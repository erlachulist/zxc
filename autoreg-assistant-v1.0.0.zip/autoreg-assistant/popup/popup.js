/**
 * AutoReg Assistant — popup (фазы 2–9).
 *
 * Вкладка «Email»: генерация (стратегия/конкретный провайдер), копирование,
 * проверка почты с OTP-кодом и ссылкой, заполнение формы на активной вкладке.
 * Вкладка «Записи»: список с поиском и фильтром по тегам, детали с копированием
 * полей, верификацией, логом попыток, тегами/заметками, удалением; экспорт JSON.
 * Пока popup открыт и запись ждёт письма — периодическая проверка почты.
 * Вся сетевая логика в background; popup только рисует результат.
 */

const $ = (id) => document.getElementById(id);

const els = {
  tabEmail: $("tabEmail"),
  tabRecords: $("tabRecords"),
  viewEmail: $("viewEmail"),
  viewRecords: $("viewRecords"),
  viewDetail: $("viewDetail"),
  btnOptions: $("btnOptions"),

  generate: $("btnGenerate"),
  generateLabel: $("btnGenerateLabel"),
  emailBlock: $("emailBlock"),
  emailText: $("emailText"),
  copy: $("btnCopy"),
  copyLabel: $("btnCopyLabel"),
  emailStatusChip: $("emailStatusChip"),
  emailStatusText: $("emailStatusText"),
  emailStatusHint: $("emailStatusHint"),
  check: $("btnCheck"),
  checkLabel: $("btnCheckLabel"),
  messages: $("messagesBlock"),
  list: $("messagesList"),
  noMessages: $("noMessages"),
  codeBlock: $("codeBlock"),
  codeText: $("codeText"),
  btnCopyCode: $("btnCopyCode"),
  linksBlock: $("linksBlock"),
  btnOpenLink: $("btnOpenLink"),

  fill: $("btnFillForm"),
  fillLabel: $("btnFillLabel"),
  fillResult: $("fillResult"),

  providerDetails: $("providerDetails"),
  providerModeLabel: $("providerModeLabel"),
  providerSelect: $("providerSelect"),
  providerToggles: $("providerToggles"),

  error: $("errorBlock"),
  errorText: $("errorText"),
  errorType: $("errorType"),

  search: $("searchInput"),
  btnExport: $("btnExport"),
  tagFilter: $("tagFilter"),
  recordsEmpty: $("recordsEmpty"),
  recordsList: $("recordsList"),

  btnBack: $("btnBack"),
  detailContent: $("detailContent"),
};

/** Текущее состояние: текущая запись на вкладке Email + UI. */
const state = {
  recordId: null,
  email: null,
  providerName: null,
  busy: false,
  activeTag: null,
  detailRecordId: null,
  detailRecord: null,
  pollTimer: null,
  currentLinks: [],
};

const CURRENT_KEY = "ar_popup_current";

const STATUS = {
  generated: { label: "создан", cls: "st-generated" },
  form_filled: { label: "форма заполнена", cls: "st-form_filled" },
  submitted: { label: "отправлено", cls: "st-submitted" },
  pending_verification: { label: "ждём письма", cls: "st-pending_verification" },
  verified: { label: "подтверждено", cls: "st-verified" },
  failed: { label: "ошибка", cls: "st-failed" },
};

const ERROR_TYPE_LABELS = {
  network: "сеть",
  rate_limit: "лимит запросов",
  provider_unavailable: "сервис недоступен",
  domain_rejected: "домен отклонён",
  email_taken: "email занят",
  form_not_found: "форма не найдена",
  unknown: "ошибка",
};

document.addEventListener("DOMContentLoaded", init);

async function init() {
  bindEvents();
  await Promise.all([loadCurrentEmail(), loadProviders()]);
  await switchTab("email");
  startPopupPolling();
}

function bindEvents() {
  els.tabEmail.addEventListener("click", () => switchTab("email"));
  els.tabRecords.addEventListener("click", () => switchTab("records"));
  els.btnOptions.addEventListener("click", () => chrome.runtime.openOptionsPage());
  els.generate.addEventListener("click", onGenerate);
  els.copy.addEventListener("click", () => onCopy(els.copyLabel, state.email));
  els.btnCopyCode.addEventListener("click", () => onCopy(null, els.codeText.textContent));
  els.btnOpenLink.addEventListener("click", onOpenLink);
  els.check.addEventListener("click", () => checkInbox(state.recordId, { render: true }));
  els.fill.addEventListener("click", onFillForm);
  els.providerSelect.addEventListener("change", () => {
    const v = els.providerSelect.value;
    els.providerModeLabel.textContent = v === "auto" ? "Авто (стратегия)" : v;
  });
  els.search.addEventListener("input", renderRecords);
  els.btnExport.addEventListener("click", exportJson);
  els.btnBack.addEventListener("click", () => switchTab("records"));
}

/** Обёртка над chrome.runtime.sendMessage, возвращающая Promise. */
function sendMessage(message) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(message, (response) => {
        resolve(response ?? { ok: false, error: "Background не ответил. Попробуйте ещё раз.", errorType: "unknown" });
      });
    } catch {
      resolve({ ok: false, error: "Расширение перезагружается — откройте popup заново.", errorType: "unknown" });
    }
  });
}

function setBusy(busy) {
  state.busy = busy;
  els.generate.disabled = busy;
  els.fill.disabled = busy;
  els.check.disabled = busy || !state.recordId;
}

// ---------------------------------------------------------------------------
// Вкладки
// ---------------------------------------------------------------------------

async function switchTab(tab) {
  stopDetailPolling();
  const isEmail = tab === "email";
  els.tabEmail.classList.toggle("active", isEmail);
  els.tabRecords.classList.toggle("active", !isEmail);
  els.viewEmail.hidden = !isEmail;
  els.viewRecords.hidden = isEmail;
  els.viewDetail.hidden = true;
  state.detailRecordId = null;
  if (!isEmail) await renderRecords();
}

// ---------------------------------------------------------------------------
// Провайдеры (фаза 7)
// ---------------------------------------------------------------------------

async function loadProviders() {
  const resp = await sendMessage({ type: "GET_PROVIDERS" });
  if (!resp.ok) return;
  const all = [
    { id: "auto", title: "Авто (стратегия)" },
    ...resp.builtin.map((p) => ({ id: p.id, title: p.title, enabled: p.enabled })),
    ...resp.custom.map((p) => ({ id: p.id, title: `${p.name} (кастомный)`, enabled: p.enabled })),
  ];

  const prev = els.providerSelect.value;
  els.providerSelect.textContent = "";
  for (const p of all) {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = p.title;
    els.providerSelect.append(opt);
  }
  if (prev && all.some((p) => p.id === prev)) els.providerSelect.value = prev;

  // Переключатели enable/disable встроенных и кастомных
  els.providerToggles.textContent = "";
  for (const p of [...resp.builtin, ...resp.custom]) {
    const label = document.createElement("label");
    label.className = "provider-toggle";
    const name = document.createElement("span");
    name.className = "name";
    name.textContent = p.title + (resp.custom.some((c) => c.id === p.id) ? " (кастомный)" : "");
    const sw = document.createElement("span");
    sw.className = "switch";
    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = p.enabled;
    input.addEventListener("change", async () => {
      const r = await sendMessage({ type: "SET_PROVIDER_ENABLED", id: p.id, enabled: input.checked });
      if (!r.ok) {
        input.checked = !input.checked;
        showError(r);
      }
    });
    const track = document.createElement("span");
    track.className = "track";
    sw.append(input, track);
    label.append(name, sw);
    els.providerToggles.append(label);
  }
}

// ---------------------------------------------------------------------------
// Генерация email
// ---------------------------------------------------------------------------

async function onGenerate() {
  if (state.busy) return;
  setBusy(true);
  els.generateLabel.textContent = "Создаю ящик…";
  hideError();
  hideMessages();

  const providerName = els.providerSelect.value !== "auto" ? els.providerSelect.value : undefined;
  const resp = await sendMessage({ type: "GENERATE_EMAIL", providerName });

  setBusy(false);
  els.generateLabel.textContent = state.recordId ? "Сгенерировать новый email" : "Сгенерировать email";
  if (!resp.ok) {
    showError(resp);
    return;
  }
  applyEmail(resp.recordId, resp.email, resp.providerName);
  saveCurrentEmail();
}

function applyEmail(recordId, email, providerName) {
  state.recordId = recordId;
  state.email = email;
  state.providerName = providerName ?? null;
  els.emailText.textContent = email;
  els.emailText.title = email;
  els.emailStatusChip.className = "status-chip st-generated";
  els.emailStatusText.textContent = STATUS.generated.label;
  els.emailStatusHint.textContent = "запись в журнале";
  els.emailBlock.hidden = false;
  els.check.disabled = false;
  els.generateLabel.textContent = "Сгенерировать новый email";
}

async function loadCurrentEmail() {
  try {
    const stored = await chrome.storage.session.get(CURRENT_KEY);
    const cur = stored?.[CURRENT_KEY];
    if (cur?.recordId && cur?.email) applyEmail(cur.recordId, cur.email, cur.providerName);
  } catch {
    /* storage.session недоступен — начинаем с чистого листа */
  }
}

async function saveCurrentEmail() {
  if (!state.recordId) return;
  try {
    chrome.storage.session.set({
      [CURRENT_KEY]: { recordId: state.recordId, email: state.email, providerName: state.providerName, savedAt: Date.now() },
    });
  } catch {
    /* не критично */
  }
}

// ---------------------------------------------------------------------------
// Проверка почты
// ---------------------------------------------------------------------------

async function checkInbox(recordId, { render = true } = {}) {
  if (!recordId || state.busy) return { messages: [] };
  if (render) {
    setBusy(true);
    els.checkLabel.textContent = "Проверяю…";
    hideError();
  }
  const resp = await sendMessage({ type: "CHECK_INBOX", recordId });
  if (render) {
    setBusy(false);
    els.checkLabel.textContent = "Проверить почту";
  }
  if (!resp.ok) {
    if (render) showError(resp);
    return { messages: [] };
  }
  if (render) renderMessages(resp.messages ?? [], resp);
  return { messages: resp.messages ?? [], code: resp.code, links: resp.links };
}

/** Список писем + код + ссылка. Только textContent — никакого HTML из писем (XSS). */
function renderMessages(messages, resp) {
  els.messages.hidden = false;
  els.list.textContent = "";
  if (messages.length === 0) {
    els.noMessages.hidden = false;
    els.noMessages.textContent = resp?.expired ? "Писем нет. Срок жизни ящика истёк." : "Писем нет";
  } else {
    els.noMessages.hidden = true;
    for (const m of messages) {
      const li = document.createElement("li");
      li.className = "message";
      const from = document.createElement("span");
      from.className = "message-from";
      from.textContent = m.from || "(неизвестный отправитель)";
      const subject = document.createElement("span");
      subject.className = "message-subject";
      subject.textContent = m.subject || "(без темы)";
      li.append(from, subject);
      els.list.appendChild(li);
    }
  }

  if (resp?.code) {
    els.codeBlock.hidden = false;
    els.codeText.textContent = resp.code;
  } else {
    els.codeBlock.hidden = true;
  }

  state.currentLinks = resp?.links ?? [];
  els.linksBlock.hidden = state.currentLinks.length === 0;
}

async function onOpenLink() {
  const link = state.currentLinks[0];
  if (!link) return;
  const resp = await sendMessage({ type: "OPEN_LINK", url: link, recordId: state.recordId });
  if (!resp.ok) showError(resp);
  else {
    els.linksBlock.hidden = true;
    els.emailStatusChip.className = "status-chip st-verified";
    els.emailStatusText.textContent = STATUS.verified.label;
    els.emailStatusHint.textContent = "ссылка открыта";
  }
}

// ---------------------------------------------------------------------------
// Заполнение формы на активной вкладке (фаза 3)
// ---------------------------------------------------------------------------

async function onFillForm() {
  if (state.busy) return;
  setBusy(true);
  els.fillLabel.textContent = "Заполняю…";
  hideError();
  els.fillResult.hidden = true;

  let tabId = null;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    tabId = tab?.id ?? null;
  } catch {
    /* tabs недоступен — background вернёт понятную ошибку */
  }

  const resp = await sendMessage({ type: "FILL_FORM", tabId });
  setBusy(false);
  els.fillLabel.textContent = "Заполнить форму на этой вкладке";

  if (!resp.ok) {
    showError(resp);
    return;
  }
  hideError();
  els.fillResult.hidden = false;
  els.fillResult.textContent = `Заполнено полей: ${resp.filled?.total ?? 0}. Email: ${resp.email}`;
  applyEmail(resp.recordId, resp.email, resp.providerName);
  saveCurrentEmail();
  els.emailStatusChip.className = "status-chip st-form_filled";
  els.emailStatusText.textContent = STATUS.form_filled.label;
  els.emailStatusHint.textContent = "жду сабмит";
}

// ---------------------------------------------------------------------------
// Записи: список, поиск, теги (фаза 2/9)
// ---------------------------------------------------------------------------

let allRecords = [];

async function renderRecords() {
  const resp = await sendMessage({ type: "GET_RECORDS" });
  if (!resp.ok) {
    showError(resp);
    return;
  }
  allRecords = (resp.records ?? []).slice().sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0));
  renderTagFilter();
  renderRecordRows();
}

function matchesQuery(r, q) {
  if (!q) return true;
  const hay = `${r.domain ?? ""} ${r.email ?? ""} ${r.username ?? ""} ${r.notes ?? ""} ${(r.tags ?? []).join(" ")}`.toLowerCase();
  return q
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean)
    .every((token) => hay.includes(token));
}

function renderRecordRows() {
  const q = els.search.value.trim();
  const tag = state.activeTag;
  const records = allRecords.filter((r) => matchesQuery(r, q) && (!tag || (r.tags ?? []).includes(tag)));

  els.recordsList.textContent = "";
  els.recordsEmpty.hidden = records.length > 0;
  if (records.length === 0) {
    els.recordsEmpty.innerHTML = "";
    els.recordsEmpty.append(
      document.createTextNode(allRecords.length === 0 ? "Пока нет записей." : q || tag ? "Ничего не найдено." : "Пока нет записей."),
      document.createElement("br")
    );
    els.recordsEmpty.append(document.createTextNode("Сгенерируйте email или заполните форму."));
  }

  for (const r of records.slice(0, 100)) {
    const row = document.createElement("li");
    row.className = "record-row";

    const top = document.createElement("div");
    top.className = "record-top";
    const domain = document.createElement("span");
    domain.className = "record-domain";
    domain.textContent = r.domain || "—";
    domain.title = r.siteName || r.domain || "";
    const time = document.createElement("span");
    time.className = "record-time";
    time.textContent = timeAgo(r.updatedAt ?? r.createdAt);
    top.append(domain, time);

    const email = document.createElement("span");
    email.className = "record-email";
    email.textContent = r.email ?? "";
    email.title = r.email ?? "";

    row.append(top, email);

    if (r.status) {
      const status = document.createElement("div");
      status.className = "record-top";
      const chip = statusChip(r.status);
      const spacer = document.createElement("span");
      spacer.style.flex = "1";
      status.append(chip, spacer);
      row.append(status);
    }

    if ((r.tags ?? []).length) {
      const tags = document.createElement("div");
      tags.className = "record-tags";
      for (const t of r.tags.slice(0, 5)) {
        const chip = document.createElement("span");
        chip.className = "tag-chip";
        chip.textContent = `#${t}`;
        tags.append(chip);
      }
      row.append(tags);
    }

    row.addEventListener("click", () => openDetail(r.id));
    els.recordsList.append(row);
  }
}

function renderTagFilter() {
  const tags = [...new Set(allRecords.flatMap((r) => r.tags ?? []))].slice(0, 12);
  els.tagFilter.textContent = "";
  els.tagFilter.hidden = tags.length === 0;
  for (const t of tags) {
    const chip = document.createElement("button");
    chip.className = "tag-chip" + (state.activeTag === t ? " active" : "");
    chip.textContent = `#${t}`;
    chip.addEventListener("click", () => {
      state.activeTag = state.activeTag === t ? null : t;
      renderTagFilter();
      renderRecordRows();
    });
    els.tagFilter.append(chip);
  }
}

// ---------------------------------------------------------------------------
// Детали записи (фаза 2 + 6 + 9)
// ---------------------------------------------------------------------------

async function openDetail(recordId) {
  const resp = await sendMessage({ type: "GET_RECORD", recordId });
  if (!resp.ok) {
    showError(resp);
    return;
  }
  state.detailRecordId = recordId;
  state.detailRecord = resp.record;
  renderDetail(resp.record);
  els.viewRecords.hidden = true;
  els.viewDetail.hidden = false;
  startDetailPolling();
}

function fieldRow({ label, value, copyable = false, masked = false, plain = false }) {
  const row = document.createElement("div");
  row.className = "field-row";
  const labelEl = document.createElement("span");
  labelEl.className = "field-label";
  labelEl.textContent = label;
  const valueEl = document.createElement("span");
  valueEl.className = "field-value" + (plain ? " plain" : "");
  if (masked) {
    valueEl.dataset.masked = "1";
    valueEl.textContent = "••••••••••";
    valueEl.dataset.real = value;
  } else {
    valueEl.textContent = value;
  }
  row.append(labelEl, valueEl);

  if (value) {
    const actions = document.createElement("span");
    actions.className = "field-actions";
    if (masked) {
      const reveal = document.createElement("button");
      reveal.className = "btn-icon";
      reveal.textContent = "👁";
      reveal.title = "Показать/скрыть";
      reveal.addEventListener("click", () => {
        const el = row.querySelector(".field-value");
        if (el.dataset.masked === "1") {
          el.textContent = el.dataset.real;
          el.dataset.masked = "0";
        } else {
          el.textContent = "••••••••••";
          el.dataset.masked = "1";
        }
      });
      actions.append(reveal);
    }
    if (copyable) {
      const copy = document.createElement("button");
      copy.className = "btn-icon";
      copy.textContent = "Копировать";
      copy.addEventListener("click", async () => {
        const ok = await copyToClipboard(value);
        copy.textContent = ok ? "Скопировано ✓" : "Не удалось";
        setTimeout(() => (copy.textContent = "Копировать"), 1500);
      });
      actions.append(copy);
    }
    row.append(actions);
  }
  return row;
}

function statusChip(status) {
  const info = STATUS[status] ?? { label: status, cls: "st-generated" };
  const chip = document.createElement("span");
  chip.className = `status-chip ${info.cls}`;
  const dot = document.createElement("span");
  dot.className = "dot";
  const text = document.createElement("span");
  text.textContent = info.label;
  chip.append(dot, text);
  return chip;
}

function renderDetail(record) {
  const c = els.detailContent;
  c.textContent = "";

  // Шапка: сайт + статус
  const head = document.createElement("div");
  head.className = "detail-head";
  const site = document.createElement("div");
  site.className = "detail-site";
  site.textContent = record.siteName || record.domain || "—";
  head.append(site, statusChip(record.status));
  c.append(head);

  // Поля
  const card = document.createElement("div");
  card.className = "card";
  card.append(fieldRow({ label: "Email", value: record.email, copyable: true }));
  if (record.password) card.append(fieldRow({ label: "Пароль", value: record.password, copyable: true, masked: true }));
  if (record.username) card.append(fieldRow({ label: "Username", value: record.username, copyable: true }));
  card.append(fieldRow({ label: "Провайдер", value: record.providerName || "—", plain: true }));
  if (record.url) card.append(fieldRow({ label: "Ссылка", value: record.url, plain: true }));
  card.append(fieldRow({ label: "Создана", value: new Date(record.createdAt).toLocaleString("ru-RU"), plain: true }));
  if (record.url) {
    const open = document.createElement("a");
    open.href = record.url;
    open.target = "_blank";
    open.className = "muted hint";
    open.style.display = "block";
    open.textContent = "Открыть сайт регистрации";
    card.append(open);
  }

  // Проверка почты по этой записи
  const checkBtn = document.createElement("button");
  checkBtn.className = "btn btn-secondary";
  const checkLabel = document.createElement("span");
  checkLabel.textContent = "Проверить почту";
  checkBtn.append(checkLabel);
  const detailMsgs = document.createElement("ul");
  const msgTitle = document.createElement("div");
  msgTitle.className = "messages-title";
  msgTitle.textContent = "Входящие";
  msgTitle.hidden = true;
  detailMsgs.style.cssText = "display:flex;flex-direction:column;gap:6px;margin-top:8px;";
  checkBtn.addEventListener("click", async () => {
    checkLabel.textContent = "Проверяю…";
    const { messages } = await checkInbox(record.id, { render: false });
    checkLabel.textContent = "Проверить почту";
    msgTitle.hidden = false;
    detailMsgs.textContent = "";
    if (messages.length === 0) {
      const li = document.createElement("li");
      li.className = "no-messages";
      li.textContent = "Писем нет";
      detailMsgs.append(li);
    }
    for (const m of messages) {
      const li = document.createElement("li");
      li.className = "message";
      const from = document.createElement("span");
      from.className = "message-from";
      from.textContent = m.from || "(неизвестный отправитель)";
      const subject = document.createElement("span");
      subject.className = "message-subject";
      subject.textContent = m.subject || "(без темы)";
      li.append(from, subject);
      detailMsgs.append(li);
    }
  });
  card.append(checkBtn, msgTitle, detailMsgs);
  c.append(card);

  // Верификация (фаза 5)
  const v = record.verification ?? {};
  if (v.otpCode || v.link || v.messageCount) {
    const box = document.createElement("div");
    box.className = "verification-box";
    const title = document.createElement("div");
    title.style.fontWeight = "650";
    title.textContent = "Верификация";
    box.append(title);
    if (v.otpCode) {
      const row = document.createElement("div");
      row.className = "row";
      const code = document.createElement("code");
      code.textContent = v.otpCode;
      const copyBtn = document.createElement("button");
      copyBtn.className = "btn-icon";
      copyBtn.textContent = "Копировать";
      copyBtn.addEventListener("click", async () => {
        await copyToClipboard(v.otpCode);
        copyBtn.textContent = "Скопировано ✓";
        setTimeout(() => (copyBtn.textContent = "Копировать"), 1500);
      });
      row.append(code, copyBtn);
      box.append(row);
    }
    if (v.link) {
      const row = document.createElement("div");
      row.className = "row";
      const linkEl = document.createElement("code");
      linkEl.textContent = v.link.length > 42 ? v.link.slice(0, 42) + "…" : v.link;
      linkEl.title = v.link;
      const openBtn = document.createElement("button");
      openBtn.className = "btn-icon";
      openBtn.textContent = "Открыть";
      openBtn.addEventListener("click", async () => {
        const resp = await sendMessage({ type: "OPEN_LINK", url: v.link, recordId: record.id });
        if (!resp.ok) showError(resp);
      });
      row.append(linkEl, openBtn);
      box.append(row);
    }
    const count = document.createElement("div");
    count.className = "muted";
    count.style.color = "var(--violet)";
    count.textContent = `писем получено: ${v.messageCount ?? 0}`;
    box.append(count);
    c.append(box);
  }

  // Лог попыток (фаза 6)
  if ((record.attempts ?? []).length) {
    const title = document.createElement("div");
    title.className = "section-title";
    title.textContent = "Попытки";
    const list = document.createElement("div");
    list.className = "attempts";
    for (const a of record.attempts) {
      const item = document.createElement("div");
      item.className = "attempt";
      const top = document.createElement("div");
      top.className = "attempt-top";
      const time = document.createElement("span");
      time.textContent = new Date(a.timestamp).toLocaleString("ru-RU");
      const info = STATUS[record.status] ? null : null;
      void info;
      top.append(time, statusChipForError(a.errorType));
      const err = document.createElement("div");
      err.className = "attempt-error";
      err.textContent = `${a.error || ""}${a.domain ? ` (домен: ${a.domain})` : ""}`;
      item.append(top, err);
      list.append(item);
    }
    c.append(title, list);
  }

  // Теги и заметки (фаза 9)
  const tagsTitle = document.createElement("div");
  tagsTitle.className = "section-title";
  tagsTitle.textContent = "Теги и заметки";
  const tagsCard = document.createElement("div");
  tagsCard.className = "card";
  const tagsEditor = document.createElement("div");
  tagsEditor.className = "tags-editor";
  const tags = [...(record.tags ?? [])];
  const tagChips = [];
  for (const t of tags) {
    const chip = document.createElement("button");
    chip.className = "tag-chip";
    chip.textContent = `#${t} ✕`;
    chip.title = "Убрать тег";
    chip.addEventListener("click", () => {
      const i = tags.indexOf(t);
      if (i >= 0) tags.splice(i, 1);
      chip.remove();
      saveTagsNotes(tagsCard, record, tags, null);
    });
    tagChips.push(chip);
    tagsEditor.append(chip);
  }
  const tagInput = document.createElement("input");
  tagInput.placeholder = "добавить тег…";
  tagInput.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    const val = tagInput.value.trim().replace(/^#/, "").slice(0, 30);
    if (!val || tags.includes(val)) {
      tagInput.value = "";
      return;
    }
    tags.push(val);
    const chip = document.createElement("button");
    chip.className = "tag-chip";
    chip.textContent = `#${val} ✕`;
    chip.addEventListener("click", () => {
      const i = tags.indexOf(val);
      if (i >= 0) tags.splice(i, 1);
      chip.remove();
      saveTagsNotes(tagsCard, record, tags, null);
    });
    tagChips.push(chip);
    tagInput.before(chip);
    tagInput.value = "";
    saveTagsNotes(tagsCard, record, tags, null);
  });
  tagsEditor.append(tagInput);
  const notes = document.createElement("textarea");
  notes.className = "notes-area";
  notes.placeholder = "Заметки о регистрации…";
  notes.value = record.notes ?? "";
  const saveRow = document.createElement("div");
  saveRow.className = "save-row";
  const saveBtn = document.createElement("button");
  saveBtn.className = "btn-icon";
  saveBtn.textContent = "Сохранить";
  saveBtn.addEventListener("click", () => saveTagsNotes(tagsCard, record, tags, notes.value));
  saveRow.append(saveBtn);
  tagsCard.append(tagsEditor, notes, saveRow);
  c.append(tagsTitle, tagsCard);

  // Удаление
  const delBtn = document.createElement("button");
  delBtn.className = "btn btn-danger";
  delBtn.textContent = "Удалить запись";
  delBtn.addEventListener("click", async () => {
    if (!confirm(`Удалить запись ${record.email}?`)) return;
    const resp = await sendMessage({ type: "DELETE_RECORD", recordId: record.id });
    if (!resp.ok) {
      showError(resp);
      return;
    }
    if (state.recordId === record.id) {
      state.recordId = null;
      state.email = null;
      els.emailBlock.hidden = true;
      els.messages.hidden = true;
      chrome.storage.session.remove(CURRENT_KEY).catch(() => {});
    }
    switchTab("records");
  });
  c.append(delBtn);
}

function statusChipForError(errorType) {
  const chip = document.createElement("span");
  chip.className = "status-chip st-failed";
  chip.textContent = ERROR_TYPE_LABELS[errorType] ?? errorType ?? "ошибка";
  return chip;
}

async function saveTagsNotes(card, record, tags, notes) {
  const patch = { tags };
  if (notes !== null) patch.notes = notes;
  const resp = await sendMessage({ type: "UPDATE_RECORD", recordId: record.id, patch });
  if (!resp.ok) {
    showError(resp);
    return;
  }
  state.detailRecord = resp.record;
  const saved = document.createElement("div");
  saved.className = "muted";
  saved.style.cssText = "text-align:right;margin-top:6px;";
  saved.textContent = "Сохранено ✓";
  card.append(saved);
  setTimeout(() => saved.remove(), 1500);
}

// ---------------------------------------------------------------------------
// Поллинг, пока popup открыт (фаза 5)
// ---------------------------------------------------------------------------

function startPopupPolling() {
  stopDetailPolling();
  state.pollTimer = setInterval(async () => {
    // Детали открыты и запись ждёт письма → обновляем их
    if (state.detailRecordId && document.visibilityState === "visible") {
      const rec = state.detailRecord;
      if (rec && ["submitted", "pending_verification"].includes(rec.status)) {
        const resp = await sendMessage({ type: "GET_RECORD", recordId: state.detailRecordId });
        if (resp.ok && state.detailRecordId === resp.record.id) {
          state.detailRecord = resp.record;
          renderDetail(resp.record);
          if (["submitted", "pending_verification"].includes(resp.record.status)) {
            await checkInbox(state.detailRecordId, { render: false });
          }
        }
      }
    }
    // Текущий email на вкладке «Email» ждёт письма → обновляем список
    if (!els.viewEmail.hidden && state.recordId) {
      const rec = allRecords.find((r) => r.id === state.recordId);
      const status = rec?.status ?? state.detailRecord?.status;
      void status;
      const resp = await sendMessage({ type: "GET_RECORD", recordId: state.recordId });
      if (resp.ok && resp.record.id === state.recordId && ["submitted", "pending_verification"].includes(resp.record.status)) {
        await checkInbox(state.recordId, { render: true });
        els.emailStatusChip.className = "status-chip " + (STATUS[resp.record.status]?.cls ?? "");
        els.emailStatusText.textContent = STATUS[resp.record.status]?.label ?? resp.record.status;
      }
    }
  }, 5000);
}

function startDetailPolling() {
  /* polling управляется общим таймером startPopupPolling */
}

function stopDetailPolling() {
  /* общий таймер продолжает жить; очистка при закрытии popup не нужна */
}

// ---------------------------------------------------------------------------
// Экспорт JSON (фаза 2)
// ---------------------------------------------------------------------------

async function exportJson() {
  const resp = await sendMessage({ type: "GET_RECORDS" });
  if (!resp.ok) {
    showError(resp);
    return;
  }
  const records = resp.records ?? [];
  const blob = new Blob([JSON.stringify(records, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `autoreg-records-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// ---------------------------------------------------------------------------
// Общее: буфер, время, ошибки
// ---------------------------------------------------------------------------

async function onCopy(labelEl, text) {
  if (!text) return false;
  const ok = await copyToClipboard(text);
  if (labelEl) {
    labelEl.textContent = ok ? "Скопировано ✓" : "Не удалось";
    setTimeout(() => (labelEl.textContent = "Копировать"), 1500);
  }
  return ok;
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const area = document.createElement("textarea");
    area.value = text;
    area.style.cssText = "position:fixed;top:0;left:0;opacity:0;";
    document.body.appendChild(area);
    area.select();
    let ok = false;
    try {
      ok = document.execCommand("copy");
    } finally {
      area.remove();
    }
    return ok;
  }
}

function timeAgo(ts) {
  if (!ts) return "";
  const diff = Date.now() - ts;
  const min = Math.floor(diff / 60000);
  if (min < 1) return "только что";
  if (min < 60) return `${min} мин назад`;
  const hours = Math.floor(min / 60);
  if (hours < 24) return `${hours} ч назад`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days} дн назад`;
  return new Date(ts).toLocaleDateString("ru-RU");
}

function showError({ error, errorType }) {
  els.error.hidden = false;
  els.errorText.textContent = error || "Неизвестная ошибка";
  const label = ERROR_TYPE_LABELS[errorType];
  els.errorType.textContent = label ? `тип: ${label}` : "";
}

function hideError() {
  els.error.hidden = true;
}

function hideMessages() {
  els.messages.hidden = true;
  els.list.textContent = "";
  els.noMessages.hidden = true;
  els.codeBlock.hidden = true;
  els.linksBlock.hidden = true;
}
