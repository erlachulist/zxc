/**
 * AutoReg Assistant — авто-вставка OTP-кодов в поля подтверждения (фаза 5).
 *
 * Поддерживает два вида полей:
 *  - одиночное: name/id/placeholder/autocomplete с code/otp/verif/pin;
 *  - сегментированное: несколько input[maxlength=1] (2–8 штук) — каждый
 *    input получает свою цифру.
 * Заполнение через core/form-filler.fillInput (нативный сеттер + input/change).
 */

import { fillInput } from "../core/form-filler.js";

const OTP_HINT_RE = /(otp|one[-_\s]?time|verif|pin|код|code)/i;
const INPUT_TYPES = ["text", "tel", "number", ""];

function isVisible(input) {
  const rect = input.getBoundingClientRect?.();
  return Boolean(rect) && rect.width > 0 && rect.height > 0;
}

function attrText(input) {
  return [input.name, input.id, input.getAttribute?.("placeholder"), input.getAttribute?.("autocomplete"), input.getAttribute?.("aria-label")]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
}

/**
 * Ищет поля OTP на странице.
 * @returns {{single: HTMLInputElement|null, segmented: HTMLInputElement[], any: boolean}}
 */
export function findOtpFields() {
  const all = [...document.querySelectorAll("input")].filter(
    (i) => !i.disabled && !i.readOnly && INPUT_TYPES.includes((i.getAttribute("type") || "text").toLowerCase()) && isVisible(i)
  );

  // Сегментированный ввод: группа одно-символьных полей
  const singles = all.filter((i) => (i.getAttribute("maxlength") || "") === "1");
  let segmented = [];
  if (singles.length >= 2 && singles.length <= 8) {
    // Группа должна жить в одном контейнере (form или общий родитель)
    const containers = new Set(singles.map((i) => i.closest("form")?.id ?? i.parentElement));
    if (containers.size === 1) segmented = singles;
  }

  // Одиночное поле по текстовым признакам
  const single = segmented.length
    ? null
    : all.find((i) => {
        const hint = attrText(i);
        if (!OTP_HINT_RE.test(hint)) return false;
        const max = parseInt(i.getAttribute("maxlength") || "", 10);
        return !Number.isFinite(max) || max >= 4; // сегментированные отсекли выше
      }) ?? null;

  return { single, segmented, any: Boolean(single) || segmented.length > 0 };
}

/**
 * Вставляет код в найденное поле.
 * @returns {{applied: boolean, mode: "single"|"segmented"|null}}
 */
export function fillOtp({ code }) {
  const digits = String(code ?? "").replace(/\D/g, "");
  if (!digits) return { applied: false, mode: null };
  const { single, segmented } = findOtpFields();

  if (segmented.length) {
    // Количество цифр должно совпадать с количеством полей (иначе частичный ввод
    // только запутает сайт — код останется в записи для ручного ввода)
    if (digits.length !== segmented.length) return { applied: false, mode: "segmented" };
    segmented.forEach((input, i) => fillInput(input, digits[i]));
    segmented[Math.min(digits.length, segmented.length) - 1]?.blur?.();
    return { applied: true, mode: "segmented" };
  }

  if (single) {
    fillInput(single, digits);
    return { applied: true, mode: "single" };
  }
  return { applied: false, mode: null };
}
