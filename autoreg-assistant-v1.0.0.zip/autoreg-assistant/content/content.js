/**
 * AutoReg Assistant — content script (классический вход, НЕ module:
 * content_scripts в MV3 не бывают ES-модулями).
 *
 * Обязанности:
 *  - маршрутизатор сообщений background/popup → модули (грузятся dynamic
 *    import-ом в изолированном мире — официальный паттерн Chrome MV3);
 *  - INSPECT_FIELDS / FILL_FIELDS через core/form-filler.js;
 *  - детект сабмита после заполнения (фаза 5): submit-событие, исчезновение
 *    формы, поля OTP, тексты успеха → SUBMITTED; тексты ошибок →
 *    ERROR_SUBMITTED; сильный успех → PAGE_VERIFIED;
 *  - отчёт FORM_DETECTED для badge на иконке (фаза 3).
 *
 * UI на странице (баннер, инлайн-кнопка) — только через Shadow DOM
 * (модули page-banner.js / inline-button.js).
 */

(() => {
  // Защита от повторной инжекции (manifest + scripting.executeScript fallback)
  if (window.__autoRegAssistantLoaded) return;
  window.__autoRegAssistantLoaded = true;

  const getURL = (p) => chrome.runtime.getURL(p);

  // Модули грузятся один раз; промисы кэшируются — слушатель ниже синхронный
  const modules = {
    formFiller: import(getURL("core/form-filler.js")),
    classifier: import(getURL("core/error-classifier.js")),
    otp: import(getURL("content/otp-autofill.js")),
    banner: import(getURL("content/page-banner.js")),
    inline: import(getURL("content/inline-button.js")), // сам сканирует поля и ставит кнопки
  };

  /** Отправка в background без падения при инвалидированном контексте. */
  function sendToBackground(msg) {
    try {
      return chrome.runtime.sendMessage(msg).catch(() => null);
    } catch {
      return Promise.resolve(null);
    }
  }

  // ---------------------------------------------------------------------------
  // Детект сабмита и ошибок после заполнения (фазы 5–6)
  // ---------------------------------------------------------------------------

  const WEAK_SUCCESS_RE = /(проверьте\s+(вашу\s+)?(почту|email)|check\s+your\s+(e-?mail|inbox)|verify\s+your\s+(e-?mail|account)|подтверд(ите|ите\s+email)|confirm\s+your\s+(e-?mail|account)|we\s+(have\s+)?sent\s+(you\s+)?(an?\s+)?(e-?mail|код|code))/i;
  const STRONG_SUCCESS_RE = /(регистрац\w*\s+(успешн|заверш)|вы\s+зарегистрирован|аккаунт\s+создан|account\s+(has\s+been\s+)?(created|activated)|registration\s+(complete|successful)|successfully\s+registered)/i;
  const GENERIC_ERROR_RE = /(ошибк|error|не\s*удалось|failed|try\s+again|повторите\s+позже)/i;

  let watch = null; // {recordId, formEl, emailField, submitted, finished, timer, mo, submitHandler}

  function stopWatch() {
    if (!watch) return;
    if (watch.timer) clearTimeout(watch.timer);
    if (watch.mo) watch.mo.disconnect();
    if (watch.submitHandler) document.removeEventListener("submit", watch.submitHandler, true);
    watch = null;
  }

  /** Запуск наблюдения после заполнения полей. */
  function startSubmitWatch(recordId, fields) {
    stopWatch();
    if (!recordId) return;
    const formEl = fields.email[0]?.closest?.("form") ?? fields.password[0]?.closest?.("form") ?? null;
    watch = {
      recordId,
      formEl,
      emailField: fields.email[0] ?? null,
      submitted: false,
      finished: false,
      startedAt: Date.now(),
    };

    // Сабмит: захватываем на document — форма может перерисоваться, но
    // событие всплывёт до document в фазе захвата в любом случае
    watch.submitHandler = (event) => {
      if (!watch || watch.submitted) return;
      const target = event.target;
      const related = !watch.formEl || target === watch.formEl || (watch.emailField && target?.contains?.(watch.emailField));
      if (!related) return; // пользователь сабмитит другую форму (например, логин)
      setTimeout(markSubmitted, 1200); // даём странице отреагировать
    };
    document.addEventListener("submit", watch.submitHandler, true);

    // SPA-сигналы: исчезновение формы, поля OTP, тексты успеха/ошибок
    let scanTimer = null;
    watch.mo = new MutationObserver(() => {
      if (scanTimer) clearTimeout(scanTimer);
      scanTimer = setTimeout(scanSignals, 900);
    });
    watch.mo.observe(document.documentElement, { childList: true, subtree: true });

    watch.timer = setTimeout(stopWatch, 180000); // максимум 3 минуты наблюдения
    setTimeout(scanSignals, 1500); // первичная проверка
  }

  function markSubmitted() {
    if (!watch || watch.submitted) return;
    watch.submitted = true;
    sendToBackground({ type: "SUBMITTED", recordId: watch.recordId });
  }

  /** Один проход по сигналам страницы. */
  async function scanSignals() {
    if (!watch || watch.finished) return;
    bodyTextCache = null; // текст страницы меняется — пересобираем
    const classifier = await modules.classifier;
    const otp = await modules.otp;

    const otpFields = otp.findOtpFields();
    const formGone = watch.formEl ? !watch.formEl.isConnected : false;

    if (!watch.submitted) {
      if (otpFields.any || formGone || pageTextMatches(WEAK_SUCCESS_RE)) {
        markSubmitted();
      }
      return;
    }

    // После сабмита: ищем ошибки и сильный успех
    if (pageTextMatches(STRONG_SUCCESS_RE)) {
      watch.finished = true;
      sendToBackground({ type: "PAGE_VERIFIED", recordId: watch.recordId });
      stopWatch();
      return;
    }

    const errorText = collectErrorTexts();
    if (errorText && (classifier.classifyPageText(errorText) || GENERIC_ERROR_RE.test(errorText))) {
      watch.finished = true;
      sendToBackground({ type: "ERROR_SUBMITTED", recordId: watch.recordId, pageText: errorText.slice(0, 600) });
      // Наблюдение остановлено: дальнейшие решения принимает background (ретраи)
      stopWatch();
    }
  }

  /** Видимый текст страницы (кэш на проход — innerText дорогой). */
  let bodyTextCache = null;
  function pageText() {
    if (bodyTextCache === null) bodyTextCache = (document.body?.innerText ?? "").slice(0, 5000);
    return bodyTextCache;
  }
  function pageTextMatches(re) {
    try {
      return re.test(pageText());
    } catch {
      return false;
    }
  }

  /** Тексты из типовых контейнеров ошибок (alert'ы, подсказки форм). */
  function collectErrorTexts() {
    const selectors = '[role="alert"], [class*="error" i], [class*="alert" i], [class*="warning" i], [class*="invalid" i], [class*="danger" i]';
    const parts = [];
    try {
      for (const el of document.querySelectorAll(selectors)) {
        if (parts.length >= 25) break;
        const rect = el.getBoundingClientRect?.();
        if (rect && (rect.width === 0 || rect.height === 0)) continue; // скрытые
        const text = (el.textContent ?? "").trim();
        if (text && text.length < 400 && !parts.includes(text)) parts.push(text);
      }
    } catch {
      /* выборка безопасна */
    }
    return parts.join("\n");
  }

  /** Авто-сабмит (настройка autoSubmit): жмём форму после заполнения. */
  function scheduleAutoSubmit(fields) {
    setTimeout(() => {
      const form = fields.email[0]?.closest?.("form") ?? fields.password[0]?.closest?.("form");
      if (!form || !form.isConnected) return;
      try {
        if (typeof form.requestSubmit === "function") form.requestSubmit();
        else form.submit();
      } catch {
        // fallback: кнопка сабмита
        form.querySelector?.('[type="submit"]:not(:disabled)')?.click?.();
      }
    }, 400);
  }

  // ---------------------------------------------------------------------------
  // Отчёт о наличии формы для badge (фаза 3)
  // ---------------------------------------------------------------------------

  let lastReported = null;
  async function reportFormStatus() {
    const ff = await modules.formFiller;
    const found = ff.hasRegistrationForm(ff.detectFields());
    if (found === lastReported) return;
    lastReported = found;
    sendToBackground({ type: "FORM_DETECTED", hasForm: found });
  }

  const debouncedReport = (() => {
    let timer;
    return () => {
      clearTimeout(timer);
      timer = setTimeout(reportFormStatus, 700);
    };
  })();

  new MutationObserver(debouncedReport).observe(document.documentElement, {
    childList: true,
    subtree: true,
  });
  reportFormStatus();

  // ---------------------------------------------------------------------------
  // Маршрутизатор сообщений
  // ---------------------------------------------------------------------------

  async function route(msg) {
    switch (msg?.type) {
      case "INSPECT_FIELDS": {
        const ff = await modules.formFiller;
        const fields = ff.detectFields();
        return {
          hasForm: ff.hasRegistrationForm(fields),
          counts: {
            email: fields.email.length,
            password: fields.password.length,
            confirm: fields.confirm.length,
            username: fields.username.length,
          },
          requirements: ff.fieldRequirements(fields),
          url: location.href,
          title: document.title,
          domain: location.hostname,
        };
      }
      case "FILL_FIELDS": {
        const ff = await modules.formFiller;
        const fields = ff.detectFields();
        const filled = ff.fillFields(fields, msg.identity, { fillMode: msg.fillMode });
        if (filled.total > 0) {
          startSubmitWatch(msg.recordId, fields);
          if (msg.autoSubmit) scheduleAutoSubmit(fields);
        }
        return { filled, url: location.href, title: document.title, domain: location.hostname };
      }
      case "FILL_OTP": {
        const otp = await modules.otp;
        return otp.fillOtp({ code: msg.code });
      }
      case "SHOW_BANNER": {
        const banner = await modules.banner;
        return { shown: banner.showBanner(msg) };
      }
      case "GET_FORM_STATUS": {
        const ff = await modules.formFiller;
        return { found: ff.hasRegistrationForm(ff.detectFields()) };
      }
      default:
        return { __unknown: true };
    }
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    route(msg)
      .then((result) => sendResponse(result ?? {}))
      .catch((err) => sendResponse({ ok: false, error: String(err?.message ?? err) }));
    return true; // ответ асинхронный
  });
})();
