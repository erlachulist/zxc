/**
 * AutoReg Assistant — баннер-панель сверху страницы (фаза 5, режим linkMode=manual).
 *
 * Хост — Shadow DOM (никаких стилей в страницу). Показывает сообщение и
 * опциональную кнопку действия (например «Открыть ссылку подтверждения» —
 * клик по кнопке = user gesture, поэтому окно/вкладка откроется легально).
 * Информационные баннеры скрываются сами; баннеры с кнопкой живут до клика
 * или 60 секунд.
 */

const BANNER_STYLES = `
  :host {
    all: initial;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 2147483647;
    display: flex;
    justify-content: center;
    pointer-events: none;
    font: 13px/1.45 system-ui, -apple-system, "Segoe UI", sans-serif;
  }
  .banner {
    pointer-events: auto;
    margin: 10px 12px 0;
    max-width: 520px;
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    border-radius: 10px;
    background: #10151d;
    color: #e8edf5;
    box-shadow: 0 8px 30px rgba(0,0,0,.45);
    border-left: 3px solid var(--accent, #a3e635);
    opacity: 0;
    transform: translateY(-8px);
    transition: opacity .2s ease, transform .2s ease;
  }
  .banner.shown { opacity: 1; transform: translateY(0); }
  .banner.error { --accent: #f87171; }
  .banner .text { flex: 1; min-width: 0; word-break: break-word; }
  .banner button {
    flex: none;
    border: 0;
    border-radius: 8px;
    padding: 6px 10px;
    background: #a3e635;
    color: #1c2430;
    font: inherit;
    font-weight: 600;
    cursor: pointer;
    white-space: nowrap;
  }
  .banner button:hover { background: #bef264; }
`;

let host = null;
let root = null;
let hideTimer = null;

function ensureHost() {
  if (host?.isConnected) return;
  host = document.createElement("div");
  root = host.attachShadow({ mode: "closed" });
  const style = document.createElement("style");
  style.textContent = BANNER_STYLES;
  root.append(style);
  document.documentElement.appendChild(host);
}

/**
 * Показывает баннер.
 * @param {object} msg
 *   text        — текст сообщения;
 *   isError     — красный акцент (ошибка);
 *   actionLabel — подпись кнопки;
 *   action      — {type, ...payload} сообщение в background по клику
 *                 (например {type: "OPEN_LINK", url, recordId});
 *   autoHideMs  — авто-скрытие (по умолчанию: с кнопкой 60000, без — 4000).
 * @returns {boolean} — показан ли баннер
 */
export function showBanner(msg) {
  if (!msg?.text) return false;
  ensureHost();

  // Один баннер одновременно: заменяем предыдущий
  const banner = document.createElement("div");
  banner.className = "banner" + (msg.isError ? " error" : "");

  const text = document.createElement("span");
  text.className = "text";
  text.textContent = String(msg.text);

  banner.append(text);

  if (msg.actionLabel && msg.action) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = String(msg.actionLabel);
    button.addEventListener("click", () => {
      try {
        chrome.runtime.sendMessage(msg.action).catch(() => {});
      } catch {
        /* контекст расширения мог инвалидироваться */
      }
      hide();
    });
    banner.append(button);
  }

  // Убираем прежний баннер и таймер
  hide();
  root.append(banner);
  requestAnimationFrame(() => banner.classList.add("shown"));

  const ttl = msg.autoHideMs ?? (msg.action ? 60000 : 4000);
  if (ttl > 0) {
    hideTimer = setTimeout(hide, ttl);
  }
  return true;
}

function hide() {
  if (hideTimer) {
    clearTimeout(hideTimer);
    hideTimer = null;
  }
  if (!root) return;
  for (const banner of [...root.querySelectorAll(".banner")]) {
    banner.classList.remove("shown");
    setTimeout(() => banner.remove(), 250);
  }
}
