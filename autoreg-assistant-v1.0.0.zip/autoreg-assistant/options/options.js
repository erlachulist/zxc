/**
 * AutoReg Assistant — страница настроек (фазы 6/8/9).
 *
 * Настройки: все поля ar_settings (autoSubmit — с предупреждением).
 * Провайдеры: переключатели builtin, кастомные JSON (добавить / Test /
 * удалить). Статистика: успех/фейл по сайтам и провайдерам. Экспорт: CSV
 * KeePass и JSON. Вся логика — через background (chrome.runtime.sendMessage).
 */

const $ = (id) => document.getElementById(id);

function sendMessage(message) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(message, (response) => {
        resolve(response ?? { ok: false, error: "Background не ответил.", errorType: "unknown" });
      });
    } catch {
      resolve({ ok: false, error: "Расширение перезагружается — обновите страницу.", errorType: "unknown" });
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  loadSettings();
  loadProviders();
  loadStats();
  bindEvents();
});

// ---------------------------------------------------------------------------
// Настройки
// ---------------------------------------------------------------------------

async function loadSettings() {
  const resp = await sendMessage({ type: "GET_SETTINGS" });
  if (!resp.ok) return;
  const s = resp.settings;
  $("optStrategy").value = s.providerStrategy;
  $("optFillMode").value = s.fillMode;
  $("optLinkMode").value = s.linkMode;
  $("optMaxRetries").value = s.maxRetries;
  $("optRetryBaseDelayMs").value = s.retryBaseDelayMs;
  $("optPollingIntervalMs").value = s.pollingIntervalMs;
  $("optPollingTimeoutMs").value = s.pollingTimeoutMs;
  $("optAutoDeleteDays").value = s.autoDeleteDays;
  $("optNotifications").checked = Boolean(s.notifications);
  $("optAutoSubmit").checked = Boolean(s.autoSubmit);
  $("autoSubmitWarning").hidden = !s.autoSubmit;
}

function bindEvents() {
  $("optAutoSubmit").addEventListener("change", (e) => {
    $("autoSubmitWarning").hidden = !e.target.checked;
  });

  $("btnSaveSettings").addEventListener("click", async () => {
    const clamp = (id, lo, hi, fallback) => {
      const v = Number($(id).value);
      return Number.isFinite(v) ? Math.min(Math.max(v, lo), hi) : fallback;
    };
    const settings = {
      providerStrategy: $("optStrategy").value,
      fillMode: $("optFillMode").value,
      linkMode: $("optLinkMode").value,
      maxRetries: clamp("optMaxRetries", 1, 10, 3),
      retryBaseDelayMs: clamp("optRetryBaseDelayMs", 100, 60000, 1000),
      pollingIntervalMs: clamp("optPollingIntervalMs", 3000, 60000, 5000),
      pollingTimeoutMs: clamp("optPollingTimeoutMs", 15000, 1800000, 300000),
      autoDeleteDays: clamp("optAutoDeleteDays", 0, 365, 0),
      notifications: $("optNotifications").checked,
      autoSubmit: $("optAutoSubmit").checked,
    };
    const resp = await sendMessage({ type: "SAVE_SETTINGS", settings });
    if (!resp.ok) {
      alert(`Не удалось сохранить: ${resp.error}`);
      return;
    }
    const saved = $("settingsSaved");
    saved.hidden = false;
    setTimeout(() => (saved.hidden = true), 2000);
    loadStats(); // autoDeleteDays мог почистить записи
  });

  // --- провайдеры ---
  $("btnTestCustom").addEventListener("click", () => testCustomProvider(false));
  $("btnAddCustom").addEventListener("click", () => testCustomProvider(true));

  // --- экспорт ---
  $("btnExportCsv").addEventListener("click", exportCsv);
  $("btnExportJson").addEventListener("click", exportJson);
}

// ---------------------------------------------------------------------------
// Провайдеры (фаза 8: Manage Providers)
// ---------------------------------------------------------------------------

async function loadProviders() {
  const resp = await sendMessage({ type: "GET_PROVIDERS" });
  if (!resp.ok) return;

  const builtinList = $("builtinList");
  builtinList.textContent = "";
  for (const p of resp.builtin) {
    builtinList.append(providerRow({
      name: p.title,
      domains: p.domains,
      enabled: p.enabled,
      onToggle: async (enabled) => {
        const r = await sendMessage({ type: "SET_PROVIDER_ENABLED", id: p.id, enabled });
        return r.ok;
      },
    }));
  }

  const customList = $("customList");
  customList.textContent = "";
  if (resp.custom.length === 0) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = "Кастомных провайдеров пока нет — добавьте конфигом JSON ниже.";
    customList.append(empty);
  }
  for (const p of resp.custom) {
    const row = providerRow({
      name: p.name,
      domains: p.domains,
      enabled: p.enabled,
      onToggle: async (enabled) => {
        const r = await sendMessage({ type: "SET_PROVIDER_ENABLED", id: p.id, enabled });
        return r.ok;
      },
    });
    // Кнопка удаления (только кастомные)
    const del = document.createElement("button");
    del.className = "btn btn-danger btn-small";
    del.textContent = "Удалить";
    del.addEventListener("click", async () => {
      if (!confirm(`Удалить провайдера «${p.name}»?`)) return;
      const cur = await sendMessage({ type: "GET_PROVIDERS" });
      if (!cur.ok) return;
      const rest = cur.custom.filter((c) => c.id !== p.id);
      const r = await sendMessage({ type: "SAVE_CUSTOM_PROVIDERS", custom: rest });
      if (!r.ok) {
        alert(r.error);
        return;
      }
      loadProviders();
    });
    row.append(del);
    customList.append(row);
  }
}

function providerRow({ name, domains, enabled, onToggle }) {
  const row = document.createElement("div");
  row.className = "provider-item";
  const info = document.createElement("div");
  info.className = "provider-info";
  const nameEl = document.createElement("div");
  nameEl.className = "provider-name";
  nameEl.textContent = name;
  info.append(nameEl);
  if ((domains ?? []).length) {
    const d = document.createElement("div");
    d.className = "provider-domains";
    d.textContent = domains.join(", ");
    info.append(d);
  }
  const sw = document.createElement("label");
  sw.className = "switch";
  const input = document.createElement("input");
  input.type = "checkbox";
  input.checked = enabled;
  input.addEventListener("change", async () => {
    const ok = await onToggle(input.checked);
    if (!ok) input.checked = !input.checked;
  });
  const track = document.createElement("span");
  track.className = "track";
  sw.append(input, track);
  row.append(info, sw);
  return row;
}

/** Test (и опционально сразу добавить) кастомный провайдер из textarea. */
async function testCustomProvider(add) {
  const result = $("customResult");
  const jsonText = $("customJson").value.trim();
  result.hidden = false;
  result.className = "result";

  if (!jsonText) {
    result.classList.add("err");
    result.textContent = "Вставьте JSON-конфиг провайдера в поле выше.";
    return;
  }

  let config;
  try {
    config = JSON.parse(jsonText);
  } catch (err) {
    result.classList.add("err");
    result.textContent = `JSON не разбирается: ${err.message}`;
    return;
  }

  // Test: создаёт inbox и читает письма — проверка полного цикла
  result.textContent = "Проверяю: создаю ящик…";
  const resp = await sendMessage({ type: "TEST_CUSTOM_PROVIDER", config });
  if (!resp.ok) {
    result.classList.add("err");
    result.textContent = `✗ ${resp.error}`;
    return;
  }

  if (!add) {
    result.classList.add("ok");
    result.textContent = `✓ Inbox создан: ${resp.email}${resp.messagesCount ? `\nПисем прочитано: ${resp.messagesCount}` : ""}`;
    return;
  }

  // Добавление: сохраняем список + новый конфиг
  const cur = await sendMessage({ type: "GET_PROVIDERS" });
  if (!cur.ok) {
    result.classList.add("err");
    result.textContent = `✗ ${cur.error}`;
    return;
  }
  const exists = cur.custom.some((c) => c.name === config.name);
  const custom = exists ? cur.custom.map((c) => (c.name === config.name ? { ...c, ...config, enabled: true } : c)) : [...cur.custom, { ...config, enabled: true }];
  const save = await sendMessage({ type: "SAVE_CUSTOM_PROVIDERS", custom });
  if (!save.ok) {
    result.classList.add("err");
    result.textContent = `✗ ${save.error}`;
    return;
  }
  result.classList.add("ok");
  result.textContent = `✓ Провайдер «${config.name}» добавлен${exists ? " (обновлён)" : ""}. Inbox: ${resp.email}`;
  $("customJson").value = "";
  loadProviders();
}

// ---------------------------------------------------------------------------
// Статистика (фаза 9)
// ---------------------------------------------------------------------------

async function loadStats() {
  const resp = await sendMessage({ type: "GET_RECORDS" });
  if (!resp.ok) return;
  const records = resp.records ?? [];
  const content = $("statsContent");
  content.textContent = "";

  const total = records.length;
  const summary = document.createElement("p");
  summary.className = "muted";
  summary.textContent = `Всего записей: ${total}. Успех (verified): ${records.filter((r) => r.status === "verified").length}. Ошибки (failed): ${records.filter((r) => r.status === "failed").length}.`;
  content.append(summary);

  content.append(statsTable("По сайтам", records, (r) => r.domain || "(без домена)"));
  content.append(statsTable("По провайдерам", records, (r) => r.providerName || "(неизвестно)"));
}

function statsTable(title, records, keyOf) {
  const wrap = document.createElement("div");
  const h = document.createElement("h3");
  h.textContent = title;
  wrap.append(h);

  const groups = new Map();
  for (const r of records) {
    const key = keyOf(r);
    const g = groups.get(key) ?? { ok: 0, fail: 0, other: 0, attempts: 0 };
    if (r.status === "verified") g.ok++;
    else if (r.status === "failed") g.fail++;
    else g.other++;
    g.attempts += (r.attempts ?? []).length;
    groups.set(key, g);
  }

  if (groups.size === 0) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = "Данных пока нет.";
    wrap.append(empty);
    return wrap;
  }

  const table = document.createElement("table");
  const thead = document.createElement("thead");
  const headRow = document.createElement("tr");
  for (const [label, cls] of [["", ""], ["успех", "num"], ["фейл", "num"], ["в процессе", "num"], ["попыток", "num"]]) {
    const th = document.createElement("th");
    th.textContent = label;
    if (cls) th.className = cls;
    headRow.append(th);
  }
  thead.append(headRow);
  table.append(thead);

  const tbody = document.createElement("tbody");
  const sorted = [...groups.entries()].sort((a, b) => b[1].ok + b[1].fail - (a[1].ok + a[1].fail));
  for (const [key, g] of sorted) {
    const tr = document.createElement("tr");
    const name = document.createElement("td");
    name.textContent = key;
    name.style.wordBreak = "break-all";
    const ok = document.createElement("td");
    ok.className = "num ok-count";
    ok.textContent = g.ok;
    const fail = document.createElement("td");
    fail.className = "num fail-count";
    fail.textContent = g.fail;
    const other = document.createElement("td");
    other.className = "num";
    other.textContent = g.other;
    const attempts = document.createElement("td");
    attempts.className = "num";
    attempts.textContent = g.attempts;
    tr.append(name, ok, fail, other, attempts);
    tbody.append(tr);
  }
  table.append(tbody);
  wrap.append(table);
  return wrap;
}

// ---------------------------------------------------------------------------
// Экспорт (фаза 9: CSV KeePass; JSON — как в popup)
// ---------------------------------------------------------------------------

async function fetchRecords() {
  const resp = await sendMessage({ type: "GET_RECORDS" });
  return resp.ok ? (resp.records ?? []) : [];
}

function download(filename, text, mime) {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

/** CSV-экранирование по RFC 4180: кавычки удваиваются, поля в кавычках. */
function csvCell(value) {
  const v = String(value ?? "");
  return `"${v.replace(/"/g, '""')}"`;
}

async function exportCsv() {
  const records = await fetchRecords();
  const lines = ["Group,Title,Username,Password,URL,Notes"];
  for (const r of records) {
    lines.push(
      [
        csvCell(r.domain ?? ""),
        csvCell(r.email ?? ""),
        csvCell(r.username ?? ""),
        csvCell(r.password ?? ""),
        csvCell(r.url ?? ""),
        csvCell(r.notes ?? ""),
      ].join(",")
    );
  }
  download(`autoreg-keepass-${new Date().toISOString().slice(0, 10)}.csv`, "\uFEFF" + lines.join("\r\n"), "text/csv");
}

async function exportJson() {
  const records = await fetchRecords();
  download(`autoreg-records-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(records, null, 2), "application/json");
}
