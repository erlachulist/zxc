/**
 * AutoReg Assistant — поиск и заполнение полей форм регистрации.
 *
 * Модуль используется двумя сторонами:
 *  - content/content.js (dynamic import) — детект полей и заполнение в DOM страницы;
 *  - background/service-worker.js — НЕТ (DOM там недоступен; требования полей
 *    background получает от контента сообщением INSPECT_FIELDS).
 *
 * Заполнение: value через нативный сеттер прототипа + dispatch input и change
 * (иначе React/Vue не видят изменение), плюс focus/blur для валидаторов форм.
 */

// --- Эвристики распознавания (латиница + кириллица, из проверенного прототипа v1) ---

const EMAIL_RE = /(e[-_]?mail|mail|почт|электрон)/i;
const USERNAME_RE = /(user[-_]?name|login|nick|логин|никнейм|псевдоним)/i;
const CONFIRM_RE = /(confirm|repeat|again|re[-_]?type|re[-_]?enter|re[-_]?pass|verify|подтвер|повтор|ещ[ёе] раз)/i;
// «2» как признак повтора: password2 / pass-2 / pwd_2 (фаза 3: confirm… «2»)
const CONFIRM2_RE = /(?:pass(word)?|pwd)[-_]?2\b/i;

/** Все текстовые признаки поля: name, id, placeholder, autocomplete, aria-label, label. */
export function attrText(input) {
  const parts = [
    input.name,
    input.id,
    input.getAttribute?.("placeholder"),
    input.getAttribute?.("autocomplete"),
    input.getAttribute?.("aria-label"),
    typeof input.className === "string" ? input.className : "",
  ];
  // input.labels существует только в браузере; в тестах его нет
  if (input.labels) {
    for (const label of input.labels) parts.push(label.textContent);
  }
  const wrapper = input.closest?.("label");
  if (wrapper) parts.push((wrapper.textContent || "").slice(0, 80));
  return parts.filter(Boolean).join(" ").toLowerCase();
}

/** Поле видно и доступно для ввода. */
export function isFillable(input) {
  const type = (input.getAttribute?.("type") || "text").toLowerCase();
  if (!["text", "email", "password", "tel", "", "number"].includes(type)) return false;
  if (input.disabled || input.readOnly) return false;
  // getClientRects есть только в браузере; в тестах считаем поле видимым
  if (input.getClientRects && input.getClientRects().length === 0) return false;
  return true;
}

/** Классификация: email | username | password | confirm | null. */
export function classify(input) {
  const type = (input.getAttribute?.("type") || "text").toLowerCase();
  if (type === "password") {
    const text = attrText(input);
    return CONFIRM_RE.test(text) || CONFIRM2_RE.test((input.name || "") + " " + (input.id || "")) ? "confirm" : "password";
  }
  const text = attrText(input);
  if (type === "email" || input.getAttribute?.("autocomplete") === "email" || EMAIL_RE.test(text)) return "email";
  if (USERNAME_RE.test(text)) return "username";
  return null;
}

/**
 * Собирает поля формы регистрации на странице.
 * @param {Document|Element} [root] — по умолчанию document.
 * @returns {{email: Array, password: Array, confirm: Array, username: Array}}
 */
export function detectFields(root) {
  const doc = root ?? (typeof document !== "undefined" ? document : null);
  if (!doc?.querySelectorAll) return { email: [], password: [], confirm: [], username: [] };
  const fields = { email: [], password: [], confirm: [], username: [] };
  for (const input of doc.querySelectorAll("input")) {
    if (!isFillable(input)) continue;
    const kind = classify(input);
    if (kind) fields[kind].push(input);
  }
  return fields;
}

/** Есть ли на странице форма регистрации (эвристика из v1). */
export function hasRegistrationForm(fields) {
  const f = fields ?? detectFields();
  const passwordCount = f.password.length + f.confirm.length;
  return (f.email.length > 0 && passwordCount > 0) || f.confirm.length > 0 || passwordCount >= 2;
}

/** Численно: parseInt атрибута или 0. */
function numAttr(input, name) {
  const v = parseInt(input.getAttribute?.(name) ?? "", 10);
  return Number.isFinite(v) && v > 0 ? v : 0;
}

/**
 * Требования к паролю со стороны формы (для background/INSPECT_FIELDS):
 * minlength и maxlength поля пароля, его pattern, отдельный maxlength повтора
 * (его учитываем как дополнительный верхний предел — берём минимум).
 * Поля без ограничений возвращают 0/null.
 */
export function fieldRequirements(fields) {
  const f = fields ?? detectFields();
  const pw = f.password[0];
  const confirm = f.confirm[0];
  return {
    minLength: pw ? numAttr(pw, "minlength") : 0,
    maxLength: pw ? numAttr(pw, "maxlength") : 0,
    confirmMaxLength: confirm ? numAttr(confirm, "maxlength") : 0,
    pattern: pw ? (pw.getAttribute?.("pattern") || null) : null,
  };
}

// --- Заполнение ---

/**
 * Устанавливает value через нативный сеттер прототипа и диспатчит input/change.
 * Нативный сеттер обязателен: React/Vue перехватывают присвоение input.value
 * напрямую, и без него значение «не прилипает» к состоянию компонента.
 */
export function fillInput(input, value) {
  const proto = typeof HTMLInputElement !== "undefined" ? HTMLInputElement.prototype : null;
  const setter = proto && Object.getOwnPropertyDescriptor(proto, "value")?.set;
  input.focus?.();
  if (setter) setter.call(input, value);
  else input.value = value;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  input.blur?.();
}

/** Короткая подсветка заполненного поля (проверено в v1, не мешает валидаторам). */
function highlight(input) {
  const prevOutline = input.style.outline;
  const prevOffset = input.style.outlineOffset;
  input.style.outline = "2px solid #84cc16";
  input.style.outlineOffset = "1px";
  setTimeout(() => {
    input.style.outline = prevOutline;
    input.style.outlineOffset = prevOffset;
  }, 1600);
}

/**
 * Заполняет распознанные поля согласно fillMode:
 *   "email"           — только email;
 *   "email+password"  — email + пароль + confirm тем же паролем;
 *   "full"            — плюс username.
 * Confirm всегда получает тот же пароль, что и основное поле (фаза 3).
 * @returns {{email: number, password: number, username: number, total: number}}
 */
export function fillFields(fields, identity, { fillMode = "email+password" } = {}) {
  const f = fields ?? detectFields();
  let email = 0;
  let password = 0;
  let username = 0;

  for (const input of f.email) {
    fillInput(input, identity.email);
    highlight(input);
    email++;
  }
  if (fillMode !== "email") {
    // Пароль и его подтверждение — одним значением
    for (const input of [...f.password, ...f.confirm]) {
      fillInput(input, identity.password);
      highlight(input);
      password++;
    }
  }
  if (fillMode === "full" && identity.username) {
    for (const input of f.username) {
      fillInput(input, identity.username);
      highlight(input);
      username++;
    }
  }
  return { email, password, username, total: email + password + username };
}
