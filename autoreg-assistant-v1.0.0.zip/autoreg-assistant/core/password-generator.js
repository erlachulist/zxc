/**
 * AutoReg Assistant — генерация паролей под требования конкретного поля.
 *
 * Стратегия «генерируй-и-проверяй» (фаза 3): сначала учитываем minlength /
 * maxlength / pattern полей (пароль + confirm), генерируем криптостойкий
 * пароль из безопасного алфавита [a-zA-Z0-9!@#$%^&*], затем до 10 попыток
 * прогоняем через pattern сайта (new RegExp(pattern).test(pw)).
 */

const LOWER = "abcdefghijklmnopqrstuvwxyz";
const UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const DIGITS = "0123456789";
const SPECIAL = "!@#$%^&*";
const ALL = LOWER + UPPER + DIGITS + SPECIAL;

/** Равномерное случайное целое [0, max) без модульного смещения. */
function randInt(max) {
  const limit = 4294967296 - (4294967296 % max);
  const buf = new Uint32Array(1);
  let x;
  do {
    crypto.getRandomValues(buf);
    x = buf[0];
  } while (x >= limit);
  return x % max;
}

/**
 * Наборы символов для «генерируй-и-проверяй»: если pattern сайта запрещает
 * спецсимволы (или цифры), чередуем наборы — full → alnum → alpha — и
 * за 10 попыток подбираем подходящий вариант.
 */
const CHARSETS = {
  full: { classes: [LOWER, UPPER, DIGITS, SPECIAL], pool: ALL },
  alnum: { classes: [LOWER, UPPER, DIGITS], pool: LOWER + UPPER + DIGITS },
  alpha: { classes: [LOWER, UPPER], pool: LOWER + UPPER },
};

/** Пароль с гарантированными классами символов выбранного набора (если длина позволяет). */
function buildPassword(length, mode = "full") {
  const { classes, pool } = CHARSETS[mode];
  const chars = [];
  const n = Math.min(classes.length, length);
  for (let i = 0; i < n; i++) chars.push(classes[i][randInt(classes[i].length)]);
  while (chars.length < length) chars.push(pool[randInt(pool.length)]);
  // Фишер–Йетс: обязательные символы не должны стоять в начале
  for (let i = chars.length - 1; i > 0; i--) {
    const j = randInt(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

/** pattern из атрибута поля → RegExp; битый pattern молча игнорируем. */
function compilePattern(pattern) {
  if (!pattern) return null;
  try {
    return new RegExp(pattern);
  } catch {
    return null;
  }
}

/**
 * Генерация пароля под требования формы.
 *
 * @param {object} [opts]
 *   minLength        — атрибут minlength поля пароля (по умолчанию 0);
 *   maxLength        — атрибут maxlength поля пароля (по умолчанию нет);
 *   confirmMaxLength — свой maxlength у поля повтора; берём МИНИМУМ
 *                      (фаза 3: «если у confirm свой maxlength — минимум»);
 *   pattern          — атрибут pattern поля пароля;
 *   attempts         — лимит итераций «генерируй-и-роверяй» (по умолчанию 10).
 * @returns {{password: string, length: number, patternOk: boolean, attempts: number}}
 */
export function generatePassword({ minLength = 0, maxLength = 0, confirmMaxLength = 0, pattern = null, attempts = 10 } = {}) {
  // Итоговые границы длины: минимум 6 (чтобы пароль был осмысленным),
  // максимум — самый строгий из ограничений полей; дефолт без ограничений — 14–16.
  const hardMax = Math.min(maxLength || Infinity, confirmMaxLength || Infinity);
  const unlimited = hardMax === Infinity;
  let lo = Math.max(Number(minLength) || 0, unlimited ? 14 : 6);
  let hi = unlimited ? Math.max(16, lo) : hardMax;
  if (hi < lo) hi = lo; // сайт требует maxlength < minlength — доверяем более длинному
  const length = hi - lo >= 2 ? lo + randInt(hi - lo + 1) : hi;

  const re = compilePattern(pattern);
  // Цикл наборов символов: full (спецсимволы есть) → alnum → alpha.
  // Так pattern, запрещающий спецсимволы или цифры, удовлетворяется за пару попыток.
  const modes = ["full", "alnum", "alpha"];
  let pw = buildPassword(length, "full");
  let patternOk = true;
  let used = 0;
  if (re) {
    patternOk = re.test(pw);
    while (!patternOk && used < attempts) {
      used++;
      pw = buildPassword(length, modes[used % modes.length]);
      patternOk = re.test(pw);
    }
  }
  return { password: pw, length, patternOk, attempts: used };
}

/** Username из локальной части адреса: milly42@x.com → milly42 (запасной user_NNNNN). */
export function generateUsername(email) {
  const local = String(email ?? "").split("@")[0] || "";
  const clean = local.replace(/[^a-z0-9._-]/gi, "").slice(0, 20);
  return clean.length >= 4 ? clean : `user_${randInt(90000) + 10000}`;
}
