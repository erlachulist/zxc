/**
 * AutoReg Assistant — извлечение OTP-кодов и ссылок подтверждения из писем.
 *
 * Правила (фаза 5):
 *  - OTP: \b\d{4,8}\b + контекст-слова (code, verification, confirm, pin,
 *    и русские аналоги) в теме или в тексте рядом с числом;
 *  - ссылки: все http(s) URL из тела, приоритет тем, где в URL есть
 *    verify/confirm/activate/token/validate.
 */

const OTP_RE = /\b(\d{4,8})\b/g;
const OTP_CONTEXT_RE = /(code|verification|verify|confirm|pin|passcode|one[-\s]?time|код|провер|подтвер|однораз|парол)/i;
const URL_RE = /https?:\/\/[^\s"'<>\\)\]}]+/gi;
const URL_GOOD_RE = /(verify|verification|confirm|activate|token|validate|auth|signup|register)/i;
const URL_BAD_RE = /(unsubscribe|отпис|privacy|terms|policy|logo|icon|\.png|\.jpg|\.svg|\.gif)/i;

/** Собирает контекст вокруг совпадения (±60 символов) для проверки слов-признаков. */
function contextAround(text, index, matched, radius = 60) {
  const from = Math.max(0, index - radius);
  const to = Math.min(text.length, index + matched.length + radius);
  return text.slice(from, to);
}

/**
 * Ищет лучший OTP-код в наборе писем.
 * Приоритет: наличие контекст-слова > близость к теме > длина 6 > свежесть.
 * @param {Array<{subject: string, body: string}>} messages
 * @returns {{code: string, subject: string} | null}
 */
export function extractOtp(messages) {
  let best = null;
  let bestScore = -1;
  for (const msg of messages ?? []) {
    const subject = String(msg.subject ?? "");
    const body = String(msg.body ?? "");
    const subjectHit = OTP_CONTEXT_RE.test(subject);
    OTP_RE.lastIndex = 0;
    let m;
    while ((m = OTP_RE.exec(body)) !== null) {
      const code = m[1];
      // Годы и цены почти никогда не являются OTP
      if (/^(19|20)\d{2}$/.test(code) && !subjectHit) continue;
      const ctx = contextAround(body, m.index, code);
      const hasCtx = OTP_CONTEXT_RE.test(ctx);
      if (!hasCtx && !subjectHit) continue;
      let score = (hasCtx ? 2 : 0) + (subjectHit ? 2 : 0) + (code.length === 6 ? 1 : 0) + code.length / 10;
      if (score > bestScore) {
        bestScore = score;
        best = { code, subject };
      }
    }
  }
  return best;
}

/**
 * Собирает ссылки из писем, отсортированные по «полезности».
 * @param {Array<{subject: string, body: string}>} messages
 * @returns {Array<string>} — уникальные URL, лучшие первыми (максимум 5)
 */
export function extractLinks(messages) {
  const scores = new Map();
  for (const msg of messages ?? []) {
    const text = String(msg.subject ?? "") + "\n" + String(msg.body ?? "");
    URL_RE.lastIndex = 0;
    let m;
    while ((m = URL_RE.exec(text)) !== null) {
      let url = m[0].replace(/[.,;:!?\u201d\u2019]+$/, ""); // хвостовая пунктуация не часть URL
      if (URL_BAD_RE.test(url)) continue;
      const score = (URL_GOOD_RE.test(url) ? 2 : 0) + (URL_GOOD_RE.test(url) && /verify|confirm|activate/i.test(url) ? 1 : 0);
      scores.set(url, Math.max(scores.get(url) ?? 0, score));
    }
  }
  return [...scores.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([url]) => url);
}

/**
 * Полный разбор писем: код + приоритетная ссылка одним вызовом.
 * @returns {{code: string|null, link: string|null, links: string[]}}
 */
export function parseMessages(messages) {
  const otp = extractOtp(messages);
  const links = extractLinks(messages);
  return {
    code: otp?.code ?? null,
    link: links[0] ?? null,
    links,
  };
}
