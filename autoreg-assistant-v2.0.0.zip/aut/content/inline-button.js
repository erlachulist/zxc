/**
 * content/inline-button.js — плавающая кнопка у каждого email-поля.
 * Стили изолированы в Shadow DOM, позиция — от getBoundingClientRect (fixed),
 * пересчёт при scroll/resize через requestAnimationFrame, скрытие вне вьюпорта.
 * Клик = полный цикл заполнения (делегируется в content.js).
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});
  const SIZE = 24;
  const GAP = 6;

  const ICON_IDLE =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg>';
  const ICON_SPIN =
    '<svg class="ar-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M21 12a9 9 0 1 1-6.2-8.5"/></svg>';
  const ICON_CHECK =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
  const ICON_CROSS =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>';

  const CSS = `
    .ar-btn{position:fixed;top:0;left:0;width:${SIZE}px;height:${SIZE}px;padding:0;margin:0;border:0;
      border-radius:6px;background:#111827;color:#fff;cursor:pointer;display:flex;align-items:center;
      justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.28);pointer-events:auto;
      transition:opacity .15s ease,transform .12s ease,background .15s ease;font-family:system-ui,sans-serif}
    .ar-btn:hover{transform:scale(1.08);background:#1f2937}
    .ar-btn:active{transform:scale(.96)}
    .ar-btn svg{width:14px;height:14px;display:block}
    .ar-btn.is-success{background:#16a34a}
    .ar-btn.is-error{background:#dc2626}
    .ar-btn.is-loading{cursor:default}
    .ar-spin{animation:ar-rot .7s linear infinite;transform-origin:center}
    @keyframes ar-rot{to{transform:rotate(360deg)}}
    .ar-btn[data-tip]:hover::after{content:attr(data-tip);position:absolute;bottom:calc(100% + 6px);right:0;
      background:#111827;color:#fff;font:11px/1.35 system-ui,sans-serif;padding:5px 8px;border-radius:6px;
      width:max-content;max-width:230px;white-space:normal;box-shadow:0 6px 18px rgba(0,0,0,.35);
      pointer-events:none;z-index:1}
  `;

  let host = null;
  let shadow = null;
  let runCycle = null;
  let rafPending = false;
  let started = false;
  const buttons = new Map(); // input -> { input, btn, state }

  function debounce(fn, ms) {
    let t;
    return () => {
      clearTimeout(t);
      t = setTimeout(fn, ms);
    };
  }

  function ensureHost() {
    if (host) return;
    host = document.createElement("div");
    host.id = "autoreg-inline-host";
    host.style.cssText =
      "all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483646;pointer-events:none";
    shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = CSS;
    shadow.appendChild(style);
    (document.body || document.documentElement).appendChild(host);
  }

  function setState(rec, state, tip) {
    rec.state = state;
    const b = rec.btn;
    b.classList.remove("is-loading", "is-success", "is-error");
    b.removeAttribute("data-tip");
    if (state === "loading") {
      b.innerHTML = ICON_SPIN;
      b.classList.add("is-loading");
    } else if (state === "success") {
      b.innerHTML = ICON_CHECK;
      b.classList.add("is-success");
    } else if (state === "error") {
      b.innerHTML = ICON_CROSS;
      b.classList.add("is-error");
      if (tip) b.setAttribute("data-tip", String(tip).slice(0, 160));
    } else {
      b.innerHTML = ICON_IDLE;
    }
  }

  async function onClick(e) {
    e.stopPropagation();
    e.preventDefault();
    const rec = e.currentTarget.__ar;
    if (!rec || rec.state === "loading") return;
    setState(rec, "loading");
    let res = null;
    try {
      res = runCycle ? await runCycle({ triggerInput: rec.input }) : null;
    } catch (err) {
      res = { ok: false, error: (err && err.message) || "Ошибка" };
    }
    if (!buttons.has(rec.input)) return;
    if (res && res.ok) setState(rec, "success", "");
    else setState(rec, "error", (res && res.error) || "Не удалось заполнить");
    setTimeout(() => {
      if (buttons.has(rec.input)) setState(rec, "idle");
    }, 3000);
  }

  function makeButton(input) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "ar-btn";
    b.innerHTML = ICON_IDLE;
    b.title = "AutoReg: заполнить форму";
    b.style.opacity = "0";
    // не даём событиям утекать на сайт
    b.addEventListener("mousedown", (e) => e.stopPropagation(), true);
    b.addEventListener("click", onClick, true);
    shadow.appendChild(b);
    const rec = { input, btn: b, state: "idle" };
    b.__ar = rec;
    buttons.set(input, rec);
    // появление с задержкой 500мс (не мигает при загрузке)
    setTimeout(() => {
      if (buttons.has(input)) b.style.opacity = "1";
    }, 500);
    position(rec);
    return rec;
  }

  function removeFor(input) {
    const rec = buttons.get(input);
    if (rec) {
      rec.btn.remove();
      buttons.delete(input);
    }
  }

  function position(rec) {
    const input = rec.input;
    const b = rec.btn;
    if (!input.isConnected) {
      removeFor(input);
      return;
    }
    const r = input.getBoundingClientRect();
    const inView =
      r.width > 0 &&
      r.height > 0 &&
      r.bottom > 0 &&
      r.right > 0 &&
      r.top < (window.innerHeight || document.documentElement.clientHeight) &&
      r.left < (window.innerWidth || document.documentElement.clientWidth);
    if (!inView) {
      b.style.display = "none";
      return;
    }
    b.style.display = "flex";

    // учитываем правый padding поля / чужую иконку внутри
    let extra = 0;
    try {
      const cs = getComputedStyle(input);
      const padRight = parseFloat(cs.paddingRight) || 0;
      if (padRight > 28) extra = padRight - 22;
    } catch {}

    let top = r.top + (r.height - SIZE) / 2;
    let left = r.right - SIZE - GAP - extra;
    // слишком узкое поле — ставим кнопку снаружи справа
    if (r.width < SIZE * 2.5) left = r.right + GAP;
    b.style.top = Math.round(Math.max(0, top)) + "px";
    b.style.left = Math.round(left) + "px";
  }

  function reposition() {
    for (const rec of buttons.values()) position(rec);
  }

  function schedule() {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(() => {
      rafPending = false;
      reposition();
    });
  }

  function scan() {
    if (!shadow) return;
    const fields = NS.fieldDetector.emailFields();
    const seen = new Set(fields);
    for (const input of fields) if (!buttons.has(input)) makeButton(input);
    for (const input of [...buttons.keys()]) if (!seen.has(input) || !input.isConnected) removeFor(input);
    reposition();
  }

  const debouncedScan = debounce(scan, 400);

  function init(runFillCycle) {
    if (started) return;
    started = true;
    runCycle = runFillCycle;
    ensureHost();
    scan();
    const mo = new MutationObserver(debouncedScan);
    mo.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["type", "style", "class", "hidden", "disabled"],
    });
    window.addEventListener("scroll", schedule, { passive: true, capture: true });
    window.addEventListener("resize", schedule, { passive: true });
  }

  function teardown() {
    for (const input of [...buttons.keys()]) removeFor(input);
    if (host) host.remove();
    host = null;
    shadow = null;
    started = false;
  }

  NS.inlineButton = { init, refresh: scan, teardown };
})();
