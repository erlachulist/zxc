/**
 * content/page-banner.js — панель-баннер сверху страницы (Shadow DOM) с большой
 * кнопкой «Открыть ссылку подтверждения». Клик = user gesture (режим linkMode=manual).
 * Также используется для показа OTP-кода, если поле на странице не найдено.
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});

  const CSS = `
    .ar-wrap{position:fixed;top:14px;left:50%;transform:translateX(-50%) translateY(-12px);
      z-index:2147483647;max-width:560px;width:calc(100% - 28px);opacity:0;
      transition:opacity .2s ease,transform .2s ease;pointer-events:auto;font-family:system-ui,-apple-system,'Segoe UI',sans-serif}
    .ar-wrap.show{opacity:1;transform:translateX(-50%) translateY(0)}
    .ar-card{display:flex;align-items:center;gap:12px;background:#0b1220;color:#e8edf5;
      border:1px solid #223049;border-radius:14px;padding:12px 14px;box-shadow:0 16px 44px rgba(0,0,0,.5)}
    .ar-ic{flex:0 0 auto;width:34px;height:34px;border-radius:9px;background:#132038;display:flex;
      align-items:center;justify-content:center;color:#7dd3fc}
    .ar-ic svg{width:18px;height:18px}
    .ar-body{flex:1 1 auto;min-width:0}
    .ar-title{font-size:13px;font-weight:650;margin:0 0 2px}
    .ar-sub{font-size:12px;color:#9fb0c9;margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .ar-code{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:18px;letter-spacing:3px;color:#fff}
    .ar-actions{display:flex;gap:8px;flex:0 0 auto}
    .ar-btn{border:0;border-radius:9px;padding:9px 13px;font-size:12.5px;font-weight:600;cursor:pointer;
      background:#2563eb;color:#fff;transition:background .15s ease}
    .ar-btn:hover{background:#1d4ed8}
    .ar-btn.ghost{background:transparent;color:#9fb0c9;padding:9px 10px}
    .ar-btn.ghost:hover{color:#fff;background:#182741}
  `;

  const LINK_SVG =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>';
  const KEY_SVG =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="4.5"/><path d="m10.5 12.5 8-8"/><path d="m17 5 3 3"/><path d="m14 8 3 3"/></svg>';

  let host = null;
  let shadow = null;
  let hideTimer = null;

  function ensure() {
    if (host) return;
    host = document.createElement("div");
    host.id = "autoreg-banner-host";
    host.style.cssText = "all:initial";
    shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = CSS;
    shadow.appendChild(style);
    (document.body || document.documentElement).appendChild(host);
  }

  function render(node) {
    ensure();
    shadow.querySelectorAll(".ar-wrap").forEach((n) => n.remove());
    shadow.appendChild(node);
    requestAnimationFrame(() => node.classList.add("show"));
  }

  function el(tag, cls, html) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  }

  function hide() {
    if (!shadow) return;
    const w = shadow.querySelector(".ar-wrap");
    if (w) {
      w.classList.remove("show");
      setTimeout(() => w.remove(), 220);
    }
    clearTimeout(hideTimer);
  }

  /** Показать баннер со ссылкой подтверждения. onOpen(url) вызывается по клику. */
  function showConfirmLink(url, onOpen) {
    const wrap = el("div", "ar-wrap");
    const card = el("div", "ar-card");
    card.appendChild(el("div", "ar-ic", LINK_SVG));
    const body = el("div", "ar-body");
    body.appendChild(el("p", "ar-title", "Письмо получено — подтвердите регистрацию"));
    let hostname = url;
    try {
      hostname = new URL(url).hostname;
    } catch {}
    body.appendChild(el("p", "ar-sub", hostname));
    card.appendChild(body);
    const actions = el("div", "ar-actions");
    const openBtn = el("button", "ar-btn", "Открыть ссылку");
    openBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (onOpen) onOpen(url);
      body.querySelector(".ar-title").textContent = "Открываем ссылку подтверждения…";
      hideTimer = setTimeout(hide, 2500);
    });
    const closeBtn = el("button", "ar-btn ghost", "✕");
    closeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      hide();
    });
    actions.appendChild(openBtn);
    actions.appendChild(closeBtn);
    card.appendChild(actions);
    wrap.appendChild(card);
    render(wrap);
  }

  /** Показать OTP-код (если поле на странице не найдено). */
  function showCode(code, onCopy) {
    const wrap = el("div", "ar-wrap");
    const card = el("div", "ar-card");
    card.appendChild(el("div", "ar-ic", KEY_SVG));
    const body = el("div", "ar-body");
    body.appendChild(el("p", "ar-title", "Код подтверждения из письма"));
    body.appendChild(el("p", "ar-code", String(code)));
    card.appendChild(body);
    const actions = el("div", "ar-actions");
    const copyBtn = el("button", "ar-btn", "Копировать");
    copyBtn.addEventListener("click", async (e) => {
      e.stopPropagation();
      try {
        await navigator.clipboard.writeText(String(code));
        copyBtn.textContent = "Скопировано";
      } catch {
        if (onCopy) onCopy(String(code));
      }
    });
    const closeBtn = el("button", "ar-btn ghost", "✕");
    closeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      hide();
    });
    actions.appendChild(copyBtn);
    actions.appendChild(closeBtn);
    card.appendChild(actions);
    wrap.appendChild(card);
    render(wrap);
  }

  NS.pageBanner = { showConfirmLink, showCode, hide };
})();
