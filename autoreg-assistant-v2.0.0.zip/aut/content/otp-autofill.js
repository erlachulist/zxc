/**
 * content/otp-autofill.js — вставка кода подтверждения в поле на странице.
 * Если поле ещё не появилось — ждёт его через MutationObserver и заполняет,
 * как только оно возникнет (после сабмита формы).
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});

  let pendingCode = null;
  let observer = null;
  let timeoutId = null;

  function stop() {
    pendingCode = null;
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    clearTimeout(timeoutId);
  }

  function tryFill() {
    if (!pendingCode) return false;
    const res = NS.otpDetector.fillCode(pendingCode);
    if (res && res.filled) {
      stop();
      return true;
    }
    return false;
  }

  /** Немедленная попытка вставки. Возвращает {filled, mode?}. */
  function fillNow(code) {
    return NS.otpDetector.fillCode(code);
  }

  /** Ждать появления поля кода и вставить, когда появится. */
  function setPending(code, ttlMs) {
    pendingCode = String(code);
    if (tryFill()) return { filled: true };
    if (!observer) {
      observer = new MutationObserver(() => tryFill());
      observer.observe(document.documentElement, { childList: true, subtree: true });
    }
    clearTimeout(timeoutId);
    timeoutId = setTimeout(stop, ttlMs || 120000);
    return { filled: false, pending: true };
  }

  NS.otpAutofill = { fillNow, setPending, clear: stop };
})();
