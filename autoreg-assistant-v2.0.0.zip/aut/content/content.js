/**
 * content/content.js — оркестратор на странице.
 *  - сообщает фону о наличии email-поля (badge);
 *  - выполняет полный цикл заполнения (инлайн-кнопка / popup / контекстное меню);
 *  - детектит сабмит и тексты ошибок, инициирует верификацию/ретраи;
 *  - принимает команды фона: вставка OTP, баннер ссылки, тост.
 */
;(function () {
  if (window.__autoRegLoaded) return;
  window.__autoRegLoaded = true;

  const NS = globalThis.AutoReg;
  if (!NS || !NS.fieldDetector) return;

  let activeRecordId = null;
  let submitReported = false;
  let errorScanned = false;
  let submitWatchStarted = false;

  function debounce(fn, ms) {
    let t;
    return (...a) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...a), ms);
    };
  }

  function send(msg) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(msg, (resp) => {
          const err = chrome.runtime.lastError;
          if (err) return reject(new Error(err.message));
          resolve(resp);
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  // --- Тост на странице ---------------------------------------------------
  let toastEl = null;
  function showToast(text, ok) {
    if (toastEl) toastEl.remove();
    const div = document.createElement("div");
    div.textContent = text;
    div.style.cssText = [
      "position:fixed",
      "right:16px",
      "bottom:16px",
      "z-index:2147483647",
      "max-width:340px",
      "padding:12px 14px",
      "border-radius:10px",
      "background:#0b1220",
      "color:#e8edf5",
      "font:13px/1.45 system-ui,-apple-system,'Segoe UI',sans-serif",
      "box-shadow:0 10px 34px rgba(0,0,0,.45)",
      "border-left:3px solid " + (ok ? "#22c55e" : "#f87171"),
      "opacity:0",
      "transform:translateY(6px)",
      "transition:opacity .2s ease, transform .2s ease",
    ].join(";");
    document.documentElement.appendChild(div);
    requestAnimationFrame(() => {
      div.style.opacity = "1";
      div.style.transform = "translateY(0)";
    });
    toastEl = div;
    setTimeout(() => {
      div.style.opacity = "0";
      setTimeout(() => div.remove(), 250);
    }, 3800);
  }

  // --- Сабмит и ошибки ----------------------------------------------------
  function reportSubmitted() {
    if (submitReported || !activeRecordId) return;
    submitReported = true;
    send({ type: "SUBMITTED", recordId: activeRecordId }).catch(() => {});
  }

  function scanForError() {
    if (errorScanned || !activeRecordId) return;
    const text = (document.body && document.body.innerText) || "";
    const cls = NS.errorClassifier.classifyPageText(text);
    if (cls) {
      errorScanned = true;
      send({
        type: "ERROR_SUBMITTED",
        recordId: activeRecordId,
        kind: cls.kind,
        matchedText: cls.matchedText,
      }).catch(() => {});
    }
  }

  function afterSubmitCheck() {
    const otp = NS.otpDetector.find();
    if (otp) reportSubmitted();
    scanForError();
  }

  function startSubmitWatch(recordId) {
    activeRecordId = recordId;
    submitReported = false;
    errorScanned = false;
    if (submitWatchStarted) return;
    submitWatchStarted = true;

    document.addEventListener(
      "submit",
      () => {
        reportSubmitted();
        setTimeout(scanForError, 1200);
        setTimeout(scanForError, 3200);
      },
      true
    );
    document.addEventListener(
      "click",
      (e) => {
        const b =
          e.target &&
          e.target.closest &&
          e.target.closest("button[type=submit],input[type=submit],button:not([type])");
        if (!b) return;
        setTimeout(() => {
          reportSubmitted();
          scanForError();
        }, 120);
        setTimeout(scanForError, 1500);
        setTimeout(scanForError, 3300);
      },
      true
    );
    new MutationObserver(debounce(afterSubmitCheck, 500)).observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true,
    });
  }

  function trySubmit() {
    const anchor =
      NS.fieldDetector.emailFields()[0] || NS.fieldDetector.collectFields().password[0] || null;
    const form = anchor && anchor.closest && anchor.closest("form");
    if (form) {
      const btn = form.querySelector("button[type=submit],input[type=submit],button:not([type])");
      if (btn) {
        btn.click();
        return;
      }
      if (form.requestSubmit) form.requestSubmit();
      else form.submit();
      return;
    }
    const btn = document.querySelector("button[type=submit],input[type=submit]");
    if (btn) btn.click();
  }

  // --- Полный цикл заполнения --------------------------------------------
  async function runFillCycle() {
    try {
      const f = NS.fieldDetector.collectFields();
      if (f.email.length === 0 && f.password.length + f.confirm.length === 0) {
        return { ok: false, error: "На странице не найдены поля формы (email/пароль)." };
      }
      const gen = await send({
        type: "GENERATE_EMAIL",
        siteDomain: location.hostname,
        url: location.href,
        title: document.title,
      });
      if (!gen || !gen.ok) {
        return { ok: false, error: (gen && gen.error && gen.error.message) || "Не удалось создать email." };
      }
      const identity = gen.identity;
      const settings = gen.settings || {};
      const recordId = gen.recordId;

      const result = NS.formFiller.fillForm(
        { email: identity.email, username: identity.username },
        settings
      );
      if (result.filled.total === 0) {
        await send({ type: "CANCEL_RECORD", recordId }).catch(() => {});
        return { ok: false, error: "Не удалось заполнить поля формы." };
      }
      await send({
        type: "FORM_FILLED",
        recordId,
        password: result.password,
        filled: result.filled,
        url: result.url,
        title: result.title,
      });
      startSubmitWatch(recordId);
      showToast("Заполнено: " + identity.email, true);
      if (settings.autoSubmit) setTimeout(trySubmit, 500);
      return { ok: true, recordId, email: identity.email, filledTotal: result.filled.total };
    } catch (err) {
      return { ok: false, error: (err && err.message) || "Ошибка заполнения." };
    }
  }

  async function runEmailOnly(forceProvider) {
    try {
      if (NS.fieldDetector.emailFields().length === 0)
        return { ok: false, error: "На странице нет email-поля." };
      const gen = await send({
        type: "GENERATE_EMAIL",
        siteDomain: location.hostname,
        url: location.href,
        title: document.title,
        forceProvider: forceProvider || null,
      });
      if (!gen || !gen.ok)
        return { ok: false, error: (gen && gen.error && gen.error.message) || "Ошибка." };
      const res = NS.formFiller.fillEmailOnly(gen.identity.email);
      await send({
        type: "FORM_FILLED",
        recordId: gen.recordId,
        password: "",
        filled: res.filled,
        url: res.url,
        title: res.title,
        emailOnly: true,
      });
      startSubmitWatch(gen.recordId);
      showToast("Email: " + gen.identity.email, true);
      return { ok: true, email: gen.identity.email };
    } catch (err) {
      return { ok: false, error: (err && err.message) || "Ошибка." };
    }
  }

  function handleRefill(msg, sendResponse) {
    try {
      const identity = msg.identity || {};
      const settings = msg.settings || {};
      const result = NS.formFiller.fillForm(
        { email: identity.email, username: identity.username },
        settings
      );
      submitReported = false;
      errorScanned = false;
      activeRecordId = msg.recordId || activeRecordId;
      showToast("Новый email подставлен: " + identity.email, true);
      if (settings.autoSubmit) setTimeout(trySubmit, 500);
      sendResponse({ ok: true, filled: result.filled, password: result.password });
    } catch (err) {
      sendResponse({ ok: false, error: (err && err.message) || "Ошибка." });
    }
  }

  // --- Статус формы (badge) ----------------------------------------------
  let lastStatus = null;
  function reportStatus() {
    const hasEmail = NS.fieldDetector.hasEmailField();
    const isForm = NS.fieldDetector.detectRegistrationForm();
    const key = hasEmail + "|" + isForm;
    if (key === lastStatus) return;
    lastStatus = key;
    send({ type: "FORM_STATUS", hasEmail, isForm }).catch(() => {});
  }

  // --- Приём сообщений ----------------------------------------------------
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    switch (msg && msg.type) {
      case "PING":
        sendResponse({ pong: true });
        return false;
      case "GET_FORM_STATUS":
        sendResponse({
          hasEmail: NS.fieldDetector.hasEmailField(),
          isForm: NS.fieldDetector.detectRegistrationForm(),
          url: location.href,
          title: document.title,
        });
        return false;
      case "FILL_FORM_CYCLE":
        runFillCycle().then(sendResponse);
        return true;
      case "FILL_EMAIL_ONLY":
        runEmailOnly(msg.forceProvider).then(sendResponse);
        return true;
      case "REFILL":
        handleRefill(msg, sendResponse);
        return false;
      case "AUTOFILL_OTP": {
        const r = NS.otpAutofill.fillNow(msg.code);
        if (r && r.filled) {
          showToast("Код подтверждения вставлен", true);
          sendResponse({ ok: true, filled: true, mode: r.mode });
        } else {
          NS.otpAutofill.setPending(msg.code);
          NS.pageBanner.showCode(msg.code);
          sendResponse({ ok: true, filled: false });
        }
        return false;
      }
      case "SHOW_CONFIRM_BANNER":
        NS.pageBanner.showConfirmLink(msg.url, (u) =>
          send({ type: "OPEN_LINK", url: u, recordId: msg.recordId }).catch(() => {})
        );
        sendResponse({ ok: true });
        return false;
      case "SHOW_TOAST":
        showToast(msg.text, !!msg.ok);
        sendResponse({ ok: true });
        return false;
      default:
        return false;
    }
  });

  // --- Инициализация ------------------------------------------------------
  (async function boot() {
    let settings = null;
    try {
      const s = await send({ type: "GET_SETTINGS" });
      settings = s && s.settings;
    } catch {}
    if (!settings || settings.inlineButton !== false) {
      NS.inlineButton.init(runFillCycle);
    }
    reportStatus();
    new MutationObserver(debounce(reportStatus, 700)).observe(document.documentElement, {
      childList: true,
      subtree: true,
    });
  })();
})();
