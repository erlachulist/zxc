/**
 * providers/adapters.js — встроенные провайдеры временной почты.
 * Эндпоинты сверены живыми запросами (сентябрь 2026):
 *   tempmail.lol : POST /v2/inbox/create → {address,token}; GET /v2/inbox?token=
 *   mail.tm      : GET /domains; POST /accounts; POST /token; GET /messages (Bearer)
 *   guerrillamail: f=get_email_address → {email_addr,sid_token}; f=get_email_list
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});
  const net = NS.net;
  const utils = NS.providerUtils;

  // --- tempmail.lol -------------------------------------------------------
  const tempmail = {
    name: "tempmail.lol",
    builtin: true,
    domains: [],
    async healthCheck() {
      try {
        const r = await net.request("https://api.tempmail.lol/", { expect: "any", timeoutMs: 6000 });
        return r.status < 500;
      } catch {
        return false;
      }
    },
    async createInbox() {
      const r = await net.request("https://api.tempmail.lol/v2/inbox/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "{}",
        timeoutMs: 15000,
      });
      const d = r.data || {};
      if (!d.address || !d.token) throw new net.ApiError("bad_response", net.humanMessage("bad_response"));
      return { email: d.address, token: d.token };
    },
    async getMessages(token) {
      const r = await net.request(
        "https://api.tempmail.lol/v2/inbox?token=" + encodeURIComponent(token),
        { timeoutMs: 15000 }
      );
      const arr = Array.isArray(r.data && r.data.emails) ? r.data.emails : [];
      return arr.map((e) => ({
        id: String(e.id != null ? e.id : e.date != null ? e.date : utils.randomLocal(6)),
        from: String(e.from || ""),
        subject: String(e.subject || ""),
        body: String(e.body || ""),
        html: String(e.html || ""),
        date: e.date != null ? e.date : null,
      }));
    },
  };

  // --- mail.tm ------------------------------------------------------------
  const MAILTM = "https://api.mail.tm";
  async function mailtmDomains() {
    const r = await net.request(MAILTM + "/domains?page=1", {
      headers: { Accept: "application/json" },
      timeoutMs: 12000,
    });
    let list = r.data;
    if (list && list["hydra:member"]) list = list["hydra:member"];
    if (!Array.isArray(list)) list = [];
    return list.filter((d) => d && d.isActive !== false).map((d) => d.domain).filter(Boolean);
  }
  const mailtm = {
    name: "mail.tm",
    builtin: true,
    domains: [],
    async healthCheck() {
      try {
        return (await mailtmDomains()).length > 0;
      } catch {
        return false;
      }
    },
    async createInbox() {
      const domains = await mailtmDomains();
      if (!domains.length) throw new net.ApiError("provider_unavailable", "mail.tm: нет доступных доменов");
      const domain = domains[0];
      const password = utils.randomLocal(10) + "A1!";
      let address = "";
      for (let i = 0; i < 4; i++) {
        const candidate = utils.randomLocal(12) + "@" + domain;
        try {
          await net.request(MAILTM + "/accounts", {
            method: "POST",
            headers: { "Content-Type": "application/json", Accept: "application/json" },
            body: JSON.stringify({ address: candidate, password }),
            timeoutMs: 12000,
          });
          address = candidate;
          break;
        } catch (err) {
          const st = err && err.meta && err.meta.status;
          if (err && err.code === "http" && (st === 422 || st === 400)) continue; // занято/невалидно
          throw err;
        }
      }
      if (!address) throw new net.ApiError("provider_unavailable", "mail.tm: не удалось создать аккаунт");
      const tr = await net.request(MAILTM + "/token", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ address, password }),
        timeoutMs: 12000,
      });
      const token = tr.data && tr.data.token;
      if (!token) throw new net.ApiError("bad_response", net.humanMessage("bad_response"));
      return { email: address, token };
    },
    async getMessages(token) {
      const r = await net.request(MAILTM + "/messages?page=1", {
        headers: { Authorization: "Bearer " + token, Accept: "application/json" },
        timeoutMs: 12000,
      });
      let list = r.data;
      if (list && list["hydra:member"]) list = list["hydra:member"];
      if (!Array.isArray(list)) list = [];
      const out = [];
      for (const m of list.slice(0, 10)) {
        let html = "";
        let text = m.intro || "";
        try {
          const full = await net.request(MAILTM + "/messages/" + encodeURIComponent(m.id), {
            headers: { Authorization: "Bearer " + token, Accept: "application/json" },
            timeoutMs: 12000,
          });
          const fd = full.data || {};
          if (Array.isArray(fd.html)) html = fd.html.join("\n");
          else if (typeof fd.html === "string") html = fd.html;
          if (fd.text) text = fd.text;
        } catch {}
        out.push({
          id: String(m.id),
          from: (m.from && (m.from.address || m.from.name)) || "",
          subject: m.subject || "",
          body: text,
          html,
          date: m.createdAt || null,
        });
      }
      return out;
    },
  };

  // --- guerrillamail ------------------------------------------------------
  const GM = "https://api.guerrillamail.com/ajax.php";
  const guerrilla = {
    name: "guerrillamail",
    builtin: true,
    domains: [
      "guerrillamail.com",
      "guerrillamail.net",
      "guerrillamail.org",
      "guerrillamailblock.com",
      "sharklasers.com",
      "grr.la",
      "pokemail.net",
      "spam.me",
    ],
    async healthCheck() {
      try {
        const r = await net.request(GM + "?f=get_email_address&lang=en", { timeoutMs: 8000 });
        return !!(r.data && r.data.email_addr);
      } catch {
        return false;
      }
    },
    async createInbox() {
      const r = await net.request(GM + "?f=get_email_address&lang=en&agent=autoreg", { timeoutMs: 12000 });
      const d = r.data || {};
      if (!d.email_addr || !d.sid_token) throw new net.ApiError("bad_response", net.humanMessage("bad_response"));
      return { email: d.email_addr, token: d.sid_token };
    },
    async getMessages(token) {
      const r = await net.request(
        GM + "?f=get_email_list&offset=0&sid_token=" + encodeURIComponent(token),
        { timeoutMs: 12000 }
      );
      const list = Array.isArray(r.data && r.data.list) ? r.data.list : [];
      const out = [];
      for (const m of list.slice(0, 10)) {
        if (String(m.mail_from || "").includes("guerrillamail") && /welcome/i.test(m.mail_subject || "")) continue;
        let body = m.mail_body || "";
        if (!body) {
          try {
            const f = await net.request(
              GM + "?f=fetch_email&email_id=" + encodeURIComponent(m.mail_id) + "&sid_token=" + encodeURIComponent(token),
              { timeoutMs: 12000 }
            );
            body = (f.data && f.data.mail_body) || m.mail_excerpt || "";
          } catch {
            body = m.mail_excerpt || "";
          }
        }
        out.push({
          id: String(m.mail_id),
          from: m.mail_from || "",
          subject: m.mail_subject || "",
          body: "",
          html: body,
          date: m.mail_date || null,
        });
      }
      return out;
    },
  };

  NS.builtinProviders = [tempmail, mailtm, guerrilla];
})();
