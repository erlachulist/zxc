/**
 * providers/registry.js — реестр провайдеров: включение/выключение, выбор по
 * стратегии (rotation / random / perSiteSuccess) и failover между провайдерами.
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});
  const net = NS.net;
  const store = NS.store;
  const utils = NS.providerUtils;

  function shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const buf = new Uint32Array(1);
      crypto.getRandomValues(buf);
      const j = buf[0] % (i + 1);
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  /** Все включённые провайдеры (встроенные без disabled + кастомные). */
  async function enabledProviders() {
    const cfg = await store.getProvidersConfig();
    const disabled = new Set(cfg.disabled || []);
    const builtins = (NS.builtinProviders || []).filter((p) => !disabled.has(p.name));
    const customs = NS.customProvider
      .buildAll(cfg.custom || [], cfg.apiKeys || {})
      .filter((p) => !disabled.has(p.name));
    return [...builtins, ...customs];
  }

  /** Метаданные всех провайдеров для UI. */
  async function allProvidersMeta() {
    const cfg = await store.getProvidersConfig();
    const disabled = new Set(cfg.disabled || []);
    const builtins = (NS.builtinProviders || []).map((p) => ({
      name: p.name,
      builtin: true,
      enabled: !disabled.has(p.name),
      domains: p.domains || [],
    }));
    const customs = (cfg.custom || []).map((c) => ({
      name: c.name,
      builtin: false,
      enabled: !disabled.has(c.name),
      domains: c.domains || [],
      config: c,
    }));
    return [...builtins, ...customs];
  }

  /** Строит объект провайдера по имени (включая disabled/custom) — для теста. */
  async function buildProviderByName(name) {
    const b = (NS.builtinProviders || []).find((p) => p.name === name);
    if (b) return b;
    const cfg = await store.getProvidersConfig();
    const c = (cfg.custom || []).find((x) => x.name === name);
    if (c) return NS.customProvider.build(c, cfg.apiKeys || {});
    return null;
  }

  /** Порядок перебора провайдеров по выбранной стратегии. */
  async function selectOrder(siteDomain, forceProvider) {
    const providers = await enabledProviders();
    if (!providers.length) throw new net.ApiError("provider_unavailable", "Нет включённых провайдеров почты.");
    if (forceProvider) {
      const p = providers.find((x) => x.name === forceProvider);
      if (p) return [p, ...providers.filter((x) => x !== p)];
    }
    const settings = await store.getSettings();
    const strat = settings.providerStrategy || "rotation";

    if (strat === "random") return shuffle(providers.slice());
    if (strat === "perSiteSuccess" && siteDomain) {
      const last = await store.getSiteProvider(siteDomain);
      if (last) {
        const p = providers.find((x) => x.name === last);
        if (p) return [p, ...providers.filter((x) => x !== p)];
      }
    }
    // rotation (по кругу)
    const idx = await store.nextRotationIndex(providers.length);
    return providers.slice(idx).concat(providers.slice(0, idx));
  }

  /**
   * Создаёт inbox с ретраями и failover.
   * opts: { siteDomain, forceProvider, blacklist[], settings, onAttempt(info) }
   * Возвращает { email, token, providerName, domain }.
   */
  async function createInboxSmart(opts = {}) {
    const { siteDomain = "", forceProvider = null, blacklist = [], onAttempt = null } = opts;
    const s = opts.settings || (await store.getSettings());
    const order = await selectOrder(siteDomain, forceProvider);
    const bl = new Set((blacklist || []).map((d) => String(d).toLowerCase()));
    const notify = (info) => {
      if (onAttempt) {
        try {
          onAttempt(info);
        } catch {}
      }
    };

    let lastErr = null;
    for (const provider of order) {
      try {
        let inbox = null;
        for (let i = 0; i < 3 && !inbox; i++) {
          const created = await NS.retry.run(() => provider.createInbox(), {
            retries: s.maxRetries,
            baseDelay: s.retryBaseDelayMs,
            onRetry: (err, att, d) =>
              notify({ provider: provider.name, error: err.code, backoffMs: d, retry: att + 1 }),
          });
          const dom = utils.domainOf(created.email);
          if (bl.has(dom)) {
            notify({ provider: provider.name, domain: dom, skipped: "blacklisted" });
            continue;
          }
          inbox = { ...created, providerName: provider.name, domain: dom };
        }
        if (!inbox)
          throw new net.ApiError("provider_unavailable", `Домены ${provider.name} в чёрном списке для этого сайта.`);
        if (siteDomain) await store.setSiteProvider(siteDomain, provider.name);
        notify({ provider: provider.name, ok: true, email: inbox.email });
        return inbox;
      } catch (err) {
        lastErr = err;
        notify({ provider: provider.name, error: (err && err.code) || "unknown", failover: true, message: err && err.message });
        continue;
      }
    }
    throw lastErr || new net.ApiError("provider_unavailable", "Не удалось создать email ни у одного провайдера.");
  }

  /** Получение писем по имени провайдера и токену (поллинг, «проверить почту»). */
  async function getMessages(providerName, token) {
    let p = providerName ? await buildProviderByName(providerName) : null;
    if (!p) p = (NS.builtinProviders || [])[0];
    if (!p) throw new net.ApiError("provider_unavailable", "Провайдер не найден.");
    return p.getMessages(token);
  }

  NS.registry = {
    enabledProviders,
    allProvidersMeta,
    buildProviderByName,
    selectOrder,
    createInboxSmart,
    getMessages,
  };
})();
