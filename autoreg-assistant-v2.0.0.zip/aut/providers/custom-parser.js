/**
 * providers/custom-parser.js — превращает декларативный JSON-конфиг в рабочий
 * провайдер (без кода). Маппинг ответа через dot-notation, подстановки
 * {{token}} / {{apiKey}} / {{email}} в URL/заголовках/теле.
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});
  const net = NS.net;
  const { dotGet, randomLocal } = NS.providerUtils;

  function applyVars(str, vars, encode) {
    return String(str).replace(/\{\{(\w+)\}\}/g, (_, k) => {
      const v = vars[k] != null ? String(vars[k]) : "";
      return encode ? encodeURIComponent(v) : v;
    });
  }
  function substHeaders(headers, vars) {
    const out = {};
    for (const k in headers || {}) out[k] = applyVars(headers[k], vars, false);
    return out;
  }

  /** Проверка конфига. Возвращает { valid, errors[] } с понятными сообщениями. */
  function validate(config) {
    const errors = [];
    if (!config || typeof config !== "object") return { valid: false, errors: ["Конфиг не является объектом JSON."] };
    if (!config.name || typeof config.name !== "string") errors.push('Поле "name" обязательно (строка).');

    const ci = config.createInbox;
    if (!ci || typeof ci !== "object") errors.push('Отсутствует объект "createInbox".');
    else {
      if (!ci.url) errors.push('createInbox.url обязателен.');
      if (!ci.responseMapping || !ci.responseMapping.email)
        errors.push('createInbox.responseMapping.email обязателен (путь к адресу в ответе).');
      if (!ci.responseMapping || !ci.responseMapping.token)
        errors.push('createInbox.responseMapping.token обязателен (путь к токену в ответе).');
    }

    const gm = config.getMessages;
    if (!gm || typeof gm !== "object") errors.push('Отсутствует объект "getMessages".');
    else {
      if (!gm.url) errors.push('getMessages.url обязателен.');
      if (!gm.responseMapping || !gm.responseMapping.messages)
        errors.push('getMessages.responseMapping.messages обязателен (путь к массиву писем).');
    }
    return { valid: errors.length === 0, errors };
  }

  /** Строит провайдер из конфига. apiKeys — { [name]: key } из настроек. */
  function build(config, apiKeys) {
    const apiKey = (apiKeys && apiKeys[config.name]) || config.apiKey || "";
    const ci = config.createInbox;
    const gm = config.getMessages;

    function buildBody(cfg, vars) {
      if (cfg.body == null) return undefined;
      return typeof cfg.body === "string"
        ? applyVars(cfg.body, vars, false)
        : applyVars(JSON.stringify(cfg.body), vars, false);
    }

    return {
      name: config.name,
      builtin: false,
      custom: true,
      domains: Array.isArray(config.domains) ? config.domains : [],
      config,
      async healthCheck() {
        return true; // оптимистично; реальная проверка — при createInbox
      },
      async createInbox() {
        const vars = { apiKey };
        const url = applyVars(ci.url, vars, false);
        const headers = substHeaders(ci.headers, vars);
        const body = buildBody(ci, vars);
        if (body && !Object.keys(headers).some((h) => h.toLowerCase() === "content-type"))
          headers["Content-Type"] = "application/json";
        const r = await net.request(url, {
          method: (ci.method || "POST").toUpperCase(),
          headers,
          body,
          timeoutMs: 15000,
        });
        const email = dotGet(r.data, ci.responseMapping.email);
        const token = dotGet(r.data, ci.responseMapping.token);
        if (email == null || token == null)
          throw new net.ApiError("bad_response", `Провайдер ${config.name}: не удалось извлечь email/token из ответа.`);
        return { email: String(email), token: String(token) };
      },
      async getMessages(token) {
        const vars = { apiKey, token };
        const url = applyVars(gm.url, vars, false);
        const headers = substHeaders(gm.headers, vars);
        const r = await net.request(url, {
          method: (gm.method || "GET").toUpperCase(),
          headers,
          timeoutMs: 15000,
        });
        const map = gm.responseMapping;
        const arr = dotGet(r.data, map.messages);
        const list = Array.isArray(arr) ? arr : [];
        return list.slice(0, 15).map((item) => ({
          id: String(pick(item, map.id, ["id", "mail_id"]) || randomLocal(6)),
          from: String(pick(item, map.from, ["from", "mail_from", "sender"]) || ""),
          subject: String(pick(item, map.subject, ["subject", "mail_subject", "title"]) || ""),
          body: String(pick(item, map.body, ["body", "mail_body", "text", "content"]) || ""),
          html: String(pick(item, map.html, ["html"]) || ""),
          date: pick(item, map.date, ["date", "mail_date", "createdAt"]) || null,
        }));
      },
    };
  }

  function pick(item, path, fallbacks) {
    if (path) {
      const v = dotGet(item, path);
      if (v != null) return v;
    }
    for (const key of fallbacks || []) if (item[key] != null) return item[key];
    return undefined;
  }

  function buildAll(configs, apiKeys) {
    const out = [];
    for (const cfg of configs || []) {
      if (validate(cfg).valid) out.push(build(cfg, apiKeys));
    }
    return out;
  }

  NS.customProvider = { validate, build, buildAll };
})();
