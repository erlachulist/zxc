/**
 * providers/provider-interface.js — общий контракт провайдера временной почты
 * и утилиты для адаптеров/кастомных провайдеров.
 *
 * Провайдер = объект:
 *   {
 *     name: string,
 *     domains: string[],
 *     builtin: boolean,
 *     healthCheck(): Promise<boolean>,
 *     createInbox(): Promise<{ email, token }>,
 *     getMessages(token): Promise<Email[]>,
 *   }
 * Email (нормализованный): { id, from, subject, body, html, date }
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});

  /** Достаёт значение по dot-notation ("data.address", "a.b.0.c"). */
  function dotGet(obj, path) {
    if (!path) return undefined;
    return String(path)
      .split(".")
      .reduce((acc, key) => (acc == null ? undefined : acc[key]), obj);
  }

  /** Случайная строка [a-z0-9] заданной длины (для локальной части адреса). */
  function randomLocal(len = 12) {
    const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    const buf = new Uint8Array(len);
    crypto.getRandomValues(buf);
    let out = "";
    for (let i = 0; i < len; i++) out += chars[buf[i] % chars.length];
    // первый символ — буква (некоторые сервисы требуют)
    return "a" + out.slice(1);
  }

  function domainOf(email) {
    const at = String(email).lastIndexOf("@");
    return at >= 0 ? String(email).slice(at + 1).toLowerCase() : "";
  }

  /** Нормализует произвольный объект письма к единой форме. */
  function normalizeEmail(raw, map) {
    map = map || {};
    return {
      id: String(raw[map.id || "id"] ?? raw.id ?? raw.mail_id ?? cryptoRandomId()),
      from: String(raw[map.from || "from"] ?? raw.from ?? raw.mail_from ?? ""),
      subject: String(raw[map.subject || "subject"] ?? raw.subject ?? raw.mail_subject ?? ""),
      body: String(raw[map.body || "body"] ?? raw.body ?? raw.mail_body ?? raw.text ?? ""),
      html: String(raw[map.html || "html"] ?? raw.html ?? ""),
      date: raw[map.date || "date"] ?? raw.date ?? raw.mail_date ?? null,
    };
  }

  function cryptoRandomId() {
    return Math.random().toString(36).slice(2, 10);
  }

  NS.providerUtils = { dotGet, randomLocal, domainOf, normalizeEmail };
})();
