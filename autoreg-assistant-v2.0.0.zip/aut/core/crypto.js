/**
 * core/crypto.js — опциональное шифрование паролей мастер-паролем.
 * PBKDF2 (SHA-256, 200k итераций) → ключ AES-GCM. WebCrypto.
 *
 * Формат зашифрованной строки: "v1.<ivBase64>.<cipherBase64>".
 * Ключ живёт только в памяти контекста (не сохраняется на диск).
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});
  const enc = new TextEncoder();
  const dec = new TextDecoder();

  function bufToB64(buf) {
    const bytes = new Uint8Array(buf);
    let bin = "";
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  }
  function b64ToBuf(b64) {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }

  function randomBytes(n) {
    const b = new Uint8Array(n);
    crypto.getRandomValues(b);
    return b;
  }

  async function deriveKey(password, saltB64) {
    const salt = b64ToBuf(saltB64);
    const baseKey = await crypto.subtle.importKey(
      "raw",
      enc.encode(password),
      "PBKDF2",
      false,
      ["deriveKey"]
    );
    return crypto.subtle.deriveKey(
      { name: "PBKDF2", salt, iterations: 200000, hash: "SHA-256" },
      baseKey,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
  }

  function newSalt() {
    return bufToB64(randomBytes(16));
  }

  async function encryptString(key, plaintext) {
    const iv = randomBytes(12);
    const ct = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      key,
      enc.encode(plaintext)
    );
    return `v1.${bufToB64(iv)}.${bufToB64(ct)}`;
  }

  async function decryptString(key, packed) {
    const parts = String(packed).split(".");
    if (parts.length !== 3 || parts[0] !== "v1") throw new Error("Некорректный формат шифра");
    const iv = b64ToBuf(parts[1]);
    const ct = b64ToBuf(parts[2]);
    const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, ct);
    return dec.decode(pt);
  }

  /** Верификатор — шифрует известную строку, чтобы позже проверить пароль. */
  async function makeVerifier(key) {
    return encryptString(key, "autoreg-verify");
  }
  async function checkVerifier(key, verifier) {
    try {
      return (await decryptString(key, verifier)) === "autoreg-verify";
    } catch {
      return false;
    }
  }

  function isEncrypted(value) {
    return typeof value === "string" && value.startsWith("v1.");
  }

  NS.crypto = {
    deriveKey,
    newSalt,
    encryptString,
    decryptString,
    makeVerifier,
    checkVerifier,
    isEncrypted,
  };
})();
