/**
 * core/error-classifier.js — классификация ошибок.
 *  - по тексту страницы после сабмита (content-скрипт);
 *  - по коду ошибки API провайдера (service worker).
 * Результат управляет системой ретраев (core/retry.js).
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});

  /** Категории проблем, на которые по-разному реагируют ретраи. */
  const KIND = {
    NETWORK: "network",
    RATE_LIMIT: "rate_limit",
    PROVIDER_UNAVAILABLE: "provider_unavailable",
    DOMAIN_REJECTED: "domain_rejected", // одноразовая почта запрещена / домен заблокирован
    EMAIL_TAKEN: "email_taken",         // email уже используется
    UNKNOWN: "unknown",
  };

  const PAGE_RULES = [
    {
      kind: KIND.DOMAIN_REJECTED,
      re: /(disposable|temporary email|throwaway|temp mail|tempmail|one[-_ ]?time email|burner email|одноразов\w* (почт|адрес|email)|временн\w* (почт|email))/i,
    },
    {
      kind: KIND.EMAIL_TAKEN,
      re: /(already (registered|in use|taken|exists|associated)|email (is )?(already|taken)|account (already )?exists|user already|уже (зарегистр|используется|занят|существует)|такой (email|аккаунт) уже)/i,
    },
    {
      kind: KIND.DOMAIN_REJECTED,
      re: /(not allowed|is blocked|blacklisted|not permitted|domain .* (blocked|blacklist)|запрещ\w*|заблокирован\w*|не разрешен\w*|недопустим\w* (домен|email|почт))/i,
    },
    {
      kind: KIND.UNKNOWN,
      re: /(invalid email|некоррект\w* (email|почт)|неверн\w* (email|почт|формат))/i,
    },
  ];

  const SUCCESS_RE =
    /(success|successfully|confirmed|verified|activated|thank you|thanks|welcome|registration complete|account created|подтвержд\w*|активирован\w*|спасибо|добро пожаловать|регистрация заверш|аккаунт создан)/i;

  /** Ищет в тексте страницы типовые сообщения об ошибке регистрации. */
  function classifyPageText(text) {
    if (!text) return null;
    const t = String(text).slice(0, 20000);
    for (const rule of PAGE_RULES) {
      const m = t.match(rule.re);
      if (m) return { kind: rule.kind, matchedText: m[0].slice(0, 120) };
    }
    return null;
  }

  /** Признаки успешной регистрации/подтверждения на странице. */
  function detectSuccessText(text) {
    return !!(text && SUCCESS_RE.test(String(text).slice(0, 20000)));
  }

  /** Ошибка API провайдера → категория ретрая. */
  function classifyApiError(err) {
    const code = (err && err.code) || "unknown";
    switch (code) {
      case "network":
      case "timeout":
        return KIND.NETWORK;
      case "rate_limit":
        return KIND.RATE_LIMIT;
      case "server":
      case "http":
      case "bad_response":
      case "provider_unavailable":
        return KIND.PROVIDER_UNAVAILABLE;
      default:
        return KIND.UNKNOWN;
    }
  }

  NS.errorClassifier = {
    KIND,
    classifyPageText,
    detectSuccessText,
    classifyApiError,
  };
})();
