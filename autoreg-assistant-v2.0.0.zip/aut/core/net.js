/**
 * core/net.js — сетевой слой (используется в service worker).
 * Все запросы к API провайдеров идут отсюда: таймаут, разбор ошибок,
 * единый класс ошибки с кодом для системы ретраев.
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});

  /** Коды ошибок сети/API (совпадают с ключами классификатора ретраев). */
  const NET = {
    NETWORK: "network",
    TIMEOUT: "timeout",
    RATE_LIMIT: "rate_limit",
    SERVER: "server",
    HTTP: "http",
    BAD_RESPONSE: "bad_response",
    PROVIDER_UNAVAILABLE: "provider_unavailable",
  };

  class ApiError extends Error {
    constructor(code, message, meta) {
      super(message);
      this.name = "ApiError";
      this.code = code || "unknown";
      this.meta = meta || {};
    }
  }

  const HUMAN = {
    network: "Нет соединения с сервисом почты. Проверьте интернет.",
    timeout: "Сервис почты не ответил вовремя.",
    rate_limit: "Слишком много запросов к сервису почты (лимит). Подождите минуту.",
    server: "Сервис почты временно недоступен. Попробуйте позже.",
    http: "Сервис почты вернул ошибку.",
    bad_response: "Неожиданный ответ сервиса почты — возможно, формат API изменился.",
    provider_unavailable: "Провайдер недоступен.",
    unknown: "Неизвестная ошибка при обращении к сервису почты.",
  };

  function humanMessage(code) {
    return HUMAN[code] || HUMAN.unknown;
  }

  /**
   * Универсальный запрос с таймаутом. Возвращает { status, data, text, headers }.
   * data — распарсенный JSON (если ответ JSON), иначе null.
   * Бросает ApiError на сетевых/HTTP-проблемах.
   */
  async function request(url, opts = {}) {
    const {
      method = "GET",
      headers = {},
      body = null,
      timeoutMs = 15000,
      expect = "json", // json | text | any
    } = opts;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    let res;
    try {
      res = await fetch(url, {
        method,
        headers,
        body,
        signal: controller.signal,
        // расширение шлёт запросы из service worker: без cookies сайта
        credentials: "omit",
      });
    } catch (err) {
      if (err && err.name === "AbortError") {
        throw new ApiError(NET.TIMEOUT, humanMessage(NET.TIMEOUT));
      }
      throw new ApiError(NET.NETWORK, humanMessage(NET.NETWORK));
    } finally {
      clearTimeout(timer);
    }

    if (res.status === 429) {
      throw new ApiError(NET.RATE_LIMIT, humanMessage(NET.RATE_LIMIT), { status: 429 });
    }
    if (res.status >= 500) {
      throw new ApiError(NET.SERVER, humanMessage(NET.SERVER), { status: res.status });
    }

    const raw = await res.text();
    let data = null;
    if (expect !== "text") {
      try {
        data = raw ? JSON.parse(raw) : null;
      } catch {
        data = null;
      }
    }

    if (!res.ok) {
      const serverMsg = data && (data.error || data.message || data.detail);
      throw new ApiError(NET.HTTP, serverMsg || `HTTP ${res.status}`, { status: res.status });
    }
    if (expect === "json" && data === null && raw.trim() !== "") {
      throw new ApiError(NET.BAD_RESPONSE, humanMessage(NET.BAD_RESPONSE));
    }

    return { status: res.status, data, text: raw, headers: res.headers };
  }

  NS.net = { NET, ApiError, request, humanMessage };
})();
