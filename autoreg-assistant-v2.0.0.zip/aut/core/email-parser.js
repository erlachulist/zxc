/**
 * core/email-parser.js — извлечение из письма OTP-кода и ссылок подтверждения.
 * Используется в service worker (поллинг) и в popup («Проверить почту»).
 *
 * Приоритет: сначала OTP-код (по контексту), затем ссылки verify/confirm/…
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});

  const CONTEXT_RE =
    /(code|verification|verify|confirm|one[-_ ]?time|otp|pin|passcode|security|activat|код|подтвержд|провер)/i;
  const LINK_PRIORITY_RE =
    /(verify|confirm|activate|activation|validat|token|confirmation|verification|подтвер|актив|провер)/i;
  const LINK_DOWNRANK_RE =
    /(unsubscribe|privacy|terms|policy|help|support|\.png|\.jpe?g|\.gif|\.css|\.svg|facebook|twitter|instagram|linkedin|mailto:)/i;

  function decodeEntities(s) {
    return String(s)
      .replace(/&amp;/gi, "&")
      .replace(/&#38;/g, "&")
      .replace(/&#x26;/gi, "&")
      .replace(/&quot;/gi, '"')
      .replace(/&#39;/g, "'");
  }

  function stripHtml(html) {
    return String(html)
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ")
      .replace(/&#?\w+;/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  /** Нормализует письмо к { subject, text, html }. */
  function normalize(email) {
    const subject = email.subject || "";
    const html = email.html || (email.body && /<[a-z][\s\S]*>/i.test(email.body) ? email.body : "") || "";
    let text = email.text || "";
    if (!text) text = html ? stripHtml(html) : email.body || "";
    return { subject, text, html };
  }

  /** OTP-код: \b\d{4,8}\b с учётом контекстных слов и длины. */
  function extractOtp(email) {
    const n = normalize(email);
    const hay = `${n.subject}\n${n.text}`;
    const re = /\b(\d{4,8})\b/g;
    let m;
    const cands = [];
    while ((m = re.exec(hay))) cands.push({ value: m[1], index: m.index });
    if (!cands.length) return null;

    function score(c) {
      let s = 0;
      const win = hay.slice(Math.max(0, c.index - 40), c.index + c.value.length + 40);
      if (CONTEXT_RE.test(win)) s += 100;
      const len = c.value.length;
      s += { 6: 6, 5: 4, 4: 3, 8: 2, 7: 1 }[len] || 0;
      const num = parseInt(c.value, 10);
      if (len === 4 && num >= 1900 && num <= 2099) s -= 5; // похоже на год
      return s;
    }
    cands.sort((a, b) => score(b) - score(a));
    // если у лучшего нет контекста и он один — всё равно вернём (best effort),
    // но если контекста нет ни у кого и кандидатов много, доверять нельзя
    const best = cands[0];
    const bestHasCtx = CONTEXT_RE.test(
      hay.slice(Math.max(0, best.index - 40), best.index + best.value.length + 40)
    );
    if (!bestHasCtx && cands.length > 3) return null;
    return best.value;
  }

  /** Все http(s)-ссылки из письма. */
  function extractLinks(email) {
    const n = normalize(email);
    const urls = new Set();
    const hrefRe = /href\s*=\s*["']([^"']+)["']/gi;
    let m;
    while ((m = hrefRe.exec(n.html))) {
      const u = decodeEntities(m[1]);
      if (/^https?:\/\//i.test(u)) urls.add(u);
    }
    const urlRe = /https?:\/\/[^\s"'<>)\]]+/gi;
    for (const src of [n.text, n.html]) {
      while ((m = urlRe.exec(src))) urls.add(decodeEntities(m[0]));
    }
    return [...urls];
  }

  function linkScore(u) {
    let s = 0;
    if (LINK_PRIORITY_RE.test(u)) s += 100;
    if (LINK_DOWNRANK_RE.test(u)) s -= 80;
    return s;
  }

  function prioritizeLinks(links) {
    return links
      .slice()
      .filter((u) => !LINK_DOWNRANK_RE.test(u) || LINK_PRIORITY_RE.test(u))
      .sort((a, b) => linkScore(b) - linkScore(a));
  }

  /** Полный разбор письма. */
  function parse(email) {
    const otp = extractOtp(email);
    const all = extractLinks(email);
    const links = prioritizeLinks(all);
    const primaryLink = links.find((u) => LINK_PRIORITY_RE.test(u)) || links[0] || null;
    return { otp, links, primaryLink, hasVerification: !!(otp || primaryLink) };
  }

  NS.emailParser = { parse, extractOtp, extractLinks, prioritizeLinks, normalize, stripHtml };
})();
