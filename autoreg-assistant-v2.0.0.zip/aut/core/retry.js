/**
 * core/retry.js — экспоненциальный backoff для транзиентных ошибок.
 * 1с → 2с → 4с (×2), не больше maxRetries раз. Используется service worker.
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});
  const TRANSIENT = new Set(["network", "timeout", "rate_limit", "server", "provider_unavailable"]);

  const delay = (ms) => new Promise((r) => setTimeout(r, ms));

  function isTransient(err) {
    return !!(err && TRANSIENT.has(err.code));
  }

  /**
   * Выполняет fn с повторами при транзиентных ошибках.
   * opts: { retries, baseDelay, factor, maxDelay, shouldRetry, onRetry }
   */
  async function run(fn, opts = {}) {
    const {
      retries = 3,
      baseDelay = 1000,
      factor = 2,
      maxDelay = 8000,
      shouldRetry = isTransient,
      onRetry = null,
    } = opts;
    let attempt = 0;
    while (true) {
      try {
        return await fn(attempt);
      } catch (err) {
        if (!shouldRetry(err) || attempt >= retries) throw err;
        const d = Math.min(maxDelay, baseDelay * Math.pow(factor, attempt));
        if (onRetry) {
          try {
            onRetry(err, attempt, d);
          } catch {}
        }
        await delay(d);
        attempt++;
      }
    }
  }

  NS.retry = { run, delay, isTransient, TRANSIENT };
})();
