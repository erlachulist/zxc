/**
 * core/otp-detector.js — поиск полей для ввода кода на странице и вставка.
 * Поддерживает обычное поле и сегментированный OTP (несколько input по 1 символу).
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});
  const detector = NS.fieldDetector;
  const filler = NS.formFiller;

  function isVisible(el) {
    return el.getClientRects().length > 0 && !el.disabled && !el.readOnly;
  }

  function isCodeType(el) {
    const t = (el.getAttribute("type") || el.type || "text").toLowerCase();
    return ["text", "tel", "number", "password", ""].includes(t);
  }

  /** Набор односимвольных инпутов — сегментированный OTP. */
  function findSegmented() {
    const singles = [...document.querySelectorAll("input")].filter((el) => {
      if (!isVisible(el) || !isCodeType(el)) return false;
      const ml = parseInt(el.getAttribute("maxlength"), 10);
      return ml === 1;
    });
    if (singles.length >= 4 && singles.length <= 10) return singles.slice(0, 8);
    return null;
  }

  /** Одиночное поле, помеченное как code/otp/verif/pin. */
  function findSingle() {
    const cands = [...document.querySelectorAll("input")].filter((el) => {
      if (!isVisible(el) || !isCodeType(el)) return false;
      if ((el.getAttribute("type") || "").toLowerCase() === "password") return false;
      return detector.CODE_RE.test(detector.attrText(el));
    });
    // отфильтруем слишком длинные (обычные text-поля) — код короткий
    const byLen = cands.filter((el) => {
      const ml = parseInt(el.getAttribute("maxlength"), 10);
      return isNaN(ml) || ml <= 12;
    });
    return byLen[0] || cands[0] || null;
  }

  /** Определяет поле(я) для кода. Возвращает {type:'single'|'segmented', inputs:[]} | null */
  function find() {
    const seg = findSegmented();
    if (seg) return { type: "segmented", inputs: seg };
    const single = findSingle();
    if (single) return { type: "single", inputs: [single] };
    return null;
  }

  /** Вставляет код в найденное поле. Возвращает {filled, mode?} */
  function fillCode(code) {
    const target = find();
    if (!target) return { filled: false };
    const digits = String(code).trim().split("");

    if (target.type === "single") {
      filler.fillInput(target.inputs[0], String(code).trim());
      return { filled: true, mode: "single" };
    }

    const inputs = target.inputs;
    let n = 0;
    for (let i = 0; i < inputs.length && i < digits.length; i++) {
      const el = inputs[i];
      try {
        el.focus();
      } catch {}
      el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: digits[i] }));
      filler.setNativeValue(el, digits[i]);
      el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: digits[i] }));
      n++;
    }
    return { filled: true, mode: "segmented", count: n };
  }

  NS.otpDetector = { find, fillCode, findSegmented, findSingle };
})();
