/**
 * core/field-detector.js — распознавание полей формы (email / username /
 * password / confirm) по типам и текстовым признакам. Латиница + кириллица.
 * Чистая работа с DOM, без запросов. Используется в content-скриптах.
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});

  const EMAIL_RE = /(e[-_]?mail|почт|электрон)/i;
  const USERNAME_RE = /(user[-_]?name|user\b|login|nick|handle|логин|никнейм|псевдоним|имя пользоват)/i;
  const CONFIRM_RE = /(confirm|verif|repeat|again|re[-_]?type|re[-_]?enter|2|повтор|подтвер|ещё раз|еще раз)/i;
  const CODE_RE = /(otp|one[-_ ]?time|\bcode\b|verif|confirm|pin|token|\bsms\b|код|подтвержд)/i;

  /** Все текстовые признаки поля: name, id, placeholder, autocomplete, label. */
  function attrText(input) {
    const parts = [
      input.name,
      input.id,
      input.placeholder,
      input.getAttribute && input.getAttribute("autocomplete"),
      input.getAttribute && input.getAttribute("aria-label"),
      input.getAttribute && input.getAttribute("data-testid"),
      input.className,
    ];
    if (input.labels) for (const label of input.labels) parts.push(label.textContent);
    const wrapper = input.closest && input.closest("label");
    if (wrapper) parts.push((wrapper.textContent || "").slice(0, 80));
    return parts.filter(Boolean).join(" ").toLowerCase();
  }

  /** Поле видно и доступно для ввода. */
  function isFillable(input) {
    const type = (input.getAttribute && input.getAttribute("type") || input.type || "text").toLowerCase();
    if (!["text", "email", "password", "tel", "search", ""].includes(type)) return false;
    if (input.disabled || input.readOnly) return false;
    if (!input.getClientRects || !input.getClientRects().length) return false;
    return true;
  }

  function typeOf(input) {
    return (input.getAttribute && input.getAttribute("type") || input.type || "text").toLowerCase();
  }

  /** email / username / password / confirm / null */
  function classify(input) {
    const type = typeOf(input);
    if (type === "password") {
      return CONFIRM_RE.test(attrText(input)) ? "confirm" : "password";
    }
    const text = attrText(input);
    if (type === "email" || EMAIL_RE.test(text)) return "email";
    if (USERNAME_RE.test(text)) return "username";
    return null;
  }

  function collectFields(root) {
    const scope = root || document;
    const fields = { email: [], username: [], password: [], confirm: [] };
    for (const input of scope.querySelectorAll("input")) {
      if (!isFillable(input)) continue;
      const kind = classify(input);
      if (kind) fields[kind].push(input);
    }
    // Эвристика confirm: если два password-поля подряд и второй не помечен —
    // считаем его подтверждением.
    if (fields.password.length === 2 && fields.confirm.length === 0) {
      fields.confirm.push(fields.password.pop());
    }
    return fields;
  }

  /** Все email-поля страницы (для инлайн-кнопки и badge). */
  function emailFields(root) {
    const scope = root || document;
    const out = [];
    for (const input of scope.querySelectorAll("input")) {
      if (!isFillable(input)) continue;
      if (classify(input) === "email") out.push(input);
    }
    return out;
  }

  /** Есть ли хотя бы одно email-поле. */
  function hasEmailField(root) {
    return emailFields(root).length > 0;
  }

  /** Похоже ли на форму регистрации (email+пароль или два пароля). */
  function detectRegistrationForm(root) {
    const f = collectFields(root);
    const passwordCount = f.password.length + f.confirm.length;
    return (f.email.length > 0 && passwordCount > 0) || f.confirm.length > 0 || passwordCount >= 2;
  }

  /** Текст рядом с полем/формой — для извлечения требований к паролю. */
  function nearbyText(input) {
    const form = (input.closest && (input.closest("form") || input.closest("div,section"))) || input.parentElement;
    if (!form) return "";
    return (form.textContent || "").replace(/\s+/g, " ").slice(0, 600).toLowerCase();
  }

  NS.fieldDetector = {
    EMAIL_RE,
    USERNAME_RE,
    CONFIRM_RE,
    CODE_RE,
    attrText,
    isFillable,
    typeOf,
    classify,
    collectFields,
    emailFields,
    hasEmailField,
    detectRegistrationForm,
    nearbyText,
  };
})();
