/**
 * core/password-generator.js — генератор паролей, читающий требования поля.
 *
 * Стратегия:
 *  1. Собрать ограничения полей: minlength, maxlength, pattern.
 *  2. Подобрать длину в диапазоне 14–16 (или под min/max поля).
 *  3. Если есть pattern — «генерируй-и-проверяй» до 10 раз; при неудаче
 *     fallback на алфавит, выведенный из самого pattern.
 *  4. Учесть текстовые подсказки рядом с формой (at least N, symbols…).
 *
 * Работает в content-скрипте и в service worker (только crypto.getRandomValues).
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});

  const LOWER = "abcdefghijklmnopqrstuvwxyz";
  const UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const DIGITS = "0123456789";
  const SPECIAL = "!@#$%^&*";
  const DEFAULT_CHARSET = LOWER + UPPER + DIGITS + SPECIAL;

  /** Равномерное случайное целое [0, max) без модульного смещения. */
  function randInt(max) {
    if (max <= 0) return 0;
    const limit = 4294967296 - (4294967296 % max);
    const buf = new Uint32Array(1);
    let x;
    do {
      crypto.getRandomValues(buf);
      x = buf[0];
    } while (x >= limit);
    return x % max;
  }

  function shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = randInt(i + 1);
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  /** Категории символов, реально присутствующие в наборе. */
  function categorize(charset) {
    const cats = [];
    const l = [...charset].filter((c) => LOWER.includes(c));
    const u = [...charset].filter((c) => UPPER.includes(c));
    const d = [...charset].filter((c) => DIGITS.includes(c));
    const s = [...charset].filter((c) => !/[a-z0-9]/i.test(c));
    for (const g of [l, u, d, s]) if (g.length) cats.push(g);
    return cats;
  }

  /** Строит пароль длины len из charset, гарантируя по одному символу из каждой категории. */
  function buildFromCharset(len, charset) {
    const set = charset && charset.length ? charset : DEFAULT_CHARSET;
    const chars = [];
    for (const cat of categorize(set)) chars.push(cat[randInt(cat.length)]);
    while (chars.length < len) chars.push(set[randInt(set.length)]);
    chars.length = len; // на случай очень короткой длины
    return shuffle(chars).join("");
  }

  /** Выбирает длину пароля с учётом min/max поля; база 14–16. */
  function pickLength(min, max) {
    let lo = 14;
    let hi = 16;
    if (min != null && min > lo) {
      lo = min;
      hi = Math.max(hi, min + 2);
    }
    if (max != null) hi = Math.min(hi, max);
    if (max != null && lo > max) lo = max;
    if (hi < lo) hi = lo;
    if (min != null && lo < min) lo = min;
    if (hi < lo) hi = lo;
    return lo + randInt(hi - lo + 1);
  }

  /** Раскрывает содержимое класса [...] в набор символов (диапазоны a-z, 0-9). */
  function expandClass(body) {
    const out = new Set();
    for (let i = 0; i < body.length; i++) {
      if (body[i] === "\\") {
        const n = body[i + 1];
        if (n === "d") DIGITS.split("").forEach((c) => out.add(c));
        else if (n === "w") (LOWER + UPPER + DIGITS + "_").split("").forEach((c) => out.add(c));
        else if (n) out.add(n);
        i++;
        continue;
      }
      if (body[i + 1] === "-" && body[i + 2] && body[i + 2] !== "]") {
        const start = body.charCodeAt(i);
        const end = body.charCodeAt(i + 2);
        if (end - start > 0 && end - start < 100) {
          for (let c = start; c <= end; c++) out.add(String.fromCharCode(c));
        }
        i += 2;
        continue;
      }
      out.add(body[i]);
    }
    return [...out];
  }

  /** Best-effort алфавит, выведенный из pattern (для fallback-генерации). */
  function charsetFromPattern(pattern) {
    const out = new Set();
    const classRe = /\[([^\]]+)\]/g;
    let m;
    while ((m = classRe.exec(pattern))) expandClass(m[1]).forEach((c) => out.add(c));
    if (/\\d/.test(pattern)) DIGITS.split("").forEach((c) => out.add(c));
    if (/\\w/.test(pattern)) (LOWER + UPPER + DIGITS).split("").forEach((c) => out.add(c));
    // одиночные литеральные символы вне метасимволов
    for (const ch of pattern.replace(/\[[^\]]*\]/g, "")) {
      if (/[a-z0-9!@#$%^&*]/i.test(ch)) out.add(ch);
    }
    const arr = [...out].filter((c) => /\S/.test(c));
    return arr.length >= 4 ? arr.join("") : null;
  }

  /**
   * Сбор ограничений из набора password-полей (включая confirm с другим maxlength).
   * min = максимум из minlength (чтобы удовлетворить всех), max = минимум из maxlength.
   */
  function collectConstraints(inputs) {
    let minLength = null;
    let maxLength = null;
    let pattern = null;
    for (const el of inputs || []) {
      const mn = parseInt(el.getAttribute && el.getAttribute("minlength"), 10);
      const mx = parseInt(el.getAttribute && el.getAttribute("maxlength"), 10);
      const pt = el.getAttribute && el.getAttribute("pattern");
      if (!isNaN(mn) && mn > 0) minLength = minLength == null ? mn : Math.max(minLength, mn);
      if (!isNaN(mx) && mx > 0) maxLength = maxLength == null ? mx : Math.min(maxLength, mx);
      if (pt && !pattern) pattern = pt;
    }
    return { minLength, maxLength, pattern };
  }

  /** Извлекает жёсткие требования из текста рядом с формой (best effort). */
  function parseTextRequirements(text) {
    const out = {};
    if (!text) return out;
    const t = text.toLowerCase();
    let m =
      t.match(/at least\s+(\d{1,2})\s*(characters|symbols|chars|знак|символ)/) ||
      t.match(/(minimum|min\.?)\s+(\d{1,2})\s*(characters|symbols)/) ||
      t.match(/не менее\s+(\d{1,2})\s*(символ|знак)/) ||
      t.match(/(\d{1,2})\+?\s*(characters|symbols)\s*(minimum|min|or more)/);
    if (m) {
      const num = parseInt(m[1] && /^\d+$/.test(m[1]) ? m[1] : m[2], 10);
      if (!isNaN(num) && num > 0 && num <= 64) out.minLength = num;
    }
    out.needSpecial = /special character|special symbol|спецсимвол|symbol/.test(t);
    out.needNumber = /number|digit|цифр/.test(t);
    out.needUpper = /uppercase|capital|заглавн|прописн/.test(t);
    return out;
  }

  /**
   * Основная генерация по собранным ограничениям.
   * constraints: { minLength, maxLength, pattern, textHint? }
   */
  function generate(constraints = {}) {
    let { minLength, maxLength, pattern } = constraints;
    const hint = constraints.textHint;
    if (hint && hint.minLength) {
      minLength = minLength == null ? hint.minLength : Math.max(minLength, hint.minLength);
      if (maxLength != null && minLength > maxLength) minLength = maxLength;
    }

    let re = null;
    if (pattern) {
      try {
        re = new RegExp("^(?:" + pattern + ")$");
      } catch {
        re = null;
      }
    }

    if (!re) return buildFromCharset(pickLength(minLength, maxLength), DEFAULT_CHARSET);

    for (let i = 0; i < 10; i++) {
      const pw = buildFromCharset(pickLength(minLength, maxLength), DEFAULT_CHARSET);
      if (re.test(pw)) return pw;
    }
    // fallback: набор из самого pattern
    const patCharset = charsetFromPattern(pattern) || DEFAULT_CHARSET;
    for (let i = 0; i < 10; i++) {
      const pw = buildFromCharset(pickLength(minLength, maxLength), patCharset);
      if (re.test(pw)) return pw;
    }
    return buildFromCharset(pickLength(minLength, maxLength), patCharset);
  }

  /** Удобный вход для content: массив password-полей + подсказка-текст. */
  function generateForFields(passwordInputs, textHint) {
    const c = collectConstraints(passwordInputs);
    c.textHint = textHint;
    return generate(c);
  }

  NS.passwordGenerator = {
    DEFAULT_CHARSET,
    randInt,
    generate,
    generateForFields,
    collectConstraints,
    parseTextRequirements,
  };
})();
