/**
 * core/form-filler.js — заполнение полей формы значениями.
 *
 * Ключевой момент: value ставится через нативный сеттер прототипа и
 * диспатчатся input/change — иначе React/Vue/Angular не заметят изменения.
 * Пароль генерируется здесь же, под требования password-полей страницы.
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});
  const detector = NS.fieldDetector;
  const passgen = NS.passwordGenerator;

  const nativeInputSetter = Object.getOwnPropertyDescriptor(
    HTMLInputElement.prototype,
    "value"
  );

  function setNativeValue(input, value) {
    if (nativeInputSetter && nativeInputSetter.set) nativeInputSetter.set.call(input, value);
    else input.value = value;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function highlight(input) {
    const prev = input.style.outline;
    const prevOffset = input.style.outlineOffset;
    input.style.outline = "2px solid #22c55e";
    input.style.outlineOffset = "1px";
    setTimeout(() => {
      input.style.outline = prev;
      input.style.outlineOffset = prevOffset;
    }, 1500);
  }

  function fillInput(input, value) {
    try {
      input.focus();
    } catch {}
    setNativeValue(input, value);
    // keyup помогает валидаторам, слушающим клавиатуру
    input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }));
    try {
      input.blur();
    } catch {}
    highlight(input);
  }

  /**
   * Заполняет форму. identity: { email, password?, username? }.
   * settings: { fillMode, addUsername }. Возвращает отчёт + фактический пароль.
   */
  function fillForm(identity, settings) {
    const opts = settings || {};
    const fillMode = opts.fillMode || "full";
    const withPassword = fillMode === "email+password" || fillMode === "full";
    const withUsername = fillMode === "full" && opts.addUsername !== false;

    const fields = detector.collectFields();
    const pwInputs = [...fields.password, ...fields.confirm];

    let password = identity.password || "";
    if (withPassword && pwInputs.length) {
      const hint = passgen.parseTextRequirements(detector.nearbyText(pwInputs[0]));
      password = passgen.generateForFields(pwInputs, hint);
    }

    let email = 0;
    let pw = 0;
    let username = 0;

    for (const input of fields.email) {
      fillInput(input, identity.email);
      email++;
    }
    if (withPassword) {
      for (const input of pwInputs) {
        fillInput(input, password);
        pw++;
      }
    }
    if (withUsername && identity.username) {
      for (const input of fields.username) {
        fillInput(input, identity.username);
        username++;
      }
    }

    return {
      filled: { email, password: pw, username, total: email + pw + username },
      password,
      url: location.href,
      title: document.title,
    };
  }

  /** Заполняет только email-поля (контекстное меню «только email»). */
  function fillEmailOnly(email) {
    const fields = detector.emailFields();
    for (const input of fields) fillInput(input, email);
    return { filled: { email: fields.length, total: fields.length }, url: location.href, title: document.title };
  }

  NS.formFiller = { setNativeValue, fillInput, fillForm, fillEmailOnly };
})();
