/**
 * storage/store.js — типобезопасная обёртка над chrome.storage.local.
 * Единственная точка чтения/записи данных расширения.
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});
  const { KEYS, DEFAULT_SETTINGS, DEFAULT_PROVIDERS, newRecord } = NS.schema;

  async function get(key, fallback) {
    const obj = await chrome.storage.local.get(key);
    return obj[key] !== undefined ? obj[key] : fallback;
  }
  async function set(key, value) {
    await chrome.storage.local.set({ [key]: value });
    return value;
  }

  // --- Записи -------------------------------------------------------------

  async function getRecords() {
    const list = await get(KEYS.RECORDS, []);
    return Array.isArray(list) ? list : [];
  }
  async function saveRecords(list) {
    return set(KEYS.RECORDS, Array.isArray(list) ? list : []);
  }
  async function addRecord(record) {
    const list = await getRecords();
    list.unshift(record);
    await saveRecords(list);
    return record;
  }
  async function getRecord(id) {
    return (await getRecords()).find((r) => r.id === id) || null;
  }
  /** Частичное обновление записи; updatedAt проставляется автоматически. */
  async function updateRecord(id, patch) {
    const list = await getRecords();
    const rec = list.find((r) => r.id === id);
    if (!rec) return null;
    Object.assign(rec, typeof patch === "function" ? patch(rec) : patch);
    rec.updatedAt = Date.now();
    await saveRecords(list);
    return rec;
  }
  async function deleteRecord(id) {
    const list = await getRecords();
    await saveRecords(list.filter((r) => r.id !== id));
  }
  /** Добавляет запись в attempts[] и обновляет updatedAt. */
  async function pushAttempt(id, entry) {
    return updateRecord(id, (rec) => ({ attempts: [...(rec.attempts || []), entry] }));
  }

  // --- Настройки ----------------------------------------------------------

  async function getSettings() {
    const saved = await get(KEYS.SETTINGS, {});
    return { ...DEFAULT_SETTINGS, ...(saved || {}) };
  }
  async function saveSettings(patch) {
    const merged = { ...(await getSettings()), ...(patch || {}) };
    return set(KEYS.SETTINGS, merged);
  }

  // --- Чёрный список доменов почты для сайта -----------------------------

  async function getBlacklist() {
    return (await get(KEYS.BLACKLIST, {})) || {};
  }
  async function getBlacklistFor(siteDomain) {
    const bl = await getBlacklist();
    return Array.isArray(bl[siteDomain]) ? bl[siteDomain] : [];
  }
  async function addBlacklistDomain(siteDomain, emailDomain) {
    if (!siteDomain || !emailDomain) return;
    const bl = await getBlacklist();
    const set0 = new Set(bl[siteDomain] || []);
    set0.add(String(emailDomain).toLowerCase());
    bl[siteDomain] = [...set0];
    await set(KEYS.BLACKLIST, bl);
  }

  // --- Провайдеры ---------------------------------------------------------

  async function getProvidersConfig() {
    const saved = await get(KEYS.PROVIDERS, {});
    return { ...DEFAULT_PROVIDERS, ...(saved || {}) };
  }
  async function saveProvidersConfig(patch) {
    const merged = { ...(await getProvidersConfig()), ...(patch || {}) };
    return set(KEYS.PROVIDERS, merged);
  }

  // --- Провайдер, успешный для сайта (perSiteSuccess) --------------------

  async function getSiteProvider(siteDomain) {
    const map = (await get(KEYS.SITE_PROVIDER, {})) || {};
    return map[siteDomain] || null;
  }
  async function setSiteProvider(siteDomain, providerName) {
    if (!siteDomain || !providerName) return;
    const map = (await get(KEYS.SITE_PROVIDER, {})) || {};
    map[siteDomain] = providerName;
    await set(KEYS.SITE_PROVIDER, map);
  }

  // --- «Текущая личность» (ожидает заполнения формы) ---------------------

  async function getPending() {
    return (await get(KEYS.PENDING, null)) || null;
  }
  async function setPending(identity) {
    return set(KEYS.PENDING, identity);
  }
  async function clearPending() {
    await chrome.storage.local.remove(KEYS.PENDING);
  }

  // --- Активные поллинги верификации -------------------------------------

  async function getPolling() {
    return (await get(KEYS.POLLING, {})) || {};
  }
  async function setPollingJob(recordId, job) {
    const map = await getPolling();
    map[recordId] = job;
    await set(KEYS.POLLING, map);
  }
  async function removePollingJob(recordId) {
    const map = await getPolling();
    delete map[recordId];
    await set(KEYS.POLLING, map);
  }

  // --- Индекс ротации провайдеров ----------------------------------------

  async function nextRotationIndex(mod) {
    const i = (await get(KEYS.ROTATION, 0)) || 0;
    const next = mod > 0 ? (i + 1) % mod : 0;
    await set(KEYS.ROTATION, next);
    return i % Math.max(1, mod);
  }

  NS.store = {
    get,
    set,
    getRecords,
    saveRecords,
    addRecord,
    getRecord,
    updateRecord,
    deleteRecord,
    pushAttempt,
    getSettings,
    saveSettings,
    getBlacklist,
    getBlacklistFor,
    addBlacklistDomain,
    getProvidersConfig,
    saveProvidersConfig,
    getSiteProvider,
    setSiteProvider,
    getPending,
    setPending,
    clearPending,
    getPolling,
    setPollingJob,
    removePollingJob,
    nextRotationIndex,
  };
})();
