/**
 * storage/schema.js — единая схема данных AutoReg Assistant.
 *
 * Загружается во всех контекстах (service worker через importScripts,
 * popup/options через <script>, content-скрипты через manifest).
 * Всё вешается на глобальный неймспейс globalThis.AutoReg, чтобы модули
 * видели друг друга без ES-import (расширение без сборки).
 */
;(function () {
  const NS = (globalThis.AutoReg = globalThis.AutoReg || {});

  /** Ключи в chrome.storage.local (префикс ar_). */
  const KEYS = {
    RECORDS: "ar_records",
    SETTINGS: "ar_settings",
    BLACKLIST: "ar_domainBlacklist",
    PROVIDERS: "ar_providers",
    SITE_PROVIDER: "ar_siteProvider",
    PENDING: "ar_pendingIdentity",
    POLLING: "ar_polling",
    CRYPTO: "ar_crypto",
    ROTATION: "ar_rotationIndex",
  };

  /** Статусы записи о регистрации. */
  const STATUS = {
    GENERATED: "generated",          // email создан, форма ещё не заполнена
    FORM_FILLED: "form_filled",      // поля заполнены на странице
    SUBMITTED: "submitted",          // форма отправлена
    PENDING: "pending_verification", // идёт поллинг почты
    VERIFIED: "verified",            // код/ссылка применены или найден success
    FAILED: "failed",                // таймаут/ошибка
  };

  /** Человекочитаемые подписи статусов (RU). */
  const STATUS_LABEL = {
    generated: "Создан email",
    form_filled: "Форма заполнена",
    submitted: "Отправлено",
    pending_verification: "Проверка почты",
    verified: "Подтверждён",
    failed: "Ошибка",
  };

  /** Настройки по умолчанию (раздел 6 ТЗ). */
  const DEFAULT_SETTINGS = {
    maxRetries: 3,
    retryBaseDelayMs: 1000,
    autoSubmit: false,
    pollingIntervalMs: 5000,
    pollingTimeoutMs: 5 * 60 * 1000,
    notifications: true,
    linkMode: "auto",                // auto | manual
    fillMode: "full",                // email | email+password | full
    autoDeleteDays: 0,               // 0 = не удалять
    providerStrategy: "rotation",    // rotation | random | perSiteSuccess
    addUsername: true,
    inlineButton: true,              // показывать инлайн-кнопку у полей
  };

  /** Конфиг провайдеров по умолчанию. */
  const DEFAULT_PROVIDERS = {
    disabled: [],   // имена отключённых встроенных провайдеров
    custom: [],     // массив JSON-конфигов кастомных провайдеров
    apiKeys: {},    // { providerName: "ключ" } для подстановки {{apiKey}}
  };

  function uuid() {
    if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
    // запасной вариант (RFC4122 v4)
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  /** Новая запись о регистрации со всеми полями схемы. */
  function newRecord(partial) {
    const now = Date.now();
    return Object.assign(
      {
        id: uuid(),
        domain: "",
        siteName: "",
        url: "",
        email: "",
        emailToken: "",
        providerName: "",
        password: "",
        username: "",
        status: STATUS.GENERATED,
        attempts: [],        // [{timestamp, error, domain}]
        tags: [],
        notes: "",
        verification: null,  // {otp, links[], appliedLink, message}
        encrypted: false,    // зашифрован ли password
        createdAt: now,
        updatedAt: now,
      },
      partial || {}
    );
  }

  /** Запись одной попытки в лог записи. */
  function attemptEntry(error, domain) {
    return { timestamp: Date.now(), error: String(error || ""), domain: String(domain || "") };
  }

  NS.schema = {
    KEYS,
    STATUS,
    STATUS_LABEL,
    DEFAULT_SETTINGS,
    DEFAULT_PROVIDERS,
    uuid,
    newRecord,
    attemptEntry,
  };
})();
