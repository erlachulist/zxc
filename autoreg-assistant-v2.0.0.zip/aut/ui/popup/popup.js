/* ui/popup/popup.js — журнал регистраций + действия в один клик. */
(function () {
  "use strict";
  const SCHEMA = globalThis.AutoReg.schema;
  const LABEL = SCHEMA.STATUS_LABEL;

  const state = { records: [], settings: {}, providers: [], crypto: { enabled: false, unlocked: false }, query: "", view: "list", currentId: null };

  // --- helpers -------------------------------------------------------------
  const $ = (s, r = document) => r.querySelector(s);

  function el(tag, props, ...kids) {
    const n = document.createElement(tag);
    if (props)
      for (const k in props) {
        const v = props[k];
        if (v == null) continue;
        if (k === "class") n.className = v;
        else if (k === "html") n.innerHTML = v;
        else if (k === "text") n.textContent = v;
        else if (k === "dataset") Object.assign(n.dataset, v);
        else if (k.startsWith("on") && typeof v === "function") n.addEventListener(k.slice(2).toLowerCase(), v);
        else n.setAttribute(k, v);
      }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      n.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return n;
  }

  const ICON = {
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
    eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>',
    eyeoff: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.9 4.2A9.1 9.1 0 0 1 12 4c6.5 0 10 7 10 7a13.2 13.2 0 0 1-2.2 3M6.6 6.6A13.2 13.2 0 0 0 2 11s3.5 7 10 7a9 9 0 0 0 4.2-1M3 3l18 18"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m2 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>',
    back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>',
    mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 5L2 7"/></svg>',
    link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>',
    key: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="4.5"/><path d="m10.5 12.5 8-8m-3 3 3 3m-6 0 3 3"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
  };
  const iconEl = (name) => el("span", { class: "i", html: ICON[name], style: "display:inline-flex;width:15px;height:15px" });

  function rpc(type, payload) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(Object.assign({ type }, payload || {}), (resp) => {
        const e = chrome.runtime.lastError;
        if (e) return reject(new Error(e.message));
        if (!resp) return reject(new Error("Нет ответа от расширения"));
        if (resp.ok === false) {
          const er = resp.error;
          return reject(new Error(typeof er === "string" ? er : (er && er.message) || "Ошибка"));
        }
        resolve(resp);
      });
    });
  }

  let toastTimer = null;
  function toast(text, ok = true) {
    const t = $("#toast");
    t.textContent = text;
    t.className = "toast show " + (ok ? "ok" : "err");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.className = "toast"), 2600);
  }

  async function copy(text) {
    try {
      await navigator.clipboard.writeText(String(text));
      toast("Скопировано");
    } catch {
      toast("Не удалось скопировать", false);
    }
  }

  function timeAgo(ts) {
    const s = Math.floor((Date.now() - ts) / 1000);
    if (s < 45) return "только что";
    if (s < 3600) return Math.floor(s / 60) + " мин назад";
    if (s < 86400) return Math.floor(s / 3600) + " ч назад";
    if (s < 604800) return Math.floor(s / 86400) + " дн назад";
    return new Date(ts).toLocaleDateString("ru-RU");
  }
  const fmtDate = (ts) => new Date(ts).toLocaleString("ru-RU", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });

  function download(filename, text, mime) {
    const blob = new Blob([text], { type: mime || "application/json" });
    const url = URL.createObjectURL(blob);
    const a = el("a", { href: url, download: filename });
    document.body.append(a);
    a.click();
    setTimeout(() => {
      URL.revokeObjectURL(url);
      a.remove();
    }, 800);
  }

  function pill(status) {
    return el("span", { class: "pill", dataset: { status } }, el("span", { class: "dot" }), LABEL[status] || status);
  }

  // --- data ----------------------------------------------------------------
  async function reload() {
    const s = await rpc("GET_STATE");
    state.records = s.records || [];
    state.settings = s.settings || {};
    state.providers = s.providers || [];
    state.crypto = s.crypto || { enabled: false, unlocked: false };
  }

  async function loadContext() {
    const box = $("#ctx");
    box.innerHTML = "";
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab) return;
      let host = "";
      try {
        host = new URL(tab.url).hostname;
      } catch {}
      let form = null;
      try {
        form = await chrome.tabs.sendMessage(tab.id, { type: "GET_FORM_STATUS" });
      } catch {}
      if (form && form.hasEmail) {
        box.append(el("span", { class: "ok" }, "●"), el("span", {}, "Форма найдена на "), el("span", { class: "host" }, host));
      } else if (host) {
        box.append(el("span", { class: "no" }, "○"), el("span", { class: "host" }, host));
      }
    } catch {}
  }

  // --- список --------------------------------------------------------------
  function filtered() {
    const q = state.query.trim().toLowerCase();
    if (!q) return state.records;
    return state.records.filter((r) =>
      [r.siteName, r.domain, r.email, r.username, (r.tags || []).join(" "), r.notes].join(" ").toLowerCase().includes(q)
    );
  }

  function renderList() {
    const list = $("#list");
    list.innerHTML = "";
    const items = filtered();
    $("#count").textContent = state.records.length;
    if (!items.length) {
      list.append(
        el("div", { class: "empty" }, state.records.length ? "Ничего не найдено." : "Пока нет записей. Нажмите «Заполнить форму» на странице регистрации.")
      );
      return;
    }
    for (const r of items) {
      const row = el(
        "div",
        { class: "row", onclick: () => openDetail(r.id) },
        el("span", { class: "rdot", style: dotStyle(r.status) }),
        el("div", { class: "rmid" }, el("div", { class: "rsite" }, r.siteName || r.domain || "—"), el("div", { class: "rmail" }, r.email || "—")),
        el("div", { class: "rright" }, pill(r.status), el("span", { class: "rtime" }, timeAgo(r.updatedAt || r.createdAt)))
      );
      list.append(row);
    }
  }
  function dotStyle(status) {
    const c = {
      generated: "var(--slate)",
      form_filled: "var(--accent-2)",
      submitted: "var(--amber)",
      pending_verification: "var(--amber)",
      verified: "var(--green)",
      failed: "var(--red)",
    };
    return "background:" + (c[status] || "var(--slate)");
  }

  // --- детали --------------------------------------------------------------
  function copyLine(value, { masked = false, revealable = false, recordId = null } = {}) {
    const val = el("div", { class: "val" + (masked ? " masked" : "") }, masked ? "••••••••••" : value || "—");
    const btns = [];
    if (revealable) {
      let shown = false;
      const eye = el("button", { class: "icon-btn btn-sm", title: "Показать" }, iconEl("eye"));
      eye.addEventListener("click", async () => {
        if (shown) {
          val.textContent = "••••••••••";
          val.classList.add("masked");
          eye.innerHTML = "";
          eye.append(iconEl("eye"));
          shown = false;
          return;
        }
        try {
          const r = await rpc("DECRYPT_PASSWORD", { id: recordId });
          if (r.locked) return promptUnlock();
          val.textContent = r.password || "—";
          val.classList.remove("masked");
          eye.innerHTML = "";
          eye.append(iconEl("eyeoff"));
          shown = true;
        } catch (e) {
          toast(e.message, false);
        }
      });
      btns.push(eye);
    }
    const cp = el("button", { class: "icon-btn btn-sm", title: "Копировать" }, iconEl("copy"));
    cp.addEventListener("click", async () => {
      if (revealable) {
        try {
          const r = await rpc("DECRYPT_PASSWORD", { id: recordId });
          if (r.locked) return promptUnlock();
          copy(r.password);
        } catch (e) {
          toast(e.message, false);
        }
      } else copy(value);
    });
    btns.push(cp);
    return el("div", { class: "copyline" }, val, ...btns);
  }

  function promptUnlock() {
    toast("Разблокируйте пароли мастер-паролем", false);
    const body = $("#view-detail .dt-body");
    if (!body || $("#unlock-box")) return;
    const inp = el("input", { class: "input", type: "password", placeholder: "Мастер-пароль" });
    const box = el(
      "div",
      { id: "unlock-box", class: "field fade-in" },
      el("span", { class: "eyebrow" }, "Разблокировать пароли"),
      el(
        "div",
        { class: "unlock" },
        inp,
        el(
          "button",
          {
            class: "btn btn-primary btn-sm",
            onclick: async () => {
              try {
                await rpc("CRYPTO_UNLOCK", { password: inp.value });
                state.crypto.unlocked = true;
                toast("Разблокировано");
                openDetail(state.currentId);
              } catch (e) {
                toast(e.message, false);
              }
            },
          },
          "OK"
        )
      )
    );
    body.prepend(box);
    inp.focus();
  }

  function verifyBlock(r) {
    const v = r.verification;
    if (!v || (!v.otp && !v.primaryLink)) return null;
    const box = el("div", { class: "verify" });
    if (v.otp) {
      box.append(
        el("div", { class: "vtitle" }, iconEl("key"), "Код подтверждения"),
        el(
          "div",
          { style: "display:flex;align-items:center;justify-content:space-between;gap:10px" },
          el("span", { class: "code-big" }, v.otp),
          el("button", { class: "btn btn-sm", onclick: () => copy(v.otp) }, iconEl("copy"), "Копировать")
        )
      );
    }
    if (v.primaryLink) {
      box.append(
        el("div", { class: "vtitle", style: v.otp ? "margin-top:10px" : "" }, iconEl("link"), "Ссылка подтверждения"),
        el(
          "button",
          {
            class: "btn btn-sm",
            style: "width:100%",
            onclick: async () => {
              try {
                await rpc("OPEN_LINK", { url: v.primaryLink, recordId: r.id });
                toast("Ссылка открыта");
                setTimeout(refreshDetail, 400);
              } catch (e) {
                toast(e.message, false);
              }
            },
          },
          iconEl("link"),
          "Открыть ссылку"
        )
      );
    }
    return box;
  }

  function tagsField(r) {
    const wrap = el("div", { class: "tags-input" });
    function paint() {
      wrap.innerHTML = "";
      for (const t of r.tags || []) {
        wrap.append(
          el(
            "span",
            { class: "tag" },
            t,
            el("button", {
              title: "Удалить",
              text: "×",
              onclick: async () => {
                r.tags = (r.tags || []).filter((x) => x !== t);
                await rpc("UPDATE_RECORD", { id: r.id, tags: r.tags });
                paint();
              },
            })
          )
        );
      }
      const inp = el("input", {
        class: "input",
        style: "flex:1 1 90px;min-width:90px;padding:5px 8px;font-size:12px",
        placeholder: "+ тег",
        onkeydown: async (e) => {
          if (e.key !== "Enter") return;
          const val = inp.value.trim();
          if (!val) return;
          r.tags = [...new Set([...(r.tags || []), val])];
          await rpc("UPDATE_RECORD", { id: r.id, tags: r.tags });
          paint();
        },
      });
      wrap.append(inp);
    }
    paint();
    return wrap;
  }

  function renderDetail(r) {
    const root = $("#view-detail");
    root.innerHTML = "";

    const head = el(
      "div",
      { class: "dt-hd" },
      el("button", { class: "icon-btn", title: "Назад", onclick: goList }, iconEl("back")),
      el("div", { class: "dt-title" }, el("div", { class: "dt-site" }, r.siteName || r.domain || "—"), el("div", { class: "dt-url" }, r.url || r.domain || "")),
      pill(r.status)
    );

    const body = el("div", { class: "dt-body" });

    // email
    body.append(el("div", { class: "field" }, el("span", { class: "eyebrow" }, "Email"), copyLine(r.email)));
    // password
    if (r.password)
      body.append(
        el(
          "div",
          { class: "field" },
          el("span", { class: "eyebrow" }, r.encrypted ? "Пароль · зашифрован" : "Пароль"),
          copyLine(r.password, { masked: true, revealable: true, recordId: r.id })
        )
      );
    // username
    if (r.username) body.append(el("div", { class: "field" }, el("span", { class: "eyebrow" }, "Имя пользователя"), copyLine(r.username)));

    // meta
    body.append(
      el(
        "div",
        { class: "kv" },
        el("span", { class: "k" }, "Провайдер"),
        el("span", { class: "v" }, r.providerName || "—"),
        el("span", { class: "k" }, "Создано"),
        el("span", { class: "v" }, fmtDate(r.createdAt)),
        el("span", { class: "k" }, "Обновлено"),
        el("span", { class: "v" }, fmtDate(r.updatedAt || r.createdAt))
      )
    );

    // verification
    const vb = verifyBlock(r);
    if (vb) body.append(el("div", { class: "field" }, el("span", { class: "eyebrow" }, "Верификация"), vb));

    // check mail
    const mailBox = el("div", { class: "field" });
    const checkBtn = el(
      "button",
      {
        class: "btn btn-sm",
        style: "width:100%",
        onclick: async () => {
          checkBtn.disabled = true;
          checkBtn.textContent = "Проверяю…";
          try {
            const res = await rpc("CHECK_INBOX", { providerName: r.providerName, token: r.emailToken });
            renderMails(mailsHost, res.emails || [], r);
          } catch (e) {
            toast(e.message, false);
          }
          checkBtn.disabled = false;
          checkBtn.innerHTML = "";
          checkBtn.append(iconEl("mail"), document.createTextNode("Проверить почту"));
        },
      },
      iconEl("mail"),
      "Проверить почту"
    );
    const mailsHost = el("div", { style: "margin-top:8px" });
    mailBox.append(el("span", { class: "eyebrow" }, "Входящие"), checkBtn, mailsHost);
    body.append(mailBox);

    // tags
    body.append(el("div", { class: "field" }, el("span", { class: "eyebrow" }, "Теги"), tagsField(r)));

    // notes
    const notes = el("textarea", { class: "textarea", placeholder: "Заметки…" });
    notes.value = r.notes || "";
    notes.addEventListener("change", async () => {
      try {
        await rpc("UPDATE_RECORD", { id: r.id, notes: notes.value });
        toast("Сохранено");
      } catch (e) {
        toast(e.message, false);
      }
    });
    body.append(el("div", { class: "field" }, el("span", { class: "eyebrow" }, "Заметки"), notes));

    // timeline
    if ((r.attempts || []).length) {
      const tl = el("div", { class: "timeline" });
      for (const a of r.attempts) tl.append(el("div", { class: "tl" }, el("span", { class: "tl-dot" }), el("div", {}, el("div", { class: "tl-txt" }, a.error), el("div", { class: "tl-time" }, fmtDate(a.timestamp)))));
      body.append(el("div", { class: "field" }, el("span", { class: "eyebrow" }, "История"), tl));
    }

    // delete
    body.append(
      el(
        "div",
        { class: "dt-actions" },
        el(
          "button",
          {
            class: "btn btn-danger",
            onclick: async () => {
              try {
                await rpc("DELETE_RECORD", { id: r.id });
                await reload();
                goList();
                toast("Запись удалена");
              } catch (e) {
                toast(e.message, false);
              }
            },
          },
          iconEl("trash"),
          "Удалить запись"
        )
      )
    );

    root.append(head, body);
  }

  function renderMails(host, emails, r) {
    host.innerHTML = "";
    if (!emails.length) {
      host.append(el("div", { class: "empty", style: "padding:14px" }, "Писем пока нет."));
      return;
    }
    for (const m of emails) {
      const card = el("div", { class: "mail" }, el("div", { class: "msub" }, m.subject || "(без темы)"), el("div", { class: "mfrom" }, m.from || ""));
      if (m.otp)
        card.append(
          el(
            "div",
            { style: "display:flex;align-items:center;justify-content:space-between;gap:8px" },
            el("span", { class: "motp" }, m.otp),
            el("button", { class: "btn btn-sm", onclick: () => copy(m.otp) }, "Копировать")
          )
        );
      if (m.primaryLink)
        card.append(
          el(
            "button",
            {
              class: "btn btn-sm",
              style: "margin-top:6px;width:100%",
              onclick: () => rpc("OPEN_LINK", { url: m.primaryLink, recordId: r.id }).then(() => toast("Ссылка открыта")).catch((e) => toast(e.message, false)),
            },
            iconEl("link"),
            "Открыть ссылку"
          )
        );
      host.append(card);
    }
  }

  function refreshDetail() {
    reload().then(() => {
      const r = state.records.find((x) => x.id === state.currentId);
      if (r) renderDetail(r);
    });
  }

  // --- навигация -----------------------------------------------------------
  function openDetail(id) {
    const r = state.records.find((x) => x.id === id);
    if (!r) return;
    state.view = "detail";
    state.currentId = id;
    renderDetail(r);
    $("#view-list").classList.add("hidden");
    const d = $("#view-detail");
    d.classList.remove("hidden");
    d.classList.add("fade-in");
  }
  function goList() {
    state.view = "list";
    state.currentId = null;
    $("#view-detail").classList.add("hidden");
    $("#view-list").classList.remove("hidden");
    renderList();
  }

  // --- действия ------------------------------------------------------------
  async function doFill() {
    const btn = $("#btn-fill");
    btn.disabled = true;
    try {
      const res = await rpc("FILL_ACTIVE_TAB");
      await reload();
      renderList();
      toast("Заполнено: " + (res.email || "готово"));
      if (res.recordId) openDetail(res.recordId);
    } catch (e) {
      toast(e.message, false);
    }
    btn.disabled = false;
  }

  async function doGenerate() {
    const btn = $("#btn-gen");
    btn.disabled = true;
    try {
      const res = await rpc("POPUP_GENERATE");
      await reload();
      renderList();
      if (res.record) {
        toast("Создан email: " + res.record.email);
        openDetail(res.record.id);
      }
    } catch (e) {
      toast(e.message, false);
    }
    btn.disabled = false;
  }

  // --- init ----------------------------------------------------------------
  function wire() {
    $("#btn-fill").addEventListener("click", doFill);
    $("#btn-gen").addEventListener("click", doGenerate);
    $("#btn-settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
    $("#btn-options").addEventListener("click", () => chrome.runtime.openOptionsPage());
    $("#btn-export").addEventListener("click", () => {
      if (!state.records.length) return toast("Нет данных для экспорта", false);
      download("autoreg-records-" + Date.now() + ".json", JSON.stringify(state.records, null, 2));
      toast("Экспортировано " + state.records.length + " записей");
    });
    const search = $("#search");
    search.addEventListener("input", () => {
      state.query = search.value;
      renderList();
    });
  }

  (async function init() {
    wire();
    try {
      await reload();
    } catch (e) {
      toast("Ошибка загрузки: " + e.message, false);
    }
    renderList();
    loadContext();
  })();
})();
