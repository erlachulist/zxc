/* ui/options/options.js — полная страница настроек AutoReg. */
(function () {
  "use strict";
  const state = { settings: {}, providers: [], apiKeys: {}, records: [], crypto: { enabled: false, unlocked: false } };

  // --- helpers -------------------------------------------------------------
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  function el(tag, props, ...kids) {
    const n = document.createElement(tag);
    if (props)
      for (const k in props) {
        const v = props[k];
        if (v == null || v === false) continue;
        if (k === "class") n.className = v;
        else if (k === "html") n.innerHTML = v;
        else if (k === "text") n.textContent = v;
        else if (k === "dataset") Object.assign(n.dataset, v);
        else if (k.startsWith("on") && typeof v === "function") n.addEventListener(k.slice(2).toLowerCase(), v);
        else n.setAttribute(k, v);
      }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      n.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return n;
  }

  function rpc(type, payload) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(Object.assign({ type }, payload || {}), (resp) => {
        const e = chrome.runtime.lastError;
        if (e) return reject(new Error(e.message));
        if (!resp) return reject(new Error("Нет ответа от расширения"));
        if (resp.ok === false) {
          const er = resp.error;
          return reject(new Error(typeof er === "string" ? er : (er && er.message) || "Ошибка"));
        }
        resolve(resp);
      });
    });
  }

  let toastTimer = null;
  function toast(text, ok = true) {
    const t = $("#toast");
    t.textContent = text;
    t.className = "toast show " + (ok ? "ok" : "err");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.className = "toast"), 2800);
  }

  function download(filename, text, mime) {
    const blob = new Blob([text], { type: mime || "application/json" });
    const url = URL.createObjectURL(blob);
    const a = el("a", { href: url, download: filename });
    document.body.append(a);
    a.click();
    setTimeout(() => {
      URL.revokeObjectURL(url);
      a.remove();
    }, 800);
  }

  // --- контролы ------------------------------------------------------------
  function lineRow(title, sub, ctrl) {
    return el(
      "div",
      { class: "line" },
      el("div", { class: "line-txt" }, el("div", { class: "line-title" }, title), sub ? el("div", { class: "line-sub" }, sub) : null),
      el("div", { class: "line-ctrl" }, ...[].concat(ctrl))
    );
  }
  function switchCtrl(value, onChange) {
    const input = el("input", { type: "checkbox" });
    input.checked = !!value;
    input.addEventListener("change", () => onChange(input.checked));
    return el("label", { class: "switch" }, input, el("span", { class: "track" }));
  }
  function selectCtrl(options, value, onChange) {
    const s = el("select", { class: "select" });
    for (const o of options) {
      const opt = el("option", { value: o.value }, o.label);
      if (o.value === value) opt.selected = true;
      s.append(opt);
    }
    s.addEventListener("change", () => onChange(s.value));
    return s;
  }
  function numberCtrl(value, opts, onChange) {
    const inp = el("input", { class: "input num", type: "number" });
    inp.value = value;
    if (opts.min != null) inp.min = opts.min;
    if (opts.max != null) inp.max = opts.max;
    if (opts.step != null) inp.step = opts.step;
    inp.addEventListener("change", () => {
      let v = parseFloat(inp.value);
      if (isNaN(v)) v = opts.min || 0;
      onChange(v);
    });
    const parts = [inp];
    if (opts.suffix) parts.push(el("span", { class: "suffix" }, opts.suffix));
    return parts;
  }

  async function saveSetting(patch) {
    try {
      const r = await rpc("SAVE_SETTINGS", { patch });
      state.settings = r.settings;
      toast("Сохранено");
    } catch (e) {
      toast(e.message, false);
    }
  }

  // --- секции настроек -----------------------------------------------------
  function renderFill() {
    const g = $("#grp-fill");
    g.innerHTML = "";
    const s = state.settings;
    g.append(
      lineRow(
        "Что заполнять",
        "Набор полей, которые подставляет ассистент.",
        selectCtrl(
          [
            { value: "full", label: "Email + пароль + имя" },
            { value: "email+password", label: "Email + пароль" },
            { value: "email", label: "Только email" },
          ],
          s.fillMode,
          (v) => saveSetting({ fillMode: v })
        )
      ),
      lineRow("Заполнять имя пользователя", "Если на форме есть поле username.", switchCtrl(s.addUsername, (v) => saveSetting({ addUsername: v }))),
      lineRow("Показывать кнопку у полей", "Плавающая молния рядом с email-полем.", switchCtrl(s.inlineButton, (v) => saveSetting({ inlineButton: v }))),
      lineRow(
        "Автоотправка формы",
        "Нажимать «Отправить» автоматически. Осторожно: возможна CAPTCHA.",
        switchCtrl(s.autoSubmit, (v) => saveSetting({ autoSubmit: v }))
      )
    );
  }

  function renderVerify() {
    const g = $("#grp-verify");
    g.innerHTML = "";
    const s = state.settings;
    g.append(
      lineRow("Интервал опроса почты", "Как часто проверять входящие.", numberCtrl(Math.round(s.pollingIntervalMs / 1000), { min: 3, max: 60, step: 1, suffix: "сек" }, (v) => saveSetting({ pollingIntervalMs: Math.max(3000, v * 1000) }))),
      lineRow("Тайм-аут ожидания", "Сколько ждать письмо, прежде чем пометить ошибкой.", numberCtrl(Math.round(s.pollingTimeoutMs / 60000), { min: 1, max: 30, step: 1, suffix: "мин" }, (v) => saveSetting({ pollingTimeoutMs: Math.max(60000, v * 60000) }))),
      lineRow(
        "Ссылки подтверждения",
        "Открывать автоматически или показывать баннер.",
        selectCtrl(
          [
            { value: "auto", label: "Открывать автоматически" },
            { value: "manual", label: "Баннер для ручного клика" },
          ],
          s.linkMode,
          (v) => saveSetting({ linkMode: v })
        )
      ),
      lineRow("Уведомления", "Системные уведомления о кодах и результатах.", switchCtrl(s.notifications, (v) => saveSetting({ notifications: v })))
    );
  }

  function renderReliability() {
    const g = $("#grp-reliability");
    g.innerHTML = "";
    const s = state.settings;
    g.append(
      lineRow("Максимум повторов", "Сколько раз пробовать другой email при ошибке.", numberCtrl(s.maxRetries, { min: 0, max: 5, step: 1 }, (v) => saveSetting({ maxRetries: v }))),
      lineRow("Базовая задержка повтора", "Экспоненциальный backoff начинается с этого значения.", numberCtrl((s.retryBaseDelayMs / 1000).toFixed(1), { min: 0.5, max: 10, step: 0.5, suffix: "сек" }, (v) => saveSetting({ retryBaseDelayMs: Math.round(v * 1000) }))),
      lineRow(
        "Стратегия выбора провайдера",
        "Как чередовать сервисы временной почты.",
        selectCtrl(
          [
            { value: "rotation", label: "По кругу (rotation)" },
            { value: "random", label: "Случайно" },
            { value: "perSiteSuccess", label: "Успешный для сайта" },
          ],
          s.providerStrategy,
          (v) => saveSetting({ providerStrategy: v })
        )
      ),
      lineRow("Автоудаление старых записей", "Удалять записи со статусом «ошибка/создан» старше N дней.", numberCtrl(s.autoDeleteDays, { min: 0, max: 365, step: 1, suffix: "дн (0 = никогда)" }, (v) => saveSetting({ autoDeleteDays: v })))
    );
  }

  // --- провайдеры ----------------------------------------------------------
  function renderProviders() {
    const host = $("#provider-list");
    host.innerHTML = "";
    for (const p of state.providers) {
      const card = el("div", { class: "prov" });

      const test = el("button", { class: "btn btn-sm" }, "Тест");
      const testOut = el("div", { class: "prov-test-out" });
      test.addEventListener("click", async () => {
        test.disabled = true;
        test.textContent = "Проверяю…";
        testOut.className = "prov-test-out show";
        testOut.textContent = "Создаю тестовый ящик…";
        try {
          const r = await rpc("TEST_PROVIDER", { name: p.name });
          testOut.className = "prov-test-out show ok";
          testOut.textContent = "✓ " + r.email;
        } catch (e) {
          testOut.className = "prov-test-out show err";
          testOut.textContent = "✕ " + e.message;
        }
        test.disabled = false;
        test.textContent = "Тест";
      });

      const actions = el(
        "div",
        { class: "prov-actions" },
        test,
        !p.builtin
          ? el("button", {
              class: "btn btn-sm btn-danger",
              text: "Удалить",
              onclick: async () => {
                try {
                  await rpc("REMOVE_CUSTOM_PROVIDER", { name: p.name });
                  await reload();
                  renderProviders();
                  toast("Провайдер удалён");
                } catch (e) {
                  toast(e.message, false);
                }
              },
            })
          : null,
        switchCtrl(p.enabled, async (v) => {
          try {
            await rpc("TOGGLE_PROVIDER", { name: p.name, enabled: v });
            p.enabled = v;
          } catch (e) {
            toast(e.message, false);
          }
        })
      );

      const domains = (p.domains || []).length ? (p.domains || []).slice(0, 6).join(", ") : "домены назначает сервис";
      card.append(
        el(
          "div",
          { class: "prov-top" },
          el(
            "div",
            {},
            el("div", { class: "prov-name" }, p.name, el("span", { class: "badge " + (p.builtin ? "built" : "custom") }, p.builtin ? "встроенный" : "свой")),
            el("div", { class: "prov-domains" }, domains)
          ),
          actions
        )
      );

      // API-ключ для кастомных провайдеров, использующих {{apiKey}}
      if (!p.builtin && p.config && JSON.stringify(p.config).includes("{{apiKey}}")) {
        const keyInp = el("input", { class: "input", type: "password", placeholder: "API-ключ" });
        keyInp.value = state.apiKeys[p.name] || "";
        card.append(
          el(
            "div",
            { class: "prov-key show" },
            keyInp,
            el("button", {
              class: "btn btn-sm",
              text: "Сохранить ключ",
              onclick: async () => {
                try {
                  await rpc("SET_API_KEY", { name: p.name, key: keyInp.value });
                  state.apiKeys[p.name] = keyInp.value;
                  toast("Ключ сохранён");
                } catch (e) {
                  toast(e.message, false);
                }
              },
            })
          )
        );
      }

      card.append(testOut);
      host.append(card);
    }
  }

  const SAMPLE = {
    name: "my-tempmail",
    domains: ["example-mail.com"],
    createInbox: {
      url: "https://api.example-mail.com/inbox",
      method: "POST",
      headers: { Authorization: "Bearer {{apiKey}}" },
      body: {},
      responseMapping: { email: "data.address", token: "data.token" },
    },
    getMessages: {
      url: "https://api.example-mail.com/inbox/{{token}}/messages",
      method: "GET",
      headers: { Authorization: "Bearer {{apiKey}}" },
      responseMapping: { messages: "data.messages", id: "id", from: "from", subject: "subject", body: "text", html: "html", date: "createdAt" },
    },
  };

  // --- безопасность --------------------------------------------------------
  function renderSecurity() {
    const g = $("#grp-security");
    g.innerHTML = "";
    const c = state.crypto;

    if (!c.enabled) {
      const p1 = el("input", { class: "input", type: "password", placeholder: "Мастер-пароль" });
      const p2 = el("input", { class: "input", type: "password", placeholder: "Повторите пароль" });
      g.append(
        el(
          "div",
          { class: "line", style: "flex-direction:column;align-items:stretch;gap:10px" },
          el("div", { class: "line-txt" }, el("div", { class: "line-title" }, "Включить шифрование паролей"), el("div", { class: "line-sub" }, "Пароли будут храниться в зашифрованном виде (AES-GCM, ключ из мастер-пароля через PBKDF2). Мастер-пароль нигде не сохраняется — если забудете, восстановить пароли будет нельзя.")),
          el("div", { class: "sec-row" }, p1, p2),
          el(
            "div",
            { class: "sec-row" },
            el("button", {
              class: "btn btn-primary btn-sm",
              text: "Включить шифрование",
              onclick: async () => {
                if (!p1.value || p1.value.length < 4) return toast("Пароль слишком короткий (мин. 4)", false);
                if (p1.value !== p2.value) return toast("Пароли не совпадают", false);
                try {
                  await rpc("CRYPTO_SETUP", { password: p1.value });
                  await reload();
                  renderSecurity();
                  toast("Шифрование включено");
                } catch (e) {
                  toast(e.message, false);
                }
              },
            })
          )
        )
      );
      return;
    }

    // включено
    const statusTxt = c.unlocked ? "Разблокировано в этой сессии." : "Заблокировано — пароли скрыты.";
    g.append(lineRow("Статус", statusTxt, el("span", { class: "pill", dataset: { status: c.unlocked ? "verified" : "failed" } }, el("span", { class: "dot" }), c.unlocked ? "Разблокировано" : "Заблокировано")));

    if (!c.unlocked) {
      const up = el("input", { class: "input", type: "password", placeholder: "Мастер-пароль" });
      g.append(
        el(
          "div",
          { class: "line", style: "flex-direction:column;align-items:stretch;gap:10px" },
          el("div", { class: "line-txt" }, el("div", { class: "line-title" }, "Разблокировать")),
          el(
            "div",
            { class: "sec-row" },
            up,
            el("button", {
              class: "btn btn-primary btn-sm",
              text: "Разблокировать",
              onclick: async () => {
                try {
                  await rpc("CRYPTO_UNLOCK", { password: up.value });
                  await reload();
                  renderSecurity();
                  toast("Разблокировано");
                } catch (e) {
                  toast(e.message, false);
                }
              },
            })
          )
        )
      );
    } else {
      g.append(lineRow("Заблокировать пароли", "Скрыть пароли до следующего ввода мастер-пароля.", el("button", { class: "btn btn-sm", text: "Заблокировать", onclick: async () => { await rpc("CRYPTO_LOCK"); await reload(); renderSecurity(); toast("Заблокировано"); } })));
    }

    // отключение
    const dp = el("input", { class: "input", type: "password", placeholder: "Мастер-пароль для подтверждения" });
    g.append(
      el(
        "div",
        { class: "line", style: "flex-direction:column;align-items:stretch;gap:10px" },
        el("div", { class: "line-txt" }, el("div", { class: "line-title" }, "Отключить шифрование"), el("div", { class: "line-sub" }, "Пароли будут расшифрованы и сохранены как обычный текст.")),
        el(
          "div",
          { class: "sec-row" },
          dp,
          el("button", {
            class: "btn btn-sm btn-danger",
            text: "Отключить",
            onclick: async () => {
              try {
                await rpc("CRYPTO_DISABLE", { password: dp.value });
                await reload();
                renderSecurity();
                toast("Шифрование отключено");
              } catch (e) {
                toast(e.message, false);
              }
            },
          })
        )
      )
    );
  }

  // --- статистика ----------------------------------------------------------
  function renderStats() {
    const host = $("#stats");
    host.innerHTML = "";
    const recs = state.records;
    const LABEL = globalThis.AutoReg.schema.STATUS_LABEL;
    const byStatus = {};
    const byProvider = {};
    for (const r of recs) {
      byStatus[r.status] = (byStatus[r.status] || 0) + 1;
      if (r.providerName) byProvider[r.providerName] = (byProvider[r.providerName] || 0) + 1;
    }
    const total = recs.length;
    const verified = byStatus["verified"] || 0;
    const failed = byStatus["failed"] || 0;
    const pending = (byStatus["pending_verification"] || 0) + (byStatus["submitted"] || 0);
    const rate = total ? Math.round((verified / total) * 100) : 0;

    function stat(num, lbl) {
      return el("div", { class: "stat" }, el("div", { class: "num" }, num), el("div", { class: "lbl" }, lbl));
    }
    host.append(stat(total, "Всего записей"), stat(verified, "Подтверждено"), stat(pending, "В процессе"), stat(failed, "Ошибок"), stat(rate + "%", "Доля успеха"));

    if (total) {
      const maxS = Math.max(...Object.values(byStatus), 1);
      const bars = el("div", { class: "bars" });
      for (const st of Object.keys(LABEL)) {
        const n = byStatus[st] || 0;
        if (!n) continue;
        bars.append(el("div", { class: "bar-row" }, el("span", { class: "bl" }, LABEL[st]), el("div", { class: "bar-track" }, el("div", { class: "bar-fill", style: "width:" + Math.round((n / maxS) * 100) + "%" })), el("span", { class: "bn" }, n)));
      }
      host.append(el("div", { class: "stat wide" }, el("div", { class: "lbl", style: "margin-bottom:10px" }, "По статусам"), bars));

      if (Object.keys(byProvider).length) {
        const maxP = Math.max(...Object.values(byProvider), 1);
        const pbars = el("div", { class: "bars" });
        for (const [name, n] of Object.entries(byProvider).sort((a, b) => b[1] - a[1])) {
          pbars.append(el("div", { class: "bar-row" }, el("span", { class: "bl" }, name), el("div", { class: "bar-track" }, el("div", { class: "bar-fill", style: "width:" + Math.round((n / maxP) * 100) + "%" })), el("span", { class: "bn" }, n)));
        }
        host.append(el("div", { class: "stat wide" }, el("div", { class: "lbl", style: "margin-bottom:10px" }, "По провайдерам"), pbars));
      }
    } else {
      host.append(el("div", { class: "empty stat wide" }, "Данных пока нет."));
    }
  }

  // --- данные --------------------------------------------------------------
  function csvCell(v) {
    v = String(v == null ? "" : v);
    return /[",\r\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }
  async function exportKeePass() {
    if (!state.records.length) return toast("Нет данных для экспорта", false);
    const rows = [["Group", "Title", "Username", "Password", "URL"]];
    for (const r of state.records) {
      let pw = r.password || "";
      if (r.encrypted) {
        try {
          const d = await rpc("DECRYPT_PASSWORD", { id: r.id });
          if (d.locked) return toast("Разблокируйте пароли на вкладке «Безопасность»", false);
          pw = d.password || "";
        } catch (e) {
          return toast(e.message, false);
        }
      }
      rows.push(["AutoReg", r.siteName || r.domain || "", r.email || r.username || "", pw, r.url || (r.domain ? "https://" + r.domain : "")]);
    }
    const csv = rows.map((row) => row.map(csvCell).join(",")).join("\r\n");
    download("autoreg-keepass-" + Date.now() + ".csv", csv, "text/csv");
    toast("CSV для KeePass готов");
  }

  // --- данные / загрузка ---------------------------------------------------
  async function reload() {
    const s = await rpc("GET_STATE");
    state.settings = s.settings || {};
    state.providers = s.providers || [];
    state.apiKeys = s.apiKeys || {};
    state.records = s.records || [];
    state.crypto = s.crypto || { enabled: false, unlocked: false };
  }

  function renderAll() {
    renderFill();
    renderVerify();
    renderReliability();
    renderProviders();
    renderSecurity();
    renderStats();
  }

  function wire() {
    $$(".nav-item").forEach((btn) =>
      btn.addEventListener("click", () => {
        const tab = btn.dataset.tab;
        $$(".nav-item").forEach((b) => b.classList.toggle("active", b === btn));
        $$(".tab").forEach((s) => s.classList.toggle("active", s.dataset.tab === tab));
      })
    );

    $("#btn-sample").addEventListener("click", () => {
      $("#custom-json").value = JSON.stringify(SAMPLE, null, 2);
    });
    $("#btn-add-prov").addEventListener("click", async () => {
      const txt = $("#custom-json").value.trim();
      if (!txt) return toast("Вставьте JSON-конфиг", false);
      try {
        const r = await rpc("ADD_CUSTOM_PROVIDER", { config: txt });
        await reload();
        renderProviders();
        $("#custom-json").value = "";
        toast("Провайдер добавлен: " + r.name);
      } catch (e) {
        toast(e.message, false);
      }
    });

    $("#exp-json").addEventListener("click", () => {
      if (!state.records.length) return toast("Нет данных для экспорта", false);
      download("autoreg-records-" + Date.now() + ".json", JSON.stringify(state.records, null, 2));
      toast("Экспортировано " + state.records.length + " записей");
    });
    $("#exp-keepass").addEventListener("click", exportKeePass);
    $("#clear-all").addEventListener("click", async () => {
      if (!confirm("Удалить все записи журнала? Это действие необратимо.")) return;
      try {
        await rpc("CLEAR_RECORDS");
        await reload();
        renderStats();
        toast("Журнал очищен");
      } catch (e) {
        toast(e.message, false);
      }
    });
  }

  (async function init() {
    wire();
    try {
      await reload();
    } catch (e) {
      toast("Ошибка загрузки: " + e.message, false);
    }
    renderAll();
  })();
})();
