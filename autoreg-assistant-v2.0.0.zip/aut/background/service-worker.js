/**
 * background/service-worker.js — центральный воркер AutoReg Assistant.
 * Все сетевые запросы, хранилище, верификация (поллинг), ретраи, меню, badge.
 */

// Загружаем общие модули (пути — от корня расширения через getURL).
importScripts(
  chrome.runtime.getURL("storage/schema.js"),
  chrome.runtime.getURL("storage/store.js"),
  chrome.runtime.getURL("core/net.js"),
  chrome.runtime.getURL("core/crypto.js"),
  chrome.runtime.getURL("core/error-classifier.js"),
  chrome.runtime.getURL("core/email-parser.js"),
  chrome.runtime.getURL("core/password-generator.js"),
  chrome.runtime.getURL("core/retry.js"),
  chrome.runtime.getURL("providers/provider-interface.js"),
  chrome.runtime.getURL("providers/adapters.js"),
  chrome.runtime.getURL("providers/custom-parser.js"),
  chrome.runtime.getURL("providers/registry.js")
);

const NS = globalThis.AutoReg;
const { schema, store, net, registry, errorClassifier, emailParser } = NS;
const ApiError = net.ApiError;

const CONTENT_FILES = [
  "core/password-generator.js",
  "core/field-detector.js",
  "core/form-filler.js",
  "core/error-classifier.js",
  "core/otp-detector.js",
  "content/otp-autofill.js",
  "content/inline-button.js",
  "content/page-banner.js",
  "content/content.js",
];

const POLL_ALARM = "ar-poll";

function toErr(e) {
  if (e instanceof ApiError) return { code: e.code, message: e.message };
  return { code: (e && e.code) || "unknown", message: (e && e.message) || String(e) };
}

function usernameFromEmail(email) {
  const local = String(email).split("@")[0] || "";
  const clean = local.replace(/[^a-z0-9._-]/gi, "").slice(0, 20);
  return clean.length >= 4 ? clean : "user" + Math.floor(Math.random() * 90000 + 10000);
}

// --- Шифрование (опционально) --------------------------------------------
async function getCryptoMeta() {
  return (await chrome.storage.local.get("ar_crypto")).ar_crypto || { enabled: false };
}
async function getSessionMaster() {
  try {
    return (await chrome.storage.session.get("ar_master")).ar_master || null;
  } catch {
    return null;
  }
}
async function deriveSessionKey() {
  const meta = await getCryptoMeta();
  const master = await getSessionMaster();
  if (!meta.enabled || !master || !meta.salt) return null;
  return NS.crypto.deriveKey(master, meta.salt);
}
async function maybeEncrypt(plain) {
  if (!plain) return { value: plain || "", encrypted: false };
  const key = await deriveSessionKey();
  if (!key) return { value: plain, encrypted: false };
  return { value: await NS.crypto.encryptString(key, plain), encrypted: true };
}
async function maybeDecrypt(value) {
  if (!NS.crypto.isEncrypted(value)) return value;
  const key = await deriveSessionKey();
  if (!key) return null;
  try {
    return await NS.crypto.decryptString(key, value);
  } catch {
    return null;
  }
}
async function encryptAllExisting(key) {
  const list = await store.getRecords();
  for (const r of list) {
    if (r.password && !NS.crypto.isEncrypted(r.password)) {
      r.password = await NS.crypto.encryptString(key, r.password);
      r.encrypted = true;
    }
  }
  await store.saveRecords(list);
}
async function decryptAllExisting(key) {
  const list = await store.getRecords();
  for (const r of list) {
    if (NS.crypto.isEncrypted(r.password)) {
      try {
        r.password = await NS.crypto.decryptString(key, r.password);
        r.encrypted = false;
      } catch {}
    }
  }
  await store.saveRecords(list);
}

// --- Уведомления ----------------------------------------------------------
const notifData = new Map(); // notifId -> {recordId, link}
async function notify(title, message, recordId, extra) {
  const settings = await store.getSettings();
  if (!settings.notifications) return;
  try {
    const id = "ar-" + Date.now() + "-" + Math.random().toString(36).slice(2, 6);
    notifData.set(id, { recordId, link: extra && extra.link });
    chrome.notifications.create(id, {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon128.png"),
      title,
      message: String(message).slice(0, 300),
      priority: 1,
    });
  } catch {}
}
chrome.notifications.onClicked.addListener((id) => {
  const d = notifData.get(id);
  if (d && d.link) {
    chrome.tabs.create({ url: d.link, active: true }).catch(() => {});
    if (d.recordId) markVerified(d.recordId, d.link).catch(() => {});
  }
  chrome.notifications.clear(id);
});

// --- Связь с вкладкой -----------------------------------------------------
async function ensureContent(tabId) {
  try {
    const r = await chrome.tabs.sendMessage(tabId, { type: "PING" });
    if (r && r.pong) return true;
  } catch {}
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: CONTENT_FILES });
    return true;
  } catch {
    return false;
  }
}
async function sendToTab(tabId, msg) {
  return chrome.tabs.sendMessage(tabId, msg);
}
async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

// --- Badge ----------------------------------------------------------------
async function setBadge(tabId, on) {
  try {
    await chrome.action.setBadgeText({ tabId, text: on ? "@" : "" });
    if (on) {
      await chrome.action.setBadgeBackgroundColor({ tabId, color: "#2563eb" });
      if (chrome.action.setBadgeTextColor) await chrome.action.setBadgeTextColor({ tabId, color: "#ffffff" });
    }
  } catch {}
}
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status === "loading") chrome.action.setBadgeText({ tabId, text: "" }).catch(() => {});
});

// --- Верификация: поллинг --------------------------------------------------
let pollTimer = null;

async function ensureAlarm() {
  const jobs = await store.getPolling();
  if (Object.keys(jobs).length) {
    chrome.alarms.create(POLL_ALARM, { periodInMinutes: 0.5 });
  }
}
async function maybeClearAlarm() {
  const jobs = await store.getPolling();
  if (!Object.keys(jobs).length) {
    chrome.alarms.clear(POLL_ALARM).catch(() => {});
    if (pollTimer) {
      clearTimeout(pollTimer);
      pollTimer = null;
    }
  }
}

async function startPolling(recordId, tabId) {
  const rec = await store.getRecord(recordId);
  if (!rec || !rec.emailToken) return;
  const settings = await store.getSettings();
  await store.setPollingJob(recordId, {
    recordId,
    token: rec.emailToken,
    providerName: rec.providerName,
    domain: rec.domain,
    tabId: tabId != null ? tabId : null,
    deadline: Date.now() + (settings.pollingTimeoutMs || 300000),
    startedAt: Date.now(),
  });
  await store.updateRecord(recordId, { status: schema.STATUS.PENDING });
  await ensureAlarm();
  ensurePollLoop();
}

let pollBusy = false;
function ensurePollLoop() {
  if (pollTimer || pollBusy) return;
  pollTick();
}

async function pollTick() {
  if (pollBusy) return;
  pollBusy = true;
  pollTimer = null;
  try {
    await pollOnce();
  } finally {
    pollBusy = false;
  }
}

async function pollOnce() {
  const jobs = await store.getPolling();
  const ids = Object.keys(jobs);
  if (!ids.length) {
    await maybeClearAlarm();
    return;
  }
  const now = Date.now();
  for (const id of ids) {
    const job = jobs[id];
    if (now > job.deadline) {
      await failPolling(id, "таймаут: письмо не пришло за отведённое время");
      continue;
    }
    try {
      const emails = await registry.getMessages(job.providerName, job.token);
      if (emails && emails.length) await handleIncomingEmails(id, job, emails);
    } catch (e) {
      // транзиентная ошибка — продолжаем поллинг
    }
  }
  const settings = await store.getSettings();
  const left = await store.getPolling();
  if (Object.keys(left).length) {
    pollTimer = setTimeout(pollTick, Math.max(3000, settings.pollingIntervalMs || 5000));
  } else {
    await maybeClearAlarm();
  }
}

async function handleIncomingEmails(recordId, job, emails) {
  const rec = await store.getRecord(recordId);
  if (!rec) {
    await store.removePollingJob(recordId);
    return;
  }
  let found = null;
  for (const em of emails) {
    const p = emailParser.parse(em);
    if (p.hasVerification) {
      found = { parsed: p, email: em };
      break;
    }
  }
  if (!found) return; // письмо без кода/ссылки — ждём дальше

  await store.removePollingJob(recordId);
  const settings = await store.getSettings();
  const p = found.parsed;
  const verification = {
    otp: p.otp || null,
    links: (p.links || []).slice(0, 6),
    primaryLink: p.primaryLink || null,
    subject: found.email.subject || "",
  };

  if (p.otp) {
    await store.updateRecord(recordId, (r) => ({
      verification,
      attempts: [...(r.attempts || []), schema.attemptEntry("получен код: " + p.otp, r.domain)],
    }));
    await notify("Код подтверждения", "Код: " + p.otp, recordId);
    let filled = false;
    if (job.tabId != null) {
      try {
        const resp = await sendToTab(job.tabId, { type: "AUTOFILL_OTP", code: p.otp, recordId });
        filled = !!(resp && resp.filled);
      } catch {}
    }
    await store.updateRecord(recordId, {
      status: schema.STATUS.VERIFIED,
      verification: { ...verification, appliedOtp: filled },
    });
  } else if (p.primaryLink) {
    await store.updateRecord(recordId, (r) => ({
      verification,
      attempts: [...(r.attempts || []), schema.attemptEntry("найдена ссылка подтверждения", r.domain)],
    }));
    if (settings.linkMode === "manual") {
      await notify("Ссылка подтверждения", "Откройте ссылку, чтобы завершить регистрацию", recordId, {
        link: p.primaryLink,
      });
      if (job.tabId != null) {
        try {
          await sendToTab(job.tabId, { type: "SHOW_CONFIRM_BANNER", url: p.primaryLink, recordId });
        } catch {}
      }
      // статус станет verified после открытия ссылки (OPEN_LINK / клик по уведомлению)
    } else {
      await openConfirmLink(p.primaryLink, recordId);
      await notify("Регистрация подтверждена", "Ссылка открыта в фоновой вкладке", recordId);
    }
  }
  await maybeClearAlarm();
}

async function openConfirmLink(url, recordId) {
  try {
    await chrome.tabs.create({ url, active: false });
    await markVerified(recordId, url);
  } catch {}
}
async function markVerified(recordId, link) {
  if (!recordId) return;
  await store.updateRecord(recordId, (r) => ({
    status: schema.STATUS.VERIFIED,
    verification: { ...(r.verification || {}), appliedLink: link || (r.verification && r.verification.primaryLink) },
    attempts: [...(r.attempts || []), schema.attemptEntry("открыта ссылка подтверждения", r.domain)],
  }));
}

async function failPolling(recordId, reason) {
  await store.removePollingJob(recordId);
  await store.updateRecord(recordId, (r) => ({
    status: schema.STATUS.FAILED,
    attempts: [...(r.attempts || []), schema.attemptEntry(reason, r.domain)],
  }));
  await notify("Верификация не удалась", reason, recordId);
  await maybeClearAlarm();
}

// --- Ретраи после ошибки на странице --------------------------------------
async function retryWithNewEmail(rec, tabId, note) {
  const settings = await store.getSettings();
  const blacklist = rec.domain ? await store.getBlacklistFor(rec.domain) : [];
  let inbox;
  try {
    inbox = await registry.createInboxSmart({ siteDomain: rec.domain, blacklist, settings });
  } catch (err) {
    await store.updateRecord(rec.id, (r) => ({
      status: schema.STATUS.FAILED,
      attempts: [...(r.attempts || []), schema.attemptEntry("не удалось создать новый email: " + (err && err.message), r.domain)],
    }));
    if (tabId != null) sendToTab(tabId, { type: "SHOW_TOAST", ok: false, text: "Не удалось создать новый email." }).catch(() => {});
    return { retried: false };
  }
  const username = usernameFromEmail(inbox.email);
  await store.updateRecord(rec.id, (r) => ({
    email: inbox.email,
    emailToken: inbox.token,
    providerName: inbox.providerName,
    username,
    status: schema.STATUS.FORM_FILLED,
    retryCount: (r.retryCount || 0) + 1,
    attempts: [...(r.attempts || []), schema.attemptEntry(note + " → " + inbox.email + " (" + inbox.providerName + ")", inbox.domain)],
  }));
  if (tabId != null) {
    try {
      const resp = await sendToTab(tabId, { type: "REFILL", identity: { email: inbox.email, username }, settings, recordId: rec.id });
      if (resp && resp.password) {
        const enc = await maybeEncrypt(resp.password);
        await store.updateRecord(rec.id, { password: enc.value, encrypted: enc.encrypted });
      }
    } catch {}
  }
  return { retried: true };
}

async function handleErrorSubmitted(msg, sender) {
  const rec = await store.getRecord(msg.recordId);
  if (!rec) return { retried: false };
  const kind = msg.kind || "unknown";
  const tabId = sender && sender.tab && sender.tab.id;
  await store.pushAttempt(
    rec.id,
    schema.attemptEntry("ошибка на странице: " + kind + (msg.matchedText ? " (" + msg.matchedText + ")" : ""), rec.domain)
  );
  await store.removePollingJob(rec.id);
  await maybeClearAlarm();

  const settings = await store.getSettings();
  if ((rec.retryCount || 0) >= settings.maxRetries) {
    await store.updateRecord(rec.id, { status: schema.STATUS.FAILED });
    if (tabId != null) sendToTab(tabId, { type: "SHOW_TOAST", ok: false, text: "Регистрация не удалась после нескольких попыток." }).catch(() => {});
    return { retried: false };
  }

  if (kind === "domain_rejected") {
    const emailDomain = (rec.email.split("@")[1] || "").toLowerCase();
    if (rec.domain && emailDomain) await store.addBlacklistDomain(rec.domain, emailDomain);
    return retryWithNewEmail(rec, tabId, "домен отклонён, беру другой");
  }
  if (kind === "email_taken") return retryWithNewEmail(rec, tabId, "email занят, беру новый");
  if (kind === "rate_limit" || kind === "network" || kind === "provider_unavailable")
    return retryWithNewEmail(rec, tabId, "повтор с новым email");

  // unknown → пауза, сообщаем пользователю
  await store.updateRecord(rec.id, { status: schema.STATUS.FAILED });
  await notify("Нужна ручная проверка", "Сайт вернул непонятную ошибку регистрации.", rec.id);
  return { retried: false };
}

// --- Обработчик GENERATE_EMAIL --------------------------------------------
async function generateEmailForSite(msg) {
  const siteDomain = msg.siteDomain || "";
  const settings = await store.getSettings();
  const blacklist = siteDomain ? await store.getBlacklistFor(siteDomain) : [];
  const inbox = await registry.createInboxSmart({
    siteDomain,
    blacklist,
    settings,
    forceProvider: msg.forceProvider || null,
  });
  const username = usernameFromEmail(inbox.email);
  const rec = schema.newRecord({
    domain: siteDomain,
    siteName: (msg.title || "").slice(0, 80) || siteDomain,
    url: msg.url || "",
    email: inbox.email,
    emailToken: inbox.token,
    providerName: inbox.providerName,
    username,
    status: schema.STATUS.GENERATED,
  });
  rec.attempts.push(schema.attemptEntry("email создан (" + inbox.providerName + ", " + inbox.domain + ")", inbox.domain));
  await store.addRecord(rec);
  return {
    identity: { email: inbox.email, token: inbox.token, providerName: inbox.providerName, username },
    settings,
    recordId: rec.id,
  };
}

// --- Роутер сообщений -----------------------------------------------------
const handlers = {
  // content → фон
  GET_SETTINGS: async () => ({ settings: await store.getSettings() }),
  GENERATE_EMAIL: async (msg) => generateEmailForSite(msg),
  CANCEL_RECORD: async (msg) => {
    await store.deleteRecord(msg.recordId);
    return {};
  },
  FORM_FILLED: async (msg) => {
    const enc = await maybeEncrypt(msg.password || "");
    const rec = await store.getRecord(msg.recordId);
    await store.updateRecord(msg.recordId, (r) => ({
      status: schema.STATUS.FORM_FILLED,
      password: msg.emailOnly ? r.password : enc.value,
      encrypted: msg.emailOnly ? r.encrypted : enc.encrypted,
      attempts: [
        ...(r.attempts || []),
        schema.attemptEntry("форма заполнена (" + (msg.filled ? msg.filled.total : 0) + " полей)", rec ? rec.domain : ""),
      ],
    }));
    return {};
  },
  SUBMITTED: async (msg, sender) => {
    const rec = await store.getRecord(msg.recordId);
    if (!rec) return {};
    await store.updateRecord(rec.id, (r) => ({
      status: schema.STATUS.SUBMITTED,
      attempts: [...(r.attempts || []), schema.attemptEntry("форма отправлена, ждём письмо", r.domain)],
    }));
    await startPolling(rec.id, sender && sender.tab && sender.tab.id);
    return {};
  },
  ERROR_SUBMITTED: async (msg, sender) => handleErrorSubmitted(msg, sender),
  OPEN_LINK: async (msg) => {
    await openConfirmLink(msg.url, msg.recordId);
    return {};
  },
  FORM_STATUS: async (msg, sender) => {
    if (sender && sender.tab && sender.tab.id != null) await setBadge(sender.tab.id, !!msg.hasEmail);
    return {};
  },

  // popup / options
  GET_STATE: async () => ({
    records: await store.getRecords(),
    settings: await store.getSettings(),
    providers: await registry.allProvidersMeta(),
    apiKeys: (await store.getProvidersConfig()).apiKeys || {},
    crypto: { enabled: (await getCryptoMeta()).enabled === true, unlocked: !!(await getSessionMaster()) },
  }),
  POPUP_GENERATE: async (msg) => {
    const settings = await store.getSettings();
    const inbox = await registry.createInboxSmart({ siteDomain: "", settings, forceProvider: msg.forceProvider || null });
    const username = usernameFromEmail(inbox.email);
    const rec = schema.newRecord({
      domain: "",
      siteName: "Сгенерировано вручную",
      email: inbox.email,
      emailToken: inbox.token,
      providerName: inbox.providerName,
      username,
      status: schema.STATUS.GENERATED,
    });
    rec.attempts.push(schema.attemptEntry("email создан (" + inbox.providerName + ")", inbox.domain));
    await store.addRecord(rec);
    return { record: rec };
  },
  FILL_ACTIVE_TAB: async () => {
    const tab = await activeTab();
    if (!tab || tab.id == null) throw new ApiError("no_tab", "Нет активной вкладки.");
    const ok = await ensureContent(tab.id);
    if (!ok) throw new ApiError("page_unavailable", "Недоступно на этой странице (chrome://, магазин Chrome, PDF).");
    return sendToTab(tab.id, { type: "FILL_FORM_CYCLE" });
  },
  CHECK_INBOX: async (msg) => {
    const emails = await registry.getMessages(msg.providerName, msg.token);
    return {
      emails: emails.map((e) => {
        const p = emailParser.parse(e);
        return { from: e.from, subject: e.subject, date: e.date, otp: p.otp, links: (p.links || []).slice(0, 5), primaryLink: p.primaryLink };
      }),
    };
  },
  DELETE_RECORD: async (msg) => {
    await store.removePollingJob(msg.id).catch(() => {});
    await store.deleteRecord(msg.id);
    return {};
  },
  UPDATE_RECORD: async (msg) => {
    const patch = {};
    if (typeof msg.notes === "string") patch.notes = msg.notes.slice(0, 2000);
    if (Array.isArray(msg.tags)) patch.tags = msg.tags.map((t) => String(t).slice(0, 40)).slice(0, 20);
    await store.updateRecord(msg.id, patch);
    return { record: await store.getRecord(msg.id) };
  },
  DECRYPT_PASSWORD: async (msg) => {
    const rec = await store.getRecord(msg.id);
    if (!rec) throw new ApiError("not_found", "Запись не найдена.");
    if (!NS.crypto.isEncrypted(rec.password)) return { password: rec.password };
    const pw = await maybeDecrypt(rec.password);
    if (pw == null) return { locked: true };
    return { password: pw };
  },
  SAVE_SETTINGS: async (msg) => ({ settings: await store.saveSettings(msg.patch || {}) }),
  CLEAR_RECORDS: async () => {
    await store.saveRecords([]);
    await chrome.storage.local.set({ [schema.KEYS.POLLING]: {} });
    await maybeClearAlarm();
    return {};
  },

  // провайдеры
  LIST_PROVIDERS: async () => ({ providers: await registry.allProvidersMeta() }),
  TEST_PROVIDER: async (msg) => {
    const p = await registry.buildProviderByName(msg.name);
    if (!p) throw new ApiError("not_found", "Провайдер не найден.");
    const inbox = await p.createInbox();
    return { email: inbox.email };
  },
  TOGGLE_PROVIDER: async (msg) => {
    const cfg = await store.getProvidersConfig();
    const disabled = new Set(cfg.disabled || []);
    if (msg.enabled) disabled.delete(msg.name);
    else disabled.add(msg.name);
    await store.saveProvidersConfig({ disabled: [...disabled] });
    await rebuildMenus();
    return {};
  },
  ADD_CUSTOM_PROVIDER: async (msg) => {
    let config = msg.config;
    if (typeof config === "string") {
      try {
        config = JSON.parse(config);
      } catch (e) {
        throw new ApiError("invalid_json", "Некорректный JSON: " + (e && e.message));
      }
    }
    const v = NS.customProvider.validate(config);
    if (!v.valid) throw new ApiError("invalid_config", v.errors.join(" "));
    const cfg = await store.getProvidersConfig();
    const custom = (cfg.custom || []).filter((c) => c.name !== config.name);
    custom.push(config);
    await store.saveProvidersConfig({ custom });
    await rebuildMenus();
    return { name: config.name };
  },
  REMOVE_CUSTOM_PROVIDER: async (msg) => {
    const cfg = await store.getProvidersConfig();
    await store.saveProvidersConfig({ custom: (cfg.custom || []).filter((c) => c.name !== msg.name) });
    await rebuildMenus();
    return {};
  },
  SET_API_KEY: async (msg) => {
    const cfg = await store.getProvidersConfig();
    const apiKeys = { ...(cfg.apiKeys || {}) };
    apiKeys[msg.name] = msg.key || "";
    await store.saveProvidersConfig({ apiKeys });
    return {};
  },

  // шифрование
  CRYPTO_STATUS: async () => {
    const meta = await getCryptoMeta();
    return { enabled: meta.enabled === true, unlocked: !!(await getSessionMaster()) };
  },
  CRYPTO_SETUP: async (msg) => {
    if (!msg.password || msg.password.length < 4) throw new ApiError("weak", "Мастер-пароль слишком короткий.");
    const salt = NS.crypto.newSalt();
    const key = await NS.crypto.deriveKey(msg.password, salt);
    const verifier = await NS.crypto.makeVerifier(key);
    await chrome.storage.local.set({ ar_crypto: { enabled: true, salt, verifier } });
    await chrome.storage.session.set({ ar_master: msg.password });
    await encryptAllExisting(key);
    return {};
  },
  CRYPTO_UNLOCK: async (msg) => {
    const meta = await getCryptoMeta();
    if (!meta.enabled) throw new ApiError("no_crypto", "Шифрование не включено.");
    const key = await NS.crypto.deriveKey(msg.password, meta.salt);
    if (!(await NS.crypto.checkVerifier(key, meta.verifier))) throw new ApiError("bad_master", "Неверный мастер-пароль.");
    await chrome.storage.session.set({ ar_master: msg.password });
    return {};
  },
  CRYPTO_LOCK: async () => {
    await chrome.storage.session.remove("ar_master");
    return {};
  },
  CRYPTO_DISABLE: async (msg) => {
    const meta = await getCryptoMeta();
    if (meta.enabled) {
      const key = await NS.crypto.deriveKey(msg.password, meta.salt);
      if (!(await NS.crypto.checkVerifier(key, meta.verifier))) throw new ApiError("bad_master", "Неверный мастер-пароль.");
      await decryptAllExisting(key);
    }
    await chrome.storage.local.remove("ar_crypto");
    await chrome.storage.session.remove("ar_master");
    return {};
  },
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const h = handlers[msg && msg.type];
  if (!h) return false;
  h(msg, sender)
    .then((r) => sendResponse(Object.assign({ ok: true }, r || {})))
    .catch((e) => sendResponse({ ok: false, error: toErr(e) }));
  return true;
});

// --- Контекстные меню -----------------------------------------------------
async function rebuildMenus() {
  await chrome.contextMenus.removeAll();
  chrome.contextMenus.create({ id: "ar-fill", title: "AutoReg: заполнить форму", contexts: ["editable", "page"] });
  chrome.contextMenus.create({ id: "ar-email", title: "AutoReg: только email", contexts: ["editable", "page"] });
  try {
    const providers = await registry.enabledProviders();
    if (providers.length) {
      chrome.contextMenus.create({ id: "ar-prov-parent", title: "Сгенерировать email через…", contexts: ["editable", "page"] });
      for (const p of providers)
        chrome.contextMenus.create({ id: "ar-prov::" + p.name, parentId: "ar-prov-parent", title: p.name, contexts: ["editable", "page"] });
    }
  } catch {}
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || tab.id == null) return;
  await ensureContent(tab.id);
  const id = String(info.menuItemId);
  try {
    if (id === "ar-fill") await sendToTab(tab.id, { type: "FILL_FORM_CYCLE" });
    else if (id === "ar-email") await sendToTab(tab.id, { type: "FILL_EMAIL_ONLY" });
    else if (id.startsWith("ar-prov::")) await sendToTab(tab.id, { type: "FILL_EMAIL_ONLY", forceProvider: id.slice(9) });
  } catch {}
});

// --- Горячая клавиша ------------------------------------------------------
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "fill-form") return;
  const tab = await activeTab();
  if (!tab || tab.id == null) return;
  const ok = await ensureContent(tab.id);
  if (ok) sendToTab(tab.id, { type: "FILL_FORM_CYCLE" }).catch(() => {});
});

// --- Автоудаление старых записей ------------------------------------------
async function cleanupOld() {
  const settings = await store.getSettings();
  const days = Number(settings.autoDeleteDays) || 0;
  if (days <= 0) return;
  const cutoff = Date.now() - days * 86400000;
  const list = await store.getRecords();
  const kept = list.filter((r) => {
    const removable = r.status === schema.STATUS.FAILED || r.status === schema.STATUS.GENERATED;
    return !(removable && (r.updatedAt || r.createdAt) < cutoff);
  });
  if (kept.length !== list.length) await store.saveRecords(kept);
}

// --- Инициализация --------------------------------------------------------
chrome.runtime.onInstalled.addListener(() => {
  rebuildMenus();
  cleanupOld();
});
chrome.runtime.onStartup.addListener(() => {
  rebuildMenus();
  cleanupOld();
  ensureAlarm().then(ensurePollLoop);
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === POLL_ALARM) ensurePollLoop();
});

// Возобновляем поллинг при пробуждении воркера.
ensureAlarm().then(() => ensurePollLoop());
